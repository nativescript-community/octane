export declare const ANIMATION_MODULE_TYPE = "NoopAnimations";
declare class NoopAnimationPlayer {
    onDone(cb?: () => void): void;
    onStart(cb?: () => void): void;
    play(): void;
    pause(): void;
    reset(): void;
    restart(): void;
    finish(): void;
    destroy(): void;
    setPosition(_value: number): void;
    getPosition(): number;
    init(): void;
}
declare class NoopAnimationFactory {
    create(): NoopAnimationPlayer;
}
export declare class AnimationBuilder {
    build(): NoopAnimationFactory;
}
export declare class BrowserAnimationBuilder extends AnimationBuilder {
}
export declare const ɵBrowserAnimationBuilder: typeof BrowserAnimationBuilder;
export declare class AnimationDriver {
    validateStyleProperty(): boolean;
    matchesElement(): boolean;
    containsElement(): boolean;
    query(): any[];
    computeStyle(): Record<string, unknown>;
    animate(): NoopAnimationPlayer;
}
export declare class ɵAnimationStyleNormalizer {
    normalizePropertyName(name: string): string;
    normalizeStyleValue(_propertyName: string, value: string | number): string | number;
}
export declare class ɵWebAnimationsStyleNormalizer extends ɵAnimationStyleNormalizer {
}
export declare class ɵAnimationEngine {
    private readonly doc?;
    private readonly driver?;
    private readonly normalizer?;
    constructor(doc?: unknown, driver?: AnimationDriver, normalizer?: ɵAnimationStyleNormalizer);
    onInsert(): void;
    onRemove(): void;
    registerTrigger(): void;
    signalFlushRequired(): void;
    flush(): void;
    listen(): () => void;
    trigger(): NoopAnimationPlayer;
}
export declare class ɵAnimationRendererFactory {
    private readonly delegate?;
    private readonly engine?;
    private readonly zone?;
    constructor(delegate?: {
        createRenderer?: (hostElement: any, type: any) => any;
    }, engine?: ɵAnimationEngine, zone?: {
        runOutsideAngular?: (fn: () => void) => void;
    });
    createRenderer(hostElement: any, type: any): any;
}
export declare class BrowserAnimationsModule {
}
export declare class NoopAnimationsModule {
}
export declare function provideAnimations(): any[];
declare const _default: {};
export default _default;
