export declare function createRequire(_url: string): any;
declare const _default: {
    createRequire: typeof createRequire;
};
export default _default;
