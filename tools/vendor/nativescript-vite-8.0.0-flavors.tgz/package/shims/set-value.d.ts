/**
 * shim for set-value commonjs package export
 */
export default function setValue(obj: any, path: any, value: any): any;
