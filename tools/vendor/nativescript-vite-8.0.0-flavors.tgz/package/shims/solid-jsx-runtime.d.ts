export declare function Fragment(props: any): any;
export declare function jsx(type: any, props: any): number | boolean | (string & {}) | Node | import("solid-js").JSX.ArrayElement | {
    type: any;
    props: any;
};
export declare const jsxs: typeof jsx;
export declare const jsxDEV: typeof jsx;
