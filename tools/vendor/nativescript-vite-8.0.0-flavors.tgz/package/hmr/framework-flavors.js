import { createRequire } from 'node:module';
import { existsSync, readFileSync } from 'node:fs';
import * as path from 'node:path';
import { getProjectRootPath } from '../helpers/project.js';
const BUILT_IN_FLAVORS = new Set(['angular', 'vue', 'react', 'solid', 'typescript', 'javascript']);
const flavors = new Map();
/**
 * Register a flavor. Call it before `baseConfig({ flavor })` runs — from the
 * top of the framework's config helper is the natural place — so the HMR
 * plugins the base config installs can find the server strategy, and the
 * device bundle is seeded with the client strategy's URL. Registering the
 * same flavor again replaces the previous definition.
 */
export function registerFrameworkFlavor(definition) {
    const flavor = String(definition?.flavor || '').trim();
    if (!flavor)
        throw new TypeError('[@nativescript/vite] registerFrameworkFlavor: `flavor` is required.');
    if (BUILT_IN_FLAVORS.has(flavor)) {
        throw new Error(`[@nativescript/vite] registerFrameworkFlavor: "${flavor}" is a built-in flavor and cannot be replaced.`);
    }
    if (!definition.server || typeof definition.server.matchesFile !== 'function' || typeof definition.server.processFile !== 'function' || typeof definition.server.buildRegistry !== 'function') {
        throw new TypeError(`[@nativescript/vite] registerFrameworkFlavor("${flavor}"): \`server\` must be a FrameworkServerStrategy.`);
    }
    if (typeof definition.client !== 'string' || !definition.client.trim()) {
        throw new TypeError(`[@nativescript/vite] registerFrameworkFlavor("${flavor}"): \`client\` must be a module specifier.`);
    }
    if (definition.server.flavor !== flavor) {
        throw new Error(`[@nativescript/vite] registerFrameworkFlavor("${flavor}"): the server strategy declares flavor "${definition.server.flavor}".`);
    }
    flavors.set(flavor, { ...definition, flavor });
}
export function getFrameworkFlavor(flavor) {
    return flavors.get(flavor);
}
/**
 * Package names that ship a registered flavor's client strategy. The device
 * pipeline treats them like `@nativescript/vite` itself: served per-module
 * through `/ns/m`, never through the vendor bundle or the plugin registry
 * shim, so the module's own relative imports and its imports of the shared
 * client surface resolve to the live client's canonical URLs.
 */
export function getFlavorClientPackages() {
    const names = new Set();
    for (const definition of flavors.values()) {
        const name = packageNameOfSpecifier(definition.client);
        if (name)
            names.add(name);
    }
    return names;
}
function packageNameOfSpecifier(specifier) {
    if (!specifier || specifier.startsWith('.') || path.isAbsolute(specifier))
        return null;
    const parts = specifier.split('/');
    return specifier.startsWith('@') ? (parts.length >= 2 ? `${parts[0]}/${parts[1]}` : null) : parts[0];
}
export function isBuiltInFlavor(flavor) {
    return BUILT_IN_FLAVORS.has(flavor);
}
/**
 * The device-side URL path of a registered flavor's client strategy module —
 * `/ns/m/node_modules/<package>/<file>` — or `''` for a built-in / unknown
 * flavor. The specifier is resolved from the app root like any import, then
 * expressed relative to its package so the path holds whether the package is
 * installed or linked from a workspace.
 */
export function getClientStrategyDevicePath(flavor, projectRoot = getProjectRootPath()) {
    const definition = flavors.get(flavor);
    if (!definition)
        return '';
    const resolved = resolveFromProject(definition.client, projectRoot);
    const pkg = findPackageRoot(resolved);
    if (!pkg) {
        throw new Error(`[@nativescript/vite] flavor "${flavor}": client module ${definition.client} resolved to ${resolved}, which is not inside a package.`);
    }
    const inside = path.relative(pkg.dir, resolved).split(path.sep).join('/');
    return `/ns/m/node_modules/${pkg.name}/${inside}`;
}
function resolveFromProject(specifier, projectRoot) {
    if (path.isAbsolute(specifier))
        return specifier;
    const require = createRequire(path.join(projectRoot, 'package.json'));
    try {
        return require.resolve(specifier);
    }
    catch (error) {
        throw new Error(`[@nativescript/vite] cannot resolve client strategy module ${JSON.stringify(specifier)} from ${projectRoot}: ${error.message}`);
    }
}
function findPackageRoot(file) {
    let dir = path.dirname(file);
    for (;;) {
        const manifest = path.join(dir, 'package.json');
        if (existsSync(manifest)) {
            try {
                const name = JSON.parse(readFileSync(manifest, 'utf8')).name;
                if (typeof name === 'string' && name)
                    return { dir, name };
            }
            catch { }
        }
        const parent = path.dirname(dir);
        if (parent === dir)
            return null;
        dir = parent;
    }
}
//# sourceMappingURL=framework-flavors.js.map