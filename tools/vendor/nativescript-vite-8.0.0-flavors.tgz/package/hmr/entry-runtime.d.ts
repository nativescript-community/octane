type EntryOpts = {
    origin: string;
    main: string;
    ver: string | number;
    verbose?: boolean;
};
type HmrCssApplier = (cssText: string, refreshRoot?: boolean) => void;
type HttpImportFn = (url: string) => Promise<any>;
type HttpPreloadResult = {
    ok: boolean;
    ms: number;
    url: string;
    err?: string;
};
export declare const APP_CSS_TAG = "app.css";
export declare function installHttpCoreCssSupport(coreModule: any, verbose?: boolean): HmrCssApplier | null;
export declare function preloadHttpCoreStyleScope(importHttp: HttpImportFn, origin: string, verbose?: boolean): Promise<HttpPreloadResult>;
export default function startEntry(opts: EntryOpts): Promise<void>;
export {};
