export declare function clearCjsNamedExportsCache(filePath?: string): void;
export declare function getCjsNamedExportsCacheSize(): number;
/**
 * Normalize a path that may have come from a Vite-resolved id (e.g.
 * `/@fs/Users/.../node_modules/foo/index.js?import`) into a plain
 * absolute filesystem path that `createRequire` can load.
 *
 * Returns null if the path does not look like an absolute filesystem
 * path that exists on disk.
 */
export declare function normalizeAbsolutePathForRequire(input: string | null | undefined): string | null;
/**
 * Enumerate the named exports of a CommonJS module by loading it in the
 * dev server's Node context.
 *
 * Returns an empty array if the module can't be loaded, isn't in
 * node_modules, or doesn't expose any enumerable string-keyed properties
 * that look like JS identifiers.
 *
 * Results are cached by absolute path. Pass `clearCjsNamedExportsCache()`
 * if you need to invalidate (e.g. between tests).
 */
export declare function getCjsNamedExports(absolutePath: string | null | undefined): string[];
