export interface PackageExportShape {
    /** Union of every named export reachable from the package entry, minus `default`. */
    names: Set<string>;
    /** True if any visited file emits a `default` export. */
    hasDefault: boolean;
    /** Absolute path to the resolved entry file (empty string when the package could not be resolved). */
    entry: string;
    /** Files visited during the walk — useful for diagnostics and cache invalidation. */
    visitedFiles: string[];
}
/**
 * Clear the cache. Tests use this to assert determinism; production code
 * never needs it (the cache is intentionally process-lifetime).
 */
export declare function __clearPackageExportsCache(): void;
export declare function enumeratePackageExports(packageId: string, projectRoot: string): PackageExportShape;
