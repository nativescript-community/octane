export declare function rewriteVendorVueSpec(code: string, origin: string, _ver?: number): string;
