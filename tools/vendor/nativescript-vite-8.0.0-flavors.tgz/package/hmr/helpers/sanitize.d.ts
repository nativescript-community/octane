export declare function stripRtCoreSentinel(code: string): string;
export declare function stripDanglingViteCjsImports(code: string): string;
declare const _default: {
    stripRtCoreSentinel: typeof stripRtCoreSentinel;
};
export default _default;
