import { parse as babelParse } from '@babel/parser';
import { genCode } from './babel.js';
export function astExtractImportsAndStripTypes(source) {
    const diagnostics = [];
    let ast = null;
    try {
        ast = babelParse(source, {
            sourceType: 'module',
            plugins: ['typescript', 'jsx', 'decorators-legacy', 'classProperties', 'classPrivateProperties', 'classPrivateMethods'],
        });
    }
    catch (e) {
        diagnostics.push('[ast] parse failed: ' + e?.message);
        return { imports: [], body: source, diagnostics };
    }
    const importDecls = [];
    const other = [];
    for (const stmt of ast.program.body) {
        if (stmt.type === 'ImportDeclaration')
            importDecls.push(stmt);
        else
            other.push(stmt);
    }
    for (const imp of importDecls) {
        if (imp.importKind === 'type') {
            const idx = importDecls.indexOf(imp);
            if (idx >= 0)
                importDecls.splice(idx, 1);
            continue;
        }
        if (imp.specifiers) {
            imp.specifiers = imp.specifiers.filter((s) => s.importKind !== 'type');
        }
    }
    const fileNoImports = {
        ...ast,
        program: { ...ast.program, body: other },
    };
    let bodyCode = '';
    try {
        bodyCode = genCode(fileNoImports, { comments: true }).code;
    }
    catch (e) {
        diagnostics.push('[ast] generate body failed: ' + e?.message);
        bodyCode = source;
    }
    if (/(\(|,|=)\s*[A-Za-z_$][\w$]*\s*:\s*(?:boolean|string|number|any|unknown|void|null|undefined)/.test(bodyCode)) {
        bodyCode = bodyCode.replace(/(\(|,|=)\s*([A-Za-z_$][\w$]*)\s*:\s*(boolean|string|number|any|unknown|void|null|undefined)/g, '$1 $2');
        diagnostics.push('[ast-fallback] stripped residual param annotations');
    }
    const beforeVarStrip = bodyCode;
    bodyCode = bodyCode.replace(/\b(const|let|var)\s+([A-Za-z_$][\w$]*)\s*:\s*([^=;]+?)(=)/g, (_m, decl, name, _type, eq) => `${decl} ${name} ${eq}`);
    if (bodyCode !== beforeVarStrip) {
        diagnostics.push('[ast-fallback] stripped variable type annotations');
    }
    const importsCode = importDecls
        .map((d) => {
        try {
            return genCode(d, { comments: false }).code;
        }
        catch {
            return '';
        }
    })
        .filter(Boolean);
    const beforeDefaults = (source.match(/\bdefault\s*:/g) || []).length;
    const afterDefaults = (bodyCode.match(/\bdefault\s*:/g) || []).length;
    if (afterDefaults < beforeDefaults)
        diagnostics.push(`[ast][warn] default property count dropped ${beforeDefaults} -> ${afterDefaults}`);
    return { imports: importsCode, body: bodyCode, diagnostics };
}
//# sourceMappingURL=ast-extract.js.map