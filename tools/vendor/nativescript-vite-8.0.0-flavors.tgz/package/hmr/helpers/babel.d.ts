export declare function genCode(node: any, opts?: any): {
    code: string;
};
