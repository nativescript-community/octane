export declare function astNormalizeModuleImportsAndHelpers(code: string, opts?: {
    underscoreTextFallback?: boolean;
}): string;
export declare function astVerifyAndAnnotateDuplicates(code: string): string;
declare const _default: {
    astNormalizeModuleImportsAndHelpers: typeof astNormalizeModuleImportsAndHelpers;
    astVerifyAndAnnotateDuplicates: typeof astVerifyAndAnnotateDuplicates;
};
export default _default;
