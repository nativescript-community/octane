export interface AstProcessResult {
    imports: string[];
    body: string;
    diagnostics: string[];
}
export declare function astExtractImportsAndStripTypes(source: string): AstProcessResult;
