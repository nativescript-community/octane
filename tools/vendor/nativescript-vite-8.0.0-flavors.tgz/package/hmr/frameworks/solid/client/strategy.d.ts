import type { FrameworkClientStrategy } from '../../../client/framework-client-strategy.js';
/**
 * Solid's on-device HMR behavior. Solid has no SFC registry or hot-update
 * message protocol — its whole client surface is the completion-hook global
 * (installed once here) plus the post-drain boundary propagation.
 */
export declare const solidClientStrategy: FrameworkClientStrategy;
