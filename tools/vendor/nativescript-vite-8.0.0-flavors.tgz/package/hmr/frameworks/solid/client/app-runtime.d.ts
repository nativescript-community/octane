/**
 * Bootstrap + HMR remount for NativeScript Solid apps.
 *
 * Solid runs with `hot: false` (solid-refresh is off — it rewrites `export
 * function` into a non-hoisted const and breaks TanStack file-route modules), so
 * there is no fine-grained component HMR.
 *
 * Division of labour on each Solid HMR cycle (`__ns_solid_hmr_subscribe`):
 *   • ROUTE files — handled by @nativescript/tanstack-router's per-page remount
 *     (`subscribeSolidHmrRemount` → `page.__ns_remount`), which swaps the route
 *     component in place WITHOUT re-navigating, so the user stays on their route.
 *     This helper does nothing for route-only edits.
 *   • Everything else (app shell / shared components / app entry) — this helper
 *     re-imports the app entry and re-renders the whole Solid tree. The router is
 *     REUSED (its chain is never evicted), so the current route is preserved.
 *
 * Renderer bindings (`Application`, `render`, `document`) are passed in rather than
 * imported here so the helper uses the app's exact solid-js / dominative instances.
 * Importing our own copies could resolve to a different module realm and break
 * Solid reactivity (NativeScript can load a package's deps in a separate realm).
 */
export interface StartSolidAppOptions {
    /** `@nativescript/core` `Application`. */
    Application: {
        run(entry: {
            create: () => any;
        }): void;
    };
    /** `@nativescript-community/solid-js` `render` — mounts a component, returns a disposer. */
    render: (component: any, target: any) => () => void;
    /** dominative `document` — returned as the root view; `document.body` is the mount target. */
    document: any;
    /** Initial root component (used for the first mount). */
    root: any;
    /**
     * App-relative specifier of the module that exports the root component, as
     * `App` or default (e.g. `/src/native/app`). Re-imported fresh on each cycle.
     */
    rootModule: string;
    /**
     * Optional `@nativescript/core` `Frame` class. Pass it when the app uses a
     * topmost-frame router (e.g. solid-navigation's `StackRouter` with
     * `useTopMostFrame`): those routers re-run their initial navigation against
     * `Frame.topmost()` when the fresh tree mounts. During a remount that would
     * target a STALE frame from the old tree (often a nested tab frame) and push
     * a backstack entry per edit. With `Frame` provided, the remount render
     * redirects such navigations to the ROOT frame (`document.documentElement`)
     * with `clearHistory: true`, so each HMR apply swaps the whole tree in place
     * and disposes the old pages instead of stacking on top of them.
     */
    Frame?: any;
}
/**
 * Boot a NativeScript Solid app and wire up HMR remounting. Call once from the
 * app entry, e.g.:
 *
 *   import './utils/dom';
 *   import { Application, Frame } from '@nativescript/core';
 *   import { render } from '@nativescript-community/solid-js';
 *   import { document } from 'dominative';
 *   import { startSolidApp } from '@nativescript/vite/solid-bootstrap';
 *   import { App } from './app';
 *
 *   // `Frame` is optional — pass it when using a topmost-frame router
 *   // (solid-navigation) so HMR remounts replace the root page in place.
 *   startSolidApp({ Application, render, document, Frame, root: App, rootModule: '/src/native/app' });
 */
export declare function startSolidApp(options: StartSolidAppOptions): void;
