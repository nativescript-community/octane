import type { FrameworkClientStrategy } from '../../../client/framework-client-strategy.js';
/**
 * Angular's on-device HMR behavior, surfaced as a `FrameworkClientStrategy` so
 * the shared client never references the Angular client module directly. Both
 * methods delegate to the existing `angular/client` functions — no behavior
 * change. Angular drives its own view refresh inside `handleHotUpdateMessage`,
 * so the mount/navigate/batch hooks stay unimplemented (shared defaults apply).
 */
export declare const angularClientStrategy: FrameworkClientStrategy;
