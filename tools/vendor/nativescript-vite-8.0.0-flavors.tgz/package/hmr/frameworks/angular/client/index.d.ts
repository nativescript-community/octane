type GetCoreFn = (name: string) => any;
export declare function installAngularHmrClientHooks(): void;
interface AngularUpdateOptions {
    getCore: GetCoreFn;
    verbose: boolean;
}
export declare function refreshAngularBootstrapOptions(msg: any, options: AngularUpdateOptions): Promise<void>;
export declare function handleAngularHotUpdateMessage(msg: any, options: AngularUpdateOptions): Promise<boolean>;
export {};
