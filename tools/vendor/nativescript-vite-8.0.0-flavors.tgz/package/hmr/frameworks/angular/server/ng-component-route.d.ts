import type { FrameworkModuleRequestContext } from '../../../server/framework-strategy.js';
/**
 * Intercept AnalogJS Angular component live-reload requests on the `/ns/m`
 * route. Returns `true` when the request was an `/@ng/component` metadata
 * fetch (answered with the no-update stub, or delegated downstream to
 * Analog's middleware with an empty-body guard); `false` for every other
 * request so the shared `/ns/m` pipeline proceeds.
 *
 * Angular 21's `ɵɵgetReplaceMetadataURL` (in @angular/core
 * _debug_node-chunk.mjs) builds the metadata-replacement URL as
 * `new URL('./@ng/component?c=<id>&t=<ts>', import.meta.url).href`.
 * Because `import.meta.url` for a NS-served module is
 * `http://host:port/ns/m/<project-relative>/component.ts`, the resolved
 * metadata URL ends up *nested* under the component's directory:
 * `/ns/m/<dir>/@ng/component?c=...&t=...`.
 *
 * AnalogJS's `liveReloadPlugin` registers a middleware that matches
 * `/@ng/component` anywhere in `req.url` and returns either an empty module
 * body (no HMR update available) or the metadata-replacement code (after a
 * save invalidates the file). Without this delegation the NS `/ns/m/`
 * middleware would treat the path as a file lookup, fail to resolve
 * `@ng/component` against disk, and respond with 404 — which surfaces as
 * `HTTP fetch/compile failed` at the component's own `_HmrLoad(Date.now())`
 * call on initial boot and blocks Angular component bootstrapping.
 *
 * Calling `next()` here lets AnalogJS's middleware (or any other middleware
 * later in the chain) handle the request. Analog's middleware reads only the
 * `?c=` query string and is pathname-agnostic, so we don't need to rewrite
 * `req.url` for it to work.
 *
 * HOWEVER: AnalogJS responds with an EMPTY body (`res.end('')`) for
 * non-invalidated component IDs (initial boot, before any file save). The
 * iOS HTTP ESM loader's `LoadHttpModuleForUrl` (ModuleInternalCallbacks.mm)
 * treats an empty body as a fetch failure (`body.empty() → reject`), even
 * when the HTTP status is 200 OK. That bubbles up as
 * `HTTP fetch/compile failed` at the device's `__ns_import(...)` inside each
 * component's `_HmrLoad(Date.now())` and crashes Angular's component
 * bootstrap. To make Analog's empty "no-update" response acceptable to the
 * iOS loader, we wrap `res.write` / `res.end` and substitute a minimal valid
 * ESM module body (`export {}`) when downstream writes nothing. Non-empty
 * bodies (real HMR update payloads after a save) pass through unchanged.
 */
export declare function interceptNgComponentRequest(ctx: FrameworkModuleRequestContext): boolean;
