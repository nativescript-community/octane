export type HotUpdateGraphModuleLike = {
    id?: string | null;
    importedModules?: Iterable<{
        id?: string | null;
    }>;
    importers?: Iterable<HotUpdateGraphModuleLike>;
};
export declare function collectGraphUpdateModulesForHotUpdate(options: {
    file: string;
    flavor: string;
    modules?: Iterable<HotUpdateGraphModuleLike>;
    getModuleById: (id: string) => HotUpdateGraphModuleLike | undefined;
    verbose?: boolean;
}): HotUpdateGraphModuleLike[];
export declare function collectAngularHotUpdateRoots(options: {
    file: string;
    modules?: Iterable<HotUpdateGraphModuleLike>;
    getModuleById: (id: string) => HotUpdateGraphModuleLike | undefined;
    getModulesByFile?: (file: string) => Iterable<HotUpdateGraphModuleLike> | undefined | null;
}): HotUpdateGraphModuleLike[];
export declare function angularSourceHasSemanticDecorator(source: string): boolean;
export declare function shouldInvalidateAngularTransitiveImporters(options: {
    flavor: string;
    file: string;
    source?: string | null;
}): boolean;
export declare function collectAngularTransformCacheInvalidationUrls(options: {
    file: string;
    isTs: boolean;
    hotUpdateRoots: Iterable<{
        id?: string | null;
    }>;
    transitiveImporters?: Iterable<{
        id?: string | null;
    }>;
    projectRoot?: string;
    workspaceRoot?: string | null;
}): string[];
export declare function collectAngularEvictionUrls(options: {
    file: string;
    hotUpdateRoots?: Iterable<{
        id?: string | null;
        file?: string | null;
    }>;
    transitiveImporters?: Iterable<{
        id?: string | null;
        file?: string | null;
    }>;
    projectRoot: string;
    origin: string;
    bootstrapEntry?: string | null;
    workspaceRoot?: string | null;
}): string[];
/**
 * Decode an Analog component id (`src%2Fapp%2F…%40Class`) to its canonical
 * form (`src/app/….ts@Class`) — the shape `URLSearchParams` yields for the
 * `c` query param on the device's metadata fetch.
 */
export declare function normalizeAngularComponentUpdateId(raw: unknown): string | null;
export interface AngularComponentUpdateLedger {
    /** Record a forwarded `angular:component-update` payload (`{ id, timestamp }`). */
    record(data: unknown): void;
    /** True when `(componentId, timestamp)` matches a recorded broadcast. */
    isLive(componentId: string, timestamp: number): boolean;
}
export declare function createAngularComponentUpdateLedger(): AngularComponentUpdateLedger;
export declare function shouldSuppressDefaultViteHotUpdate(options: {
    flavor: string;
    file: string;
}): boolean;
export type PendingAngularReloadSuppressionEntry = {
    absPath: string;
    relPath: string;
    expiresAt: number;
};
export declare function normalizeHotReloadMatchPath(raw: string, root?: string): string;
/**
 * True when Analog's in-place component metadata event targets the same TS
 * file already owned by a pending `ns:angular-update` reboot. A single save
 * must never both rebuild the Angular root and then run `ɵɵreplaceMetadata`
 * against that freshly rebuilt routed component tree.
 */
export declare function shouldSuppressAngularComponentUpdatePayload(options: {
    payload: any;
    pendingEntries: Iterable<PendingAngularReloadSuppressionEntry>;
    root?: string;
    now?: number;
}): boolean;
export declare function shouldSuppressViteFullReloadPayload(options: {
    payload: any;
    pendingEntries: Iterable<PendingAngularReloadSuppressionEntry>;
    root?: string;
    now?: number;
}): boolean;
