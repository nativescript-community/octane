/**
 * Identifies the Angular **bootstrap (root) component** of a project from
 * its dev-server entry module, and provides helpers to match Analog's
 * `angular:component-update` events against it.
 *
 * Why this exists
 * ---------------
 * NativeScript's root Angular component hosts the navigation `Frame` (via
 * `<page-router-outlet>`). Analog's in-place template HMR
 * (`ɵɵreplaceMetadata`) recreates the matching `LView`s for the edited
 * component WITHOUT re-running router navigation. For a normal child
 * component that's exactly right — its view re-renders inside an intact
 * page. For the ROOT component it's fatal: replacing the root metadata
 * tears down the `PageRouterOutlet`'s `Frame` and nothing re-navigates,
 * leaving a permanent blank/white screen that no further in-place update
 * can recover.
 *
 * The reboot path (`ns:angular-update` → `__reboot_ng_modules__`) DOES
 * recover the root view (it re-bootstraps and replays route state). So the
 * fix is to route every root-component edit through the reboot path and
 * suppress the destructive in-place update for it. Both halves need to know
 * which file is the root component — that's what this module resolves.
 *
 * Resolution is intentionally dependency-free string/path math so it can be
 * unit-tested without a Vite server or filesystem. It targets the modern
 * standalone bootstrap shape (`bootstrapApplication(AppComponent, …)`),
 * which is what `main.ts` uses; it degrades gracefully to `null` for shapes
 * it can't statically resolve (e.g. NgModule `bootstrap: [...]`), in which
 * case callers keep their existing behavior.
 */
export interface BootstrapRootComponent {
    /**
     * Extensionless, project-relative POSIX path with a leading slash —
     * e.g. `/src/app/app.component`. Comparisons are always extensionless so
     * a `.html` template edit and its `.ts` component resolve to the same key.
     */
    moduleRel: string;
    /**
     * The class name passed to `bootstrapApplication(...)` (best-effort,
     * resolved back to the imported binding name when aliased). Used as a
     * secondary match signal for Analog ids whose path base differs from the
     * project root.
     */
    className: string;
}
/**
 * Normalizes any project-relative path to a leading-slash, extensionless
 * POSIX key suitable for equality comparison between a `.html`/`.ts` edit
 * and the resolved root component.
 */
export declare function toExtensionlessModuleRel(rel: string): string;
/** True when two project-relative paths refer to the same module (ignoring extension). */
export declare function isSameAngularModuleRel(a: string | null | undefined, b: string | null | undefined): boolean;
/**
 * Resolves the bootstrap root component from a dev-server entry module's
 * source. Returns `null` when the bootstrap shape can't be statically
 * resolved (callers should then keep their default behavior).
 */
export declare function resolveBootstrapRootComponent(options: {
    entrySource: string;
    entryRel: string;
    appRootRel?: string;
}): BootstrapRootComponent | null;
/**
 * Decodes Analog's `angular:component-update` payload `id`
 * (`encodeURIComponent(relativePath + '@' + className)`) into a normalized,
 * extensionless module rel plus the class name, so the bridge can compare it
 * against the resolved root component. Returns `null` for empty/invalid ids.
 */
export declare function decodeAngularComponentUpdateId(id: unknown): {
    moduleRel: string;
    className: string;
} | null;
/**
 * True when an Analog `angular:component-update` `id` targets the resolved
 * root component — matched by module path first (robust to class-name
 * collisions), then by class name as a fallback.
 */
export declare function isAngularRootComponentUpdate(root: BootstrapRootComponent | null | undefined, id: unknown): boolean;
