export declare function rewriteAngularEntryRegisterOnly(code: string, angularCoreImportSource?: string): string;
export declare function resolveAngularCoreHmrImportSource(code: string, httpOrigin?: string): string;
