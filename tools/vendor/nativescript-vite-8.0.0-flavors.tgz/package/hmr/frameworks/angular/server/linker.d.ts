export declare function linkAngularPartialsIfNeeded(code: string, filename?: string): string;
