import type { FrameworkClientStrategy } from '../../../client/framework-client-strategy.js';
/**
 * React reuses the generic TypeScript HMR path on BOTH server and client: it
 * has no Fast Refresh, so a module edit drives a plain module reload (the
 * React tree re-renders). This mirrors the server's
 * `{ ...typescriptServerStrategy, flavor: 'react' }` — modal tracking, the
 * TS-style root factory, and the code-behind re-registration all apply — but
 * the batch refresh differs: React mounts a dominative document root via
 * `startReactApp` rather than an `app-root` module, so the TypeScript
 * `resetRootView({moduleName:'app-root'})` path doesn't apply.
 */
export declare const reactClientStrategy: FrameworkClientStrategy;
