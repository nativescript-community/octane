import type { FrameworkServerStrategy } from '../../../server/framework-strategy.js';
export declare const reactServerStrategy: FrameworkServerStrategy;
