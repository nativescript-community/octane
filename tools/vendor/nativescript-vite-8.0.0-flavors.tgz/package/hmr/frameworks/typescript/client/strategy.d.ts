import type { FrameworkClientStrategy } from '../../../client/framework-client-strategy.js';
/**
 * TypeScript (plain XML) flavor client strategy. React reuses everything here
 * except `refreshAfterBatch` (see `frameworks/react/client/strategy.ts`) —
 * mirroring the server's `{ ...typescriptServerStrategy, flavor: 'react' }`.
 */
export declare const typescriptClientStrategy: FrameworkClientStrategy;
