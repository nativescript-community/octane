import type { ViteDevServer } from 'vite';
import type { RegisterSfcHandlersOptions } from './sfc-route-shared.js';
/**
 * Registers `GET /ns/asm` — the deterministic, self-contained SFC assembler module.
 * Extracted verbatim from `websocket-sfc.ts` (pure move, no behavior change).
 */
export declare function registerSfcAsmRoute(server: ViteDevServer, options: RegisterSfcHandlersOptions): void;
