import type { FrameworkServerStrategy } from '../../../server/framework-strategy.js';
export declare const processSfcCode: (code: string) => string;
/**
 * Purge BOTH transform-cache layers for a changed file so the device's
 * eviction + re-import evaluates the CURRENT save's code (mirrors the
 * Solid/Angular hot-update tails — see solid/server/strategy.ts for the full
 * two-layer rationale):
 *
 *   1. `sharedTransformRequest` keeps a 60s TTL result cache to amortize the
 *      cold-boot bulk walk + device request bursts. Without purging, a save
 *      that lands inside the TTL window (e.g. the FIRST save after boot, whose
 *      entry the initial graph walk populated) serves the device the PREVIOUS
 *      transform — the HMR cycle runs perfectly on-device yet renders stale
 *      values.
 *   2. Vite's own `ModuleNode.transformResult` for the file + transitive
 *      importers, so `server.transformRequest` re-runs the pipeline.
 *
 * Ends with the same `clear()` sledgehammer Solid uses: the `/ns/m/` handler
 * probes many candidate extensions per spec and EACH candidate is a separate
 * cache key, so targeted invalidation alone can miss the key a previous serve
 * actually populated.
 */
export declare function purgeVueTransformCachesForHotUpdate(options: {
    file: string;
    server: {
        config?: {
            root?: string;
        };
        moduleGraph?: any;
    };
    sharedTransformRequest?: {
        invalidateMany: (urls: Iterable<string>) => void;
        clear: () => void;
    } | null;
    verbose?: boolean;
}): void;
export declare const vueServerStrategy: FrameworkServerStrategy;
