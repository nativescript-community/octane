import type { ViteDevServer } from 'vite';
import type { RegisterSfcHandlersOptions } from './sfc-route-shared.js';
/**
 * Registers `GET /ns/sfc-meta` — JSON metadata (script exports, render presence,
 * hmr id) for an SFC. Extracted verbatim from `websocket-sfc.ts` (pure move).
 */
export declare function registerSfcMetaRoute(server: ViteDevServer, options: RegisterSfcHandlersOptions): void;
