export type ProcessCodeForDeviceFn = (code: string, isVitePreBundled: boolean) => string;
export interface ExtractTemplateRenderResult {
    helperBindings: string;
    renderDecl: string;
    inlineBlock?: string;
    ok: boolean;
}
/**
 * Factory that returns the Vue SFC processor with dependencies injected.
 */
export declare function createProcessSfcCode(processCodeForDevice: ProcessCodeForDeviceFn): (code: string) => string;
export declare function processTemplateVariantMinimal(code: string): string;
export declare function extractTemplateRender(code: string): ExtractTemplateRenderResult;
export declare function buildInlineTemplateBlock(compiled: string): string | undefined;
