import type { FrameworkServerStrategy } from '../../../server/framework-strategy.js';
/**
 * Plugin-closure dependencies the SFC route handlers need. The pure transform
 * functions (`cleanCode`, `processCodeForDevice`, `rewriteImports`) and the
 * device-origin resolver (`getServerOrigin`) are imported directly (from
 * `websocket-device-transform.ts` / `server-origin.ts`); only genuine plugin
 * state is injected here.
 */
export interface RegisterSfcHandlersOptions {
    verbose: boolean;
    appVirtualWithSlash: string;
    sfcFileMap: Map<string, string>;
    depFileMap: Map<string, string>;
    getStrategy(): FrameworkServerStrategy;
}
export declare const babelTraverse: any;
export declare const parse: typeof import("@vue/compiler-sfc").parse, compileTemplate: typeof import("@vue/compiler-sfc").compileTemplate, compileScript: typeof import("@vue/compiler-sfc").compileScript, compileStyleAsync: typeof import("@vue/compiler-sfc").compileStyleAsync;
/**
 * Compile an SFC descriptor's `<style>` blocks to one CSS string for the device
 * (`scss`/`sass` via the app's `sass`; plain CSS passes through).
 *
 * Emitted UNSCOPED — the HMR template compile doesn't stamp `data-v-*` ids, so
 * scoped selectors wouldn't match; NS components use uniquely-prefixed classes,
 * so global application is equivalent. Returns `''` if there are no styles or
 * every block fails (callers degrade gracefully).
 */
export declare function compileSfcStylesToCss(descriptor: any, filename: string, projectRoot: string, verbose?: boolean): Promise<string>;
export declare const pluginTransformTypescript: any;
/**
 * Canonicalize app-source `/ns/m/` imports inside a served Vue SFC artifact
 * (assembler module or `/ns/sfc` variant): strip any `__ns_hmr__/<tag>/`
 * segment (stale cached device code) so every import lands on the STABLE
 * `/ns/m/<app-path>` URL.
 *
 * Why canonical (not versioned): module identity IS the URL. Freshness for
 * changed deps comes from explicit eviction — ns:module `invalidateModules` drops
 * the canonical key from V8's registry AND arms the runtime's bust-next-fetch
 * nonce, so the artifact's re-import re-fetches current content. Emitting a
 * versioned URL would mint a NEW module identity per save (the runtime no
 * longer collapses tags), splitting module state.
 *
 * Vendor (`node_modules`) paths pass through untouched (they're already
 * stable and never tagged).
 */
export declare function canonicalizeNsMAppImports(code: string): string;
