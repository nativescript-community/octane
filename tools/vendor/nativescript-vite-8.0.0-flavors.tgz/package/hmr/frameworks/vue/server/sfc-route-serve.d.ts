import type { ViteDevServer } from 'vite';
import type { RegisterSfcHandlersOptions } from './sfc-route-shared.js';
/**
 * Registers `GET /ns/sfc` — serves SFC modules. Full SFCs delegate to the `/ns/asm`
 * assembler; script/template variants are processed for device delivery. Extracted
 * verbatim from `websocket-sfc.ts` (pure move, no behavior change).
 */
export declare function registerSfcServeRoute(server: ViteDevServer, options: RegisterSfcHandlersOptions): void;
