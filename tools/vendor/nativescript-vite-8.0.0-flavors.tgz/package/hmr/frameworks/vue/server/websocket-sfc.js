import { registerSfcServeRoute } from './sfc-route-serve.js';
import { registerSfcMetaRoute } from './sfc-route-meta.js';
import { registerSfcAsmRoute } from './sfc-route-assemble.js';
/**
 * Registers the three Vue SFC endpoints on the dev server:
 *   - `GET /ns/sfc`      — serves SFC modules (full delegates to the assembler; variants processed)
 *   - `GET /ns/sfc-meta` — JSON metadata (script exports, render presence) for an SFC
 *   - `GET /ns/asm`      — deterministic, self-contained SFC assembler module
 *
 * The implementation of each endpoint lives in its own focused module
 * (`sfc-route-{serve,meta,assemble}.ts`); this barrel preserves the public surface
 * (`registerSfcHandlers` + `RegisterSfcHandlersOptions`) and the middleware
 * registration order (/ns/sfc, /ns/sfc-meta, /ns/asm).
 */
export function registerSfcHandlers(server, options) {
    registerSfcServeRoute(server, options);
    registerSfcMetaRoute(server, options);
    registerSfcAsmRoute(server, options);
}
//# sourceMappingURL=websocket-sfc.js.map