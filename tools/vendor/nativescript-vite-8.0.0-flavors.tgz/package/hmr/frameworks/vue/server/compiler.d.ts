import { parse as vueParse, compileTemplate as vueCompileTemplate, compileScript as vueCompileScript, compileStyleAsync as vueCompileStyleAsync } from '@vue/compiler-sfc';
export declare function makeNativeScriptIsCustomElement(bindingMetadata?: Record<string, unknown>): (tag: string) => boolean;
export declare const vueSfcCompiler: {
    parse: typeof vueParse;
    compileTemplate: typeof vueCompileTemplate;
    compileScript: typeof vueCompileScript;
    compileStyleAsync: typeof vueCompileStyleAsync;
};
export declare const parseSfc: typeof vueParse;
export declare const compileSfcTemplate: typeof vueCompileTemplate;
export declare const compileSfcScript: typeof vueCompileScript;
export declare const compileSfcStyleAsync: typeof vueCompileStyleAsync;
export type { SFCDescriptor, SFCParseOptions, SFCScriptCompileOptions, SFCTemplateCompileOptions } from '@vue/compiler-sfc';
