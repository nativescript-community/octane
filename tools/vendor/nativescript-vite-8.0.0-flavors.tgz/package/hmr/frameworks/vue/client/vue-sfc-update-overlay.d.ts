export type VueOverlayApiLike = {
    setUpdateStage?: (stage: string, info?: {
        detail?: string;
        progress?: number | null;
    }) => unknown;
    hide?: (reason?: string) => unknown;
} | null | undefined;
export type VueSfcUpdateOverlayDeps = {
    /** Resolves the live overlay API. Returning null/undefined is treated as "no overlay installed". */
    getOverlay: () => VueOverlayApiLike;
    /** Override the build-time gate for testing. Defaults to reading `__NS_HMR_PROGRESS_OVERLAY_ENABLED__` (or `true` when undefined). */
    overlayEnabled?: boolean;
    /** Time source — exposed so tests can stub deterministically. */
    now?: () => number;
};
export type VueSfcUpdateOverlayRun<TComponent> = {
    /** The changed SFC path as broadcast by the server (e.g. `/src/components/Home.vue`). */
    filePath?: string;
    /** Resolves the component to mount. Returning `null`/`undefined` is treated as "no swap needed" and still completes the overlay. */
    loadComponent: () => Promise<TComponent | null | undefined>;
    /** Performs the view-tree swap once the component is loaded. Return value is intentionally `unknown` (callers like `performResetRoot` return `Promise<boolean>`; we only care about resolution, not the payload). */
    applyComponent: (component: TComponent) => Promise<unknown>;
};
export type VueSfcUpdateOverlayResult = {
    /** True when the overlay reached the 'complete' stage (whether the swap actually ran or was skipped). */
    completed: boolean;
    /** True when `applyComponent` was called and resolved without throwing. */
    swapped: boolean;
    /** Wall-clock duration of the orchestration window. */
    elapsedMs: number;
    /** Captured error from `loadComponent` / `applyComponent`, if any. */
    error?: unknown;
};
export declare function buildSfcLoadingDetail(filePath: string | undefined): string;
export declare function buildSfcRemountDetail(filePath: string | undefined): string;
export declare function buildSfcCompleteDetail(filePath: string | undefined, elapsedMs: number): string;
export declare function buildSfcSkippedDetail(filePath: string | undefined): string;
export declare function buildSfcFailedDetail(filePath: string | undefined): string;
/**
 * Orchestrate the apply-progress overlay around a single Vue SFC
 * registry update.
 *
 * The function never throws — every overlay call is guarded — and
 * always resolves the orchestration even if the underlying load/apply
 * functions reject. Callers can inspect the returned `error` field for
 * diagnostics, but the visual contract is that the user always sees a
 * completed (or hidden) overlay at the end of the call.
 */
export declare function driveVueSfcUpdateOverlay<TComponent>(run: VueSfcUpdateOverlayRun<TComponent>, deps: VueSfcUpdateOverlayDeps): Promise<VueSfcUpdateOverlayResult>;
