export declare const sfcChangedIds: Set<string>;
export declare const sfcArtifactMap: Map<string, string>;
export declare function installNsVueDevShims(): void;
export declare function ensureVueGlobals(): void;
export declare function ensurePiniaOnApp(app: any): void;
export declare function ensureNsVueBootstrap(): void;
export declare function handleVueSfcRegistry(msg: any): void;
export declare function handleVueSfcRegistryUpdate(msg: any, graphVersion: number): Promise<any>;
export declare function recordVuePayloadChanges(changed: any[], graphVersion: number): void;
/**
 * True when the delta for `version` included a `.vue` change. The dep-change
 * propagation in `refreshAfterBatch` uses this to stand down for mixed batches:
 * the SFC registry-update path will already remount with a freshly assembled
 * artifact at this version, which links against the re-imported deps — a second
 * resetRoot from propagation would just double the work (and the flash).
 */
export declare function sfcChangedInVersion(version: number): boolean;
export declare function addSfcMapping(originalPath: string, fileName: string): void;
export declare function buildSfcEvictionUrls(id: string): string[];
export declare function loadSfcComponent(targetVuePath: string): Promise<any | null>;
export declare function getRootForVue(newComponent: any, state: {
    getRootKind: () => 'page' | 'frame';
    setRootKind: (k: 'page' | 'frame') => void;
    getCachedRoot: () => any;
    setCachedRoot: (r: any) => void;
}): any;
/** Install a robust $navigateBack wrapper once that falls back to remounting the
 * original root component if there's no usable Frame history. This keeps dev UX
 * predictable when testing deep links or isolated component mounts.
 */
export declare function ensureBackWrapperInstalled(performResetRoot: (comp: any) => void, getCore: (name: string) => any): void;
