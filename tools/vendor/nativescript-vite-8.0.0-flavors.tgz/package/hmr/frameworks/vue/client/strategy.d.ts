import type { FrameworkClientStrategy, FrameworkClientBatchContext } from '../../../client/framework-client-strategy.js';
import { driveVueSfcUpdateOverlay } from './vue-sfc-update-overlay.js';
import { findNearestSfcBoundaries } from './dep-propagation.js';
/** Injectable seam so the propagation decision tree is unit testable. */
export interface VueDepPropagationDeps {
    findBoundaries: typeof findNearestSfcBoundaries;
    loadComponent: (targetVuePath: string) => Promise<any | null>;
    sfcChangedInVersion: (version: number) => boolean;
    getVersion: () => number;
    driveOverlay: typeof driveVueSfcUpdateOverlay;
}
/**
 * Non-SFC dependency propagation. When a plain `.ts`/`.js` module changes, the
 * shared queue evicts + re-imports it, but the live component instance still
 * holds bindings to the OLD module instance — nothing on the Vue side remounts
 * (the server only emits `ns:vue-sfc-registry-update` for `.vue` edits). Walk
 * the reverse import graph to the nearest `.vue` boundary and remount it the
 * same way the registry-update path does: `loadSfcComponent` re-assembles the
 * SFC at the bumped graph version, whose rewritten static imports resolve to
 * the freshly re-imported dep modules.
 *
 * Returns true when a boundary remount cycle ran (and drove the overlay to
 * 'complete' itself); false when the caller should fall through to the plain
 * overlay-complete frame (no boundary found, mixed batch handled by the
 * registry-update path, or missing context).
 */
export declare function propagateDepChangeToSfcBoundary(drained: string[], ctx: FrameworkClientBatchContext, deps?: VueDepPropagationDeps): Promise<boolean>;
/**
 * Vue's on-device HMR behavior, surfaced as a `FrameworkClientStrategy` so the
 * shared client never references the Vue client module directly. Every method
 * delegates to the existing `vue/client` functions — no behavior change.
 */
export declare const vueClientStrategy: FrameworkClientStrategy;
