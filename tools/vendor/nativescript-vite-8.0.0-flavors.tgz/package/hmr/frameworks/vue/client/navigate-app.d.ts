export declare function normalizeComponent(input: any, nameHint?: string): any;
/** Expose deterministic app navigation globally so /ns/rt can guarantee single-path navigation. */
export declare function installVueNavigateUsingApp(): void;
