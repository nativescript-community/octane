import { getCore, getCurrentApp, graph, invalidateModulesByUrls, normalizeSpec, resolveHmrHttpOrigin, safeDynImport, safeReadDefault, setCurrentApp } from '../../../client/utils.js';
import { getGlobalScope } from '../../../shared/runtime/global-scope.js';
import { resolveVendorModule } from '../../../shared/runtime/vendor-resolve.js';
import { findSfcAncestors } from './dep-propagation.js';
const APP_VIRTUAL_WITH_SLASH = (() => {
    // Define substitution does not reach this raw-served file; prefer the
    // globalThis seed from the entry's defines-seed module ('app/'-rooted
    // projects would otherwise get the wrong '/src' default).
    const root = (typeof __NS_APP_ROOT_VIRTUAL__ === 'string' && __NS_APP_ROOT_VIRTUAL__) || (typeof getGlobalScope().__NS_APP_ROOT_VIRTUAL__ === 'string' && getGlobalScope().__NS_APP_ROOT_VIRTUAL__) || '/src';
    return root.replace(/\/+$/, '') + '/';
})();
// Optional runtime knob: allow disabling assembler path in favor of variant-only flow
const DISABLE_ASM = !!globalThis.__NS_HMR_DISABLE_ASM__;
// Module-scoped state to avoid leaking into globalThis
let nsVueInitDone = false; // nativescript-vue init guard
let nsStartDone = false; // start() guard
// Track SFC changes by graph version to prioritize SFC root reset before non-Vue evaluation
let sfcChangedVersion = null;
export const sfcChangedIds = new Set();
// Map of original SFC source absolute/relative path -> compiled sfc-*.mjs filename written to Documents
export const sfcArtifactMap = new Map();
// Install dev shims for nativescript-vue navigation to observe and (optionally) rescue
export function installNsVueDevShims() {
    try {
        const nv = resolveVendorModule('nativescript-vue');
        const rh = resolveVendorModule('nativescript-vue/dist/runtimeHelpers');
        const wrap = (orig, label) => {
            if (typeof orig !== 'function')
                return orig;
            if (orig.__ns_wrapped__)
                return orig; // idempotent
            const wrapped = function __ns_nav_wrap(component, params) {
                try {
                    if (__NS_ENV_VERBOSE__) {
                        console.log('[diag][nv][navigateTo]', {
                            from: label,
                            hasComp: !!component,
                            paramKeys: Object.keys(params || {}),
                        });
                    }
                    // eslint-disable-next-line prefer-rest-params -- forwards all args verbatim to the patched original (arity-preserving)
                    return orig.apply(this, arguments);
                }
                catch (e) {
                    console.warn('[diag][nv][navigateTo][error]', (e && e.message) || e);
                    try {
                        // Rescue path: attempt navigation via authoritative app Frame
                        return globalThis.__nsNavigateUsingApp?.(component, params);
                    }
                    catch { }
                    throw e;
                }
            };
            try {
                wrapped.__ns_wrapped__ = true;
            }
            catch { }
            return wrapped;
        };
        if (nv) {
            try {
                if (nv.navigateTo)
                    nv.navigateTo = wrap(nv.navigateTo, 'nv');
                if (nv.$navigateTo)
                    nv.$navigateTo = wrap(nv.$navigateTo, '$nv');
            }
            catch { }
        }
        if (rh) {
            try {
                if (rh.navigateTo)
                    rh.navigateTo = wrap(rh.navigateTo, 'rh');
            }
            catch { }
        }
    }
    catch { }
}
// Ensure Vue runtime global functions exist before evaluating SFC artifacts that rely on globalThis.* indirections.
export function ensureVueGlobals() {
    try {
        const g = globalThis;
        const vueAlready = g.defineComponent && g.resolveComponent && g.createVNode;
        // Prefer nativescript-vue first so createApp has .start and NSVRoot is available
        const nvMod = resolveVendorModule('nativescript-vue');
        let vueMod = resolveVendorModule('vue') ?? resolveVendorModule('@vue/runtime-core');
        const chosenMod = nvMod || vueMod;
        if (!chosenMod)
            return;
        // No standalone vue realm available: nativescript-vue re-exports the runtime API.
        if (!vueMod)
            vueMod = nvMod;
        // Polyfill essential runtime helpers often imported from 'vue' by compiled SFC render code
        try {
            const polyNormalizeClass = (val) => {
                if (!val)
                    return '';
                if (typeof val === 'string')
                    return val;
                if (Array.isArray(val))
                    return val.map(polyNormalizeClass).filter(Boolean).join(' ');
                if (typeof val === 'object')
                    return Object.keys(val)
                        .filter((k) => !!val[k])
                        .join(' ');
                return '';
            };
            const polyNormalizeStyle = (val) => {
                if (!val)
                    return null;
                if (Array.isArray(val))
                    return val.reduce((acc, v) => Object.assign(acc, polyNormalizeStyle(v) || {}), {});
                if (typeof val === 'string') {
                    const out = {};
                    val.split(';').forEach((pair) => {
                        const idx = pair.indexOf(':');
                        if (idx > -1) {
                            const k = pair.slice(0, idx).trim();
                            const v = pair.slice(idx + 1).trim();
                            if (k)
                                out[k] = v;
                        }
                    });
                    return out;
                }
                if (typeof val === 'object')
                    return { ...val };
                return null;
            };
            const polyToDisplayString = (val) => {
                try {
                    if (val == null)
                        return '';
                    if (typeof val === 'object')
                        return JSON.stringify(val);
                    return String(val);
                }
                catch {
                    return String(val);
                }
            };
            const vmAny = vueMod;
            if (vmAny && typeof vmAny === 'object') {
                if (!('normalizeClass' in vmAny))
                    vmAny.normalizeClass = polyNormalizeClass;
                if (!('normalizeStyle' in vmAny))
                    vmAny.normalizeStyle = polyNormalizeStyle;
                if (!('toDisplayString' in vmAny))
                    vmAny.toDisplayString = polyToDisplayString;
            }
            // Do not assign polyfills onto globalThis; compiled helpers are wired via alias() below
        }
        catch { }
        const runtime = (chosenMod && (chosenMod.default ?? chosenMod)) || chosenMod;
        const { defineComponent, resolveComponent, createVNode, createTextVNode, createCommentVNode, 
        // We deliberately pull createApp here but assign it globally below to avoid mixing module instances
        createApp: _createApp, Fragment, withCtx, openBlock, createBlock, createElementVNode, createElementBlock, renderSlot, mergeProps, toHandlers, renderList, normalizeProps, guardReactiveProps, withDirectives, resolveDirective, withModifiers, withKeys, isRef, ref, shallowRef, unref, computed, onMounted, onBeforeUnmount, onUnmounted, watch, nextTick, vShow, } = (runtime || {});
        // Assign only if not already set to avoid clobbering potentially patched versions.
        if (!vueAlready) {
            g.defineComponent || (g.defineComponent = defineComponent);
            g.resolveComponent || (g.resolveComponent = resolveComponent);
            g.createVNode || (g.createVNode = createVNode);
            g.createTextVNode || (g.createTextVNode = createTextVNode);
            g.createCommentVNode || (g.createCommentVNode = createCommentVNode);
            g.Fragment || (g.Fragment = Fragment);
            // Critical: ensure createApp and runtime-bound classes/functions reference the same module instance
            try {
                g.createApp || (g.createApp = _createApp || runtime?.createApp || nvMod?.createApp || vueMod?.createApp);
            }
            catch { }
            try {
                g.NSVRoot || (g.NSVRoot = runtime?.NSVRoot || nvMod?.NSVRoot || vueMod?.NSVRoot);
            }
            catch { }
            try {
                g.registerElement || (g.registerElement = runtime?.registerElement || nvMod?.registerElement || vueMod?.registerElement);
            }
            catch { }
            try {
                g.start || (g.start = runtime?.start || nvMod?.start || vueMod?.start);
            }
            catch { }
            g.withCtx || (g.withCtx = withCtx);
            g.openBlock || (g.openBlock = openBlock);
            g.createBlock || (g.createBlock = createBlock);
            g.createElementVNode || (g.createElementVNode = createElementVNode || createVNode);
            g.createElementBlock || (g.createElementBlock = createElementBlock || createBlock);
            g.renderSlot || (g.renderSlot = renderSlot);
            g.mergeProps || (g.mergeProps = mergeProps);
            g.toHandlers || (g.toHandlers = toHandlers);
            g.renderList || (g.renderList = renderList);
            g.normalizeProps || (g.normalizeProps = normalizeProps);
            g.guardReactiveProps || (g.guardReactiveProps = guardReactiveProps);
            g.withDirectives || (g.withDirectives = withDirectives);
            g.resolveDirective || (g.resolveDirective = resolveDirective);
            g.withModifiers || (g.withModifiers = withModifiers);
            g.withKeys || (g.withKeys = withKeys);
            g.isRef || (g.isRef = isRef);
            g.ref || (g.ref = ref);
            g.shallowRef || (g.shallowRef = shallowRef);
            g.unref || (g.unref = unref);
            g.computed || (g.computed = computed);
            g.onMounted || (g.onMounted = onMounted);
            g.onBeforeUnmount || (g.onBeforeUnmount = onBeforeUnmount);
            g.onUnmounted || (g.onUnmounted = onUnmounted);
            g.watch || (g.watch = watch);
            g.nextTick || (g.nextTick = nextTick);
            // Built-in directives
            g.vShow || (g.vShow = vShow);
            // Create underscore aliases to satisfy compiled helper identifiers (e.g. _renderSlot)
            try {
                const alias = (from, to) => {
                    try {
                        const val = g[from];
                        const key = to || '_' + from;
                        if (val && !(key in g))
                            g[key] = val;
                    }
                    catch { }
                };
                alias('renderSlot');
                alias('normalizeClass');
                alias('normalizeStyle');
                alias('toDisplayString');
                alias('openBlock');
                alias('createElementBlock');
                alias('createElementVNode');
                alias('createVNode');
                alias('createBlock');
                alias('normalizeProps');
                alias('guardReactiveProps');
                alias('mergeProps');
                alias('toHandlers');
                alias('withCtx');
                alias('withDirectives');
                alias('resolveComponent');
                alias('resolveDirective');
                alias('withModifiers');
                alias('withKeys');
                alias('isRef');
                alias('unref');
                alias('vShow');
                alias('Fragment', '_Fragment');
            }
            catch { }
        }
        // Navigation helpers: no longer patched onto globalThis; use __nsNavigateUsingApp via imports or app instance
        // If Vue was already present originally we still ensure nav helpers; that's why we delayed early return.
    }
    catch { }
}
// Ensure Pinia is installed on the given Vue app during HMR remounts.
// We keep a singleton Pinia instance on globalThis to preserve store state across resets when possible.
export function ensurePiniaOnApp(app) {
    try {
        if (!app || typeof app.use !== 'function')
            return;
        const g = getGlobalScope();
        // If this app already has a Pinia provide, skip
        try {
            const prov = app?._context?.provides;
            if (prov) {
                const hasString = Object.prototype.hasOwnProperty.call(prov, 'pinia');
                const knownSym = g.__NS_PINIA_SYMBOL__;
                const hasKnownSym = knownSym ? Object.prototype.hasOwnProperty.call(prov, knownSym) : false;
                const hasSym = hasKnownSym || Object.getOwnPropertySymbols(prov).some((s) => /pinia/i.test(s.description || ''));
                if (hasString || hasSym)
                    return;
            }
        }
        catch { }
        // If a global Pinia instance is already present, just use it and avoid importing new copies
        if (g.__NS_HMR_PINIA__) {
            try {
                app.use(g.__NS_HMR_PINIA__);
            }
            catch { }
            // Attempt to set active pinia if API is available
            try {
                const piniaMod = resolveVendorModule('pinia');
                const resolved = (piniaMod && (piniaMod.default ?? piniaMod)) || null;
                const setActivePinia = resolved?.setActivePinia;
                if (typeof setActivePinia === 'function')
                    setActivePinia(g.__NS_HMR_PINIA__);
            }
            catch { }
            return;
        }
        // Prefer vendor registry/require to load 'pinia'
        const piniaMod = resolveVendorModule('pinia');
        if (!piniaMod)
            return;
        const resolved = (piniaMod && (piniaMod.default ?? piniaMod)) || null;
        const createPinia = resolved?.createPinia;
        const setActivePinia = resolved?.setActivePinia;
        if (typeof createPinia !== 'function')
            return;
        // Reuse across HMR cycles
        const pinia = (g.__NS_HMR_PINIA__ || (g.__NS_HMR_PINIA__ = createPinia()));
        try {
            app.use(pinia);
        }
        catch { }
        try {
            if (typeof setActivePinia === 'function')
                setActivePinia(pinia);
        }
        catch { }
    }
    catch { }
}
// Prefer nativescript-vue's own bootstrap to set up element registry and built-ins
export function ensureNsVueBootstrap() {
    try {
        if (nsVueInitDone)
            return;
        // Try full init, which should register core elements and built-in components
        try {
            const nv = resolveVendorModule('nativescript-vue/dist/nativescript');
            const init = (nv && (nv.init || nv.default?.init)) || undefined;
            if (typeof init === 'function') {
                init();
                nsVueInitDone = true;
                if (__NS_ENV_VERBOSE__)
                    console.log('[hmr-client] nativescript-vue init() executed');
                return;
            }
        }
        catch { }
        // Fallback: register core elements only
        try {
            const elems = resolveVendorModule('nativescript-vue/dist/nativescript/elements');
            const fn = (elems && (elems.registerCoreElements || elems.default?.registerCoreElements)) || undefined;
            if (typeof fn === 'function') {
                fn();
                if (__NS_ENV_VERBOSE__)
                    console.log('[hmr-client] registerCoreElements executed');
            }
        }
        catch { }
    }
    catch { }
}
// Install built-in components from nativescript-vue onto the given app (idempotent)
function installBuiltInComponentsOnApp(app) {
    try {
        if (!app || typeof app.component !== 'function')
            return;
        const comps = resolveVendorModule('nativescript-vue/dist/components');
        const built = comps && (comps.BUILT_IN_COMPONENTS || comps.default?.BUILT_IN_COMPONENTS);
        if (!built || typeof built !== 'object')
            return;
        const ctx = app._context;
        const registered = new Set(Object.keys((ctx && ctx.components) || {}));
        for (const [name, def] of Object.entries(built)) {
            try {
                if (!registered.has(name)) {
                    app.component(name, def);
                    registered.add(name);
                }
            }
            catch { }
        }
        if (__NS_ENV_VERBOSE__) {
            console.log('[hmr-client] installed built-in components:', Array.from(registered).join(','));
        }
    }
    catch { }
}
function bridgePiniaProvides(app, existingApp) {
    try {
        const g = getGlobalScope();
        if (!app || !app._context)
            return;
        const newProv = app._context.provides || (app._context.provides = {});
        // Determine pinia instance to bind
        let piniaInst = g.__NS_HMR_PINIA__;
        if (!piniaInst)
            piniaInst = newProv['pinia'];
        if (!piniaInst && existingApp)
            piniaInst = existingApp?._context?.provides?.['pinia'];
        if (!piniaInst && existingApp) {
            const syms = Object.getOwnPropertySymbols(existingApp?._context?.provides || {});
            for (const s of syms) {
                if (/pinia/i.test(s.description || '')) {
                    piniaInst = existingApp._context.provides[s];
                    break;
                }
            }
        }
        if (!piniaInst)
            return;
        // Collect candidate symbols to bind
        const candidates = [];
        try {
            const known = g.__NS_PINIA_SYMBOL__;
            if (known && typeof known === 'symbol')
                candidates.push(known);
        }
        catch { }
        try {
            const vmod = resolveVendorModule('pinia');
            const resolved = (vmod && (vmod.default ?? vmod)) || vmod;
            const vendorSym = resolved?.piniaSymbol || vmod?.piniaSymbol;
            if (vendorSym && typeof vendorSym === 'symbol')
                candidates.push(vendorSym);
            // Also set active pinia on vendor module if possible
            const setActivePinia = resolved?.setActivePinia || vmod?.setActivePinia;
            if (typeof setActivePinia === 'function') {
                try {
                    setActivePinia(piniaInst);
                }
                catch { }
            }
        }
        catch { }
        try {
            const oldProv = existingApp?._context?.provides || {};
            const oldSyms = Object.getOwnPropertySymbols(oldProv || {});
            for (const s of oldSyms) {
                if (/pinia/i.test(s.description || ''))
                    candidates.push(s);
            }
        }
        catch { }
        // De-duplicate symbols
        const uniq = [];
        for (const s of candidates) {
            if (typeof s === 'symbol' && !uniq.includes(s))
                uniq.push(s);
        }
        // Bind all symbols to the same instance
        for (const s of uniq) {
            try {
                newProv[s] = piniaInst;
            }
            catch { }
        }
        // Also ensure string key for any code that looks up string provides
        try {
            if (!newProv['pinia'])
                newProv['pinia'] = piniaInst;
        }
        catch { }
        try {
            g.__NS_PINIA_SYMBOL__ || (g.__NS_PINIA_SYMBOL__ = uniq[0] || undefined);
        }
        catch { }
        if (__NS_ENV_VERBOSE__) {
            try {
                const syms = Object.getOwnPropertySymbols(newProv).map((s) => s.description || String(s));
                console.log('[hmr-client] bridged pinia provides', {
                    stringKey: !!newProv['pinia'],
                    symbols: syms,
                });
            }
            catch { }
        }
    }
    catch { }
}
export function handleVueSfcRegistry(msg) {
    try {
        const entries = msg.entries || [];
        // Mapping-only: record presence for quick readiness checks (no disk writes in HTTP mode)
        for (const e of entries) {
            addSfcMapping(e.path, e.fileName);
        }
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr][sfc-registry] entries=', entries.length, 'map size', sfcArtifactMap.size);
    }
    catch (e) {
        console.warn('[hmr-client][sfc-registry] install failed', e);
    }
}
/**
 * A component that declares required props can't be mounted as a standalone HMR
 * root — nothing supplies them, so its render throws (white screen). Detects the
 * object-form `props` Vue itself reads for the "Missing required prop" warning.
 */
function hmrComponentHasRequiredProps(comp) {
    try {
        const props = comp && comp.props;
        if (!props || typeof props !== 'object' || Array.isArray(props))
            return false;
        for (const key of Object.keys(props)) {
            const def = props[key];
            if (def && typeof def === 'object' && def.required === true)
                return true;
        }
    }
    catch { }
    return false;
}
// ── HMR replace-navigation window ────────────────────────────────────────────
// An in-place SFC reload (`__VUE_HMR_RUNTIME__.reload`) unmounts the old
// component subtree and mounts the fresh one. When the component's root is a
// `<Page>` hosted by a `<Frame>`, nativescript-vue's Frame nodeOps `insert`
// calls `frame.navigate({ create })` — a forward navigation that PUSHES a new
// backstack entry. Every HMR apply would grow the backstack and surface a Back
// button in the ActionBar (tapping it walks back through stale pre-edit
// renders). While a reload flush is in flight, convert those page navigations
// into `replacePage` (core's replace-navigation, the same primitive LiveSync
// uses) so the fresh Page takes the current entry's place and the user's real
// backstack is preserved untouched.
let hmrReplaceNavInstalled = false;
let hmrReplaceNavWindowDepth = 0;
function installHmrFrameReplaceNavigation() {
    if (hmrReplaceNavInstalled)
        return true;
    try {
        const FrameCtor = getCore('Frame');
        const proto = FrameCtor?.prototype;
        if (!proto || typeof proto.navigate !== 'function' || typeof proto.replacePage !== 'function')
            return false;
        const originalNavigate = proto.navigate;
        proto.navigate = function (entry) {
            // Only page-entry navigations on a frame that is already showing a
            // page are rewritten — first mounts and user-driven navigations
            // (outside the window) flow through untouched.
            if (hmrReplaceNavWindowDepth > 0 && entry && typeof entry === 'object' && typeof entry.create === 'function' && this.currentPage) {
                try {
                    if (__NS_ENV_VERBOSE__)
                        console.log('[hmr][vue] reload window: replacePage instead of forward navigate');
                    this.replacePage({ create: entry.create, animated: false });
                    return;
                }
                catch (e) {
                    console.warn('[hmr][vue] replacePage during reload failed; falling back to navigate', e);
                }
            }
            // eslint-disable-next-line prefer-rest-params -- forwards all args verbatim to the patched original (arity-preserving)
            return originalNavigate.apply(this, arguments);
        };
        hmrReplaceNavInstalled = true;
        return true;
    }
    catch {
        return false;
    }
}
function openHmrReplaceNavWindow() {
    if (!installHmrFrameReplaceNavigation())
        return () => { };
    hmrReplaceNavWindowDepth++;
    let closed = false;
    return () => {
        if (closed)
            return;
        closed = true;
        hmrReplaceNavWindowDepth = Math.max(0, hmrReplaceNavWindowDepth - 1);
    };
}
/**
 * In-place Vue HMR. The assembled SFC stamps a stable `comp.__hmrId`, so Vue's
 * registerHMR has a record for every mounted instance. Calling the real
 * `__VUE_HMR_RUNTIME__.reload(id, newComp)` re-renders just those instances in
 * place — preserving the App.vue shell (drawer, nav, router), current route, and
 * scroll — instead of a whole-tree resetRootView. Returns false (→ resetRoot
 * fallback) when the real runtime is absent (stub/prod build), the component has
 * no id, or reload throws. A reload that matches no live instances is a no-op
 * (component not currently displayed); the caller treats that as handled.
 */
function tryInPlaceVueReload(comp) {
    try {
        const rt = getGlobalScope().__VUE_HMR_RUNTIME__;
        const id = comp && comp.__hmrId;
        if (!rt || typeof rt.reload !== 'function' || !id)
            return false;
        // Vue queues the remount on its scheduler (microtask flush) — the
        // Frame navigation happens inside that flush, not synchronously in
        // reload(). Hold the replace-navigation window through the flush:
        // nextTick resolves after the job queue drains; the timeout is a
        // safety net when nextTick is unavailable.
        const closeWindow = openHmrReplaceNavWindow();
        try {
            rt.reload(id, comp);
        }
        catch (e) {
            closeWindow();
            throw e;
        }
        try {
            const nextTick = getGlobalScope().nextTick;
            if (typeof nextTick === 'function') {
                nextTick(() => closeWindow());
            }
        }
        catch { }
        setTimeout(closeWindow, 500);
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr][vue] in-place reload', id);
        return true;
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr][vue] in-place reload failed; resetRoot fallback', e);
        return false;
    }
}
export async function handleVueSfcRegistryUpdate(msg, graphVersion) {
    try {
        if (typeof msg.path === 'string' && /\.vue$/i.test(msg.path)) {
            // The registry update is the authoritative signal that this SFC changed
            // for the announced version — record it unconditionally so remounts are
            // resilient to out-of-order or dropped delta delivery.
            try {
                sfcChangedVersion = typeof msg.version === 'number' ? msg.version : graphVersion;
                sfcChangedIds.add(String(msg.path).split('?')[0]);
            }
            catch { }
            try {
                ensureVueGlobals();
                const changedPath = String(msg.path);
                // Default: remount the SFC that changed, so editing a page reflects
                // immediately even if a different page is displayed.
                let comp = await loadSfcComponent(changedPath);
                // Preferred path: patch the changed component's mounted instances in
                // place (App.vue shell, route, scroll all survive). Returning null tells
                // the overlay no resetRootView is needed.
                if (tryInPlaceVueReload(comp)) {
                    return null;
                }
                // Fallback (real Vue HMR runtime unavailable): a child SFC with required
                // props cannot be a standalone root — mounting it bare crashes (missing
                // props → white screen). Walk up to the nearest mountable ancestor (its
                // hosting page) and remount that; the child's artifact set was evicted
                // above, so the ancestor's re-assembly links the edited child and it
                // re-renders with props.
                if (comp && hmrComponentHasRequiredProps(comp)) {
                    const ancestors = findSfcAncestors(changedPath, graph);
                    for (const ancestor of ancestors) {
                        const ancestorComp = await loadSfcComponent(ancestor);
                        if (ancestorComp && !hmrComponentHasRequiredProps(ancestorComp)) {
                            if (__NS_ENV_VERBOSE__)
                                console.log('[hmr][vue] child SFC needs props; remounting nearest mountable ancestor', { changed: changedPath, ancestor });
                            comp = ancestorComp;
                            break;
                        }
                    }
                }
                return comp;
            }
            catch (e) {
                console.warn('[hmr-client] update path failed for', msg.path, e);
            }
        }
        return;
    }
    catch (e) {
        console.warn('[hmr-client][sfc-registry] update failed', e);
    }
}
export function recordVuePayloadChanges(changed, graphVersion) {
    // Record .vue changes seen in this delta
    let sawVue = false;
    for (const m of changed) {
        if (m && typeof m.id === 'string' && /\.vue$/i.test(m.id)) {
            sfcChangedIds.add(m.id);
            sawVue = true;
        }
    }
    if (sawVue)
        sfcChangedVersion = graphVersion;
}
/**
 * True when the delta for `version` included a `.vue` change. The dep-change
 * propagation in `refreshAfterBatch` uses this to stand down for mixed batches:
 * the SFC registry-update path will already remount with a freshly assembled
 * artifact at this version, which links against the re-imported deps — a second
 * resetRoot from propagation would just double the work (and the flash).
 */
export function sfcChangedInVersion(version) {
    return sfcChangedVersion != null && sfcChangedVersion === version && sfcChangedIds.size > 0;
}
// Map a graph id (possibly a .vue source path) to actual import spec
export function addSfcMapping(originalPath, fileName) {
    try {
        if (!originalPath || !fileName)
            return;
        const base = originalPath.split('?')[0];
        const norm = normalizeSpec(base);
        // Also derive a relative variant if under app root to handle lookups that slice to that portion
        let rel = norm;
        const srcIdx = norm.indexOf(APP_VIRTUAL_WITH_SLASH);
        if (srcIdx !== -1)
            rel = norm.slice(srcIdx);
        sfcArtifactMap.set(norm, fileName);
        if (rel !== norm)
            sfcArtifactMap.set(rel, fileName);
    }
    catch { }
}
// Build explicit SFC variant URL (script/template). Always preserves the
// variant query. CANONICAL (unversioned): module identity is the URL;
// freshness comes from the eviction in `evictSfcArtifacts` below.
function resolveSfcVariantSpec(id, type) {
    const origin = resolveHmrHttpOrigin();
    const base = id.split('?')[0];
    if (!origin)
        return base + `?vue&type=${type}`;
    const safePath = base.startsWith('/') ? base : '/' + base;
    return origin + '/ns/sfc' + safePath + `?vue&type=${type}`;
}
// Resolve deterministic SFC assembler ESM module (canonical, unversioned).
function resolveSfcAssemblerSpec(id) {
    const origin = resolveHmrHttpOrigin();
    const base = id.split('?')[0];
    if (!origin)
        return base; // fallback: device will likely fail; origin should be available in dev
    const safePath = base.startsWith('/') ? base : '/' + base;
    let url = origin + '/ns/asm' + `?path=${encodeURIComponent(safePath)}`;
    try {
        if (globalThis.__NS_HMR_ASM_DIAG__) {
            url += '&diag=1';
        }
    }
    catch { }
    return url;
}
// The full SFC artifact URL set for one `.vue` path — every URL shape the
// device may hold a module record under for this component:
//   - the assembler module (dynamic loads + full-SFC delegation target)
//   - the assembler's `mode=inline` twin (static child imports inside a
//     parent's assembled module)
//   - the script/template variants (variant assembly + asm fallbacks)
//   - the full `/ns/sfc<path>` delegation module (static `.vue` imports
//     rewritten by the server inside `/ns/m` modules)
export function buildSfcEvictionUrls(id) {
    const origin = resolveHmrHttpOrigin();
    if (!origin)
        return [];
    const base = id.split('?')[0];
    const safePath = base.startsWith('/') ? base : '/' + base;
    const asmUrl = origin + '/ns/asm' + `?path=${encodeURIComponent(safePath)}`;
    return [asmUrl, asmUrl + '&mode=inline', origin + '/ns/sfc' + safePath + '?vue&type=script', origin + '/ns/sfc' + safePath + '?vue&type=template', origin + '/ns/sfc' + safePath];
}
// Evict every module record for this SFC's artifact set so the re-imports in
// `loadSfcComponent` fetch fresh content. ns:module `invalidateModules` drops the
// V8 registry entries AND arms the
// bust-next-fetch nonce that defeats the OS HTTP cache — the same freshness
// protocol `/ns/m` modules use (URLs never vary; eviction drives updates).
// Soft-fail: on runtimes without the eviction primitive we still re-import
// (worst case the device serves the cached artifact — same as any other
// module type on such a runtime).
function evictSfcArtifacts(id) {
    try {
        const urls = buildSfcEvictionUrls(id);
        if (urls.length)
            invalidateModulesByUrls(urls);
    }
    catch (e) {
        try {
            console.warn('[hmr][vue] SFC artifact eviction failed for', id, e);
        }
        catch { }
    }
}
// Safely load a component for a .vue SFC. Prefer deterministic assembler first to avoid
// any variant-compile or TDZ flakiness; only fall back to variant assembly if needed.
export async function loadSfcComponent(targetVuePath) {
    // Minimal mode removed: always go through deterministic assembler + device reset
    // Ensure Vue globals exist BEFORE evaluating variant modules; their top-level aliasing reads globalThis.* once.
    ensureVueGlobals();
    // Evict this SFC's artifact URL set BEFORE any import below. Every load
    // through here happens because fresh content is wanted (a `.vue` edit, an
    // ancestor remount, or a dep-change boundary re-assembly), and the URLs
    // are stable across saves — without the eviction, `import()` would return
    // the cached (pre-edit) module records.
    evictSfcArtifacts(targetVuePath);
    // Prefer deterministic assembler first so AST normalization (including nav helpers) always applies.
    try {
        if (!DISABLE_ASM) {
            const asmMod = await safeDynImport(resolveSfcAssemblerSpec(targetVuePath));
            const asmComp = asmMod?.default ?? asmMod;
            if (asmComp && typeof asmComp === 'object') {
                if (__NS_ENV_VERBOSE__)
                    console.log('[hmr][vue-reset][diag] using assembler-first component');
                return asmComp;
            }
        }
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr][vue-reset][diag] assembler-first failed; trying variants', e);
    }
    // 1) Variant assembly (script then template) – closest to browser behavior
    try {
        // Import script variant FIRST to avoid TDZ due to cyclic evaluation between script/template.
        const scriptMod = await safeDynImport(resolveSfcVariantSpec(targetVuePath, 'script'));
        // Ensure script default is readable before importing the template; this enforces a stable order.
        const base = await safeReadDefault(scriptMod);
        // Now import the template render implementation
        const templateMod = await safeDynImport(resolveSfcVariantSpec(targetVuePath, 'template'));
        if (__NS_ENV_VERBOSE__) {
            const sKeys = scriptMod ? Object.keys(scriptMod).join(',') : '<none>';
            const tKeys = templateMod ? Object.keys(templateMod).join(',') : '<none>';
            console.log('[hmr][vue-reset][diag] variant-imports', targetVuePath, 'script.keys=', sKeys, 'template.keys=', tKeys);
            console.log('[hmr][vue-reset][diag] scriptMod:', scriptMod);
            console.log('[hmr][vue-reset][diag] templateMod:', {
                render: typeof templateMod?.render,
            });
        }
        // Only use variant assembly when the script provides a real component options object.
        const render = templateMod?.render;
        const scriptExports = scriptMod || {};
        const exportKeys = Object.keys(scriptExports).filter((k) => k !== 'default' && k !== '__esModule');
        if (base && typeof base === 'object') {
            // If variant template didn't produce a render, try assembler as a targeted fallback.
            if (!render) {
                try {
                    if (__NS_ENV_VERBOSE__)
                        console.log('[hmr][vue-reset][diag] no render from template variant; attempting assembler for', targetVuePath);
                    const asmMod = await safeDynImport(resolveSfcAssemblerSpec(targetVuePath));
                    const asmComp = asmMod?.default ?? asmMod;
                    if (asmComp && typeof asmComp === 'object' && typeof asmComp.render === 'function') {
                        try {
                            base.render = asmComp.render;
                        }
                        catch { }
                    }
                }
                catch (e) {
                    if (__NS_ENV_VERBOSE__)
                        console.warn('[hmr][vue-reset][diag] assembler no-render fallback failed', e);
                }
            }
            else {
                try {
                    base.render = render;
                }
                catch { }
            }
            // Merge named exports (likely locally-declared components) into the component's components map
            if (exportKeys.length) {
                try {
                    base.components = base.components || {};
                    for (const k of exportKeys) {
                        try {
                            base.components[k] = scriptExports[k];
                        }
                        catch { }
                    }
                }
                catch { }
            }
            if (__NS_ENV_VERBOSE__) {
                console.log('[hmr][vue-reset][diag] assembled.component (from script default) keys=', Object.keys(base).join(','), 'has.render=', !!base.render, 'components=', Object.keys(base.components || {}).join(','));
            }
            return base;
        }
        // If script default is absent (common with <script setup> or named exports), but we have a template render,
        // prefer loading the full SFC first if the script provided no named exports — the full SFC may contain
        // compiled metadata (local components, hoisted helpers) that variant assembly can't reconstruct.
        if (!base && typeof render === 'function') {
            if (!exportKeys.length) {
                if (__NS_ENV_VERBOSE__)
                    console.log('[hmr][vue-reset][diag] no script exports detected; attempting assembler import for', targetVuePath);
                try {
                    const asm = await safeDynImport(resolveSfcAssemblerSpec(targetVuePath));
                    const compAsm = asm?.default ?? asm;
                    if (compAsm && typeof compAsm === 'object') {
                        if (__NS_ENV_VERBOSE__)
                            console.log('[hmr][vue-reset][diag] assembler import succeeded and will be used');
                        return compAsm;
                    }
                }
                catch (e) {
                    if (__NS_ENV_VERBOSE__)
                        console.warn('[hmr][vue-reset][diag] assembler import failed, will synthesize as fallback', e);
                }
            }
            // Synthesize a minimal component and attach named exports as local components so template resolveComponent works.
            try {
                ensureVueGlobals();
                const comp = getGlobalScope().defineComponent
                    ? getGlobalScope().defineComponent({
                        name: targetVuePath.split('/').pop() || 'AnonymousSFC',
                        render,
                    })
                    : {
                        name: targetVuePath.split('/').pop() || 'AnonymousSFC',
                        render,
                    };
                if (exportKeys.length) {
                    try {
                        comp.components = comp.components || {};
                        for (const k of exportKeys) {
                            try {
                                comp.components[k] = scriptExports[k];
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
                if (__NS_ENV_VERBOSE__) {
                    console.log('[hmr][vue-reset][diag] synthesized.component keys=', Object.keys(comp).join(','), 'components=', Object.keys(comp.components || {}).join(','));
                }
                return comp;
            }
            catch (e) {
                if (__NS_ENV_VERBOSE__)
                    console.warn('[hmr][vue-reset][diag] synthesize component failed', e);
            }
        }
        // Otherwise fall through to full SFC import.
    }
    catch (e2) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr][vue-reset][variant-import] failed; will try full SFC', targetVuePath, e2);
    }
    // 2) Final fallback: assembler import (after a short delay to let dependents settle)
    try {
        if (DISABLE_ASM)
            throw new Error('asm disabled by __NS_HMR_DISABLE_ASM__');
        await new Promise((r) => setTimeout(r, 10));
        const mod = await safeDynImport(resolveSfcAssemblerSpec(targetVuePath));
        try {
            const comp = await safeReadDefault(mod);
            if (comp)
                return comp;
        }
        catch (err) {
            if (__NS_ENV_VERBOSE__)
                console.warn('[hmr][vue-reset][asm-import-default-read] error', targetVuePath, err);
        }
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr][vue-reset][asm-import] failed', targetVuePath, e);
    }
    // Final soft fallback: return a minimal placeholder so rerender can proceed and surface UI
    return null;
}
export function getRootForVue(newComponent, state) {
    const t0 = Date.now();
    if (__NS_ENV_VERBOSE__)
        console.log('[hmr-client] [createRoot] begin');
    ensureVueGlobals();
    const g = getGlobalScope();
    const AppFactory = g.createApp;
    let RootCtor = g.NSVRoot;
    // Hygiene: unmount any existing app instance to avoid duplicate lifecycle hooks
    try {
        const existing = (getCurrentApp() || g.__NS_VUE_APP__);
        if (existing && typeof existing.unmount === 'function') {
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] unmounting existing app before remount');
            try {
                existing.unmount();
            }
            catch { }
        }
    }
    catch { }
    try {
        if (!RootCtor) {
            const domMod = resolveVendorModule('nativescript-vue/dist/dom');
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] NS DOM', domMod ? 'resolved from vendor chain' : 'unresolved');
            if (domMod) {
                const nsDom = (domMod && (domMod.default ?? domMod)) || domMod;
                const ctor = nsDom?.NSVRoot || (nsDom?.default && nsDom.default.NSVRoot) || domMod?.NSVRoot;
                if (ctor)
                    RootCtor = ctor;
            }
        }
    }
    catch { }
    const existingApp = getCurrentApp() || g.__NS_VUE_APP__;
    try {
        ensureNsVueBootstrap();
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] ensured NS-Vue bootstrap');
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] ensureNsVueBootstrap failed', e);
    }
    try {
        if (typeof g.start === 'function' && !nsStartDone) {
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] invoking global start()');
            g.start();
            nsStartDone = true;
        }
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] start() failed', e);
    }
    if (!RootCtor)
        throw new Error('NSVRoot constructor unavailable during HMR remount');
    let app;
    try {
        const mk = globalThis.__NS_HMR_CREATE_APP__;
        if (typeof mk === 'function') {
            app = mk(newComponent);
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] app created via custom factory');
        }
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] custom app factory failed', e);
    }
    if (!app) {
        app = AppFactory(newComponent);
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] app created via createApp');
    }
    try {
        const rh = resolveVendorModule('nativescript-vue/dist/runtimeHelpers');
        const setRootApp = rh && (rh.setRootApp || rh.default?.setRootApp);
        if (typeof setRootApp === 'function') {
            setRootApp(app);
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] runtimeHelpers.setRootApp applied');
        }
        try {
            const nv = resolveVendorModule('nativescript-vue');
            const setRootApp2 = nv && (nv.setRootApp || nv.default?.setRootApp);
            if (typeof setRootApp2 === 'function') {
                setRootApp2(app);
                if (__NS_ENV_VERBOSE__)
                    console.log('[hmr-client] [createRoot] nativescript-vue.setRootApp applied');
            }
        }
        catch { }
    }
    catch { }
    try {
        const hook = globalThis.__NS_HMR_INSTALL_PLUGINS__;
        if (typeof hook === 'function') {
            hook(app);
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] plugins installed');
        }
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] plugin install failed', e);
    }
    try {
        ensurePiniaOnApp(app);
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] Pinia ensured on app');
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] ensurePiniaOnApp failed', e);
    }
    try {
        bridgePiniaProvides(app, existingApp);
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] provides bridged from previous app');
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] bridgePiniaProvides failed', e);
    }
    try {
        installBuiltInComponentsOnApp(app);
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] built-in components installed');
    }
    catch (e) {
        if (__NS_ENV_VERBOSE__)
            console.warn('[hmr-client] [createRoot] installBuiltInComponentsOnApp failed', e);
    }
    const root = new RootCtor();
    const vm = typeof app.runWithContext === 'function' ? app.runWithContext(() => app.mount(root)) : app.mount(root);
    setCurrentApp(app);
    if (__NS_ENV_VERBOSE__) {
        console.log('[hmr-client] [createRoot] mount result', {
            hasEl: !!vm?.$el,
            elType: vm?.$el?.constructor?.name,
            hasNativeView: !!vm?.$el?.nativeView,
            nativeViewType: vm?.$el?.nativeView?.constructor?.name,
            elapsedMs: Date.now() - t0,
        });
    }
    const findNativeView = (element) => {
        if (element?.nativeView)
            return element.nativeView;
        const children = element?.childNodes || element?.children || [];
        for (const child of children) {
            const res = findNativeView(child);
            if (res)
                return res;
        }
        return null;
    };
    const findFrameNativeView = (element) => {
        if (!element)
            return null;
        const nv = element.nativeView;
        if (nv) {
            const ctorName = String(nv?.constructor?.name || '').replace(/^_+/, '');
            if (ctorName === 'Frame' || /^Frame(\$\d+)?$/.test(ctorName))
                return nv;
        }
        const kids = element?.childNodes || element?.children || [];
        for (const k of kids) {
            const res = findFrameNativeView(k);
            if (res)
                return res;
        }
        return null;
    };
    const findPageNativeView = (element) => {
        if (!element)
            return null;
        const nv = element.nativeView;
        if (nv) {
            const ctorName = String(nv?.constructor?.name || '').replace(/^_+/, '');
            if (ctorName === 'Page' || /^Page(\$\d+)?$/.test(ctorName))
                return nv;
        }
        const kids = element?.childNodes || element?.children || [];
        for (const k of kids) {
            const res = findPageNativeView(k);
            if (res)
                return res;
        }
        return null;
    };
    // Resolve the top-level native view from the component output. The previous logic
    // preferred ANY Frame found anywhere in the tree via depth-first recursion, which
    // is wrong when the component root is a Page that contains nested Frames (e.g.
    // a TabView whose TabViewItems each wrap their content in a <Frame>). That picked
    // the FIRST nested Frame and set it as the app root via resetRootView, severing
    // it from its TabViewItem parent and leaving a white screen on HMR reload.
    // Only fall back to the deep Frame/Page lookups when the top-level view is neither
    // (e.g., a raw Layout that the user intends to host an inner Frame for navigation).
    const topLevelNativeView = findNativeView(vm?.$el);
    const topCtorName = topLevelNativeView ? String(topLevelNativeView?.constructor?.name || '').replace(/^_+/, '') : '';
    const topIsPageOrFrame = /^(Page|Frame)(\$\d+)?$/.test(topCtorName);
    const nativeView = topIsPageOrFrame ? topLevelNativeView : findFrameNativeView(vm?.$el) || findPageNativeView(vm?.$el) || topLevelNativeView;
    const GPage = getCore('Page');
    // Decide root type and cache it
    if (nativeView) {
        const ctorName = String(nativeView?.constructor?.name || '').replace(/^_+/, '');
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] nativeView found', {
                ctorName,
            });
        // Treat Frame as authoritative root regardless of whether it already has a currentPage.
        // This avoids producing a Frame inside a wrapper Page which can lead to blank content in complex apps.
        if (ctorName === 'Frame' || /^Frame(\$\d+)?$/.test(ctorName)) {
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] root kind=frame (adopting component Frame)');
            state.setRootKind('frame');
            state.setCachedRoot(nativeView);
            return state.getCachedRoot();
        }
        if (ctorName === 'Page' || /^Page(\$\d+)?$/.test(ctorName)) {
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] root kind=page');
            state.setRootKind('page');
            state.setCachedRoot(nativeView);
            return state.getCachedRoot();
        }
        if (GPage) {
            const page = new GPage();
            page.content = nativeView;
            // If we're wrapping a view inside a Page purely to drive navigation,
            // hide the default ActionBar to avoid duplicate bars.
            try {
                page.actionBarHidden = true;
            }
            catch { }
            if (__NS_ENV_VERBOSE__)
                console.log('[hmr-client] [createRoot] wrapped nativeView in Page (root kind=page)');
            state.setRootKind('page');
            state.setCachedRoot(page);
            return state.getCachedRoot();
        }
    }
    // fallback page
    if (GPage) {
        if (__NS_ENV_VERBOSE__)
            console.log('[hmr-client] [createRoot] fallback empty Page');
        state.setRootKind('page');
        state.setCachedRoot(new GPage());
        return state.getCachedRoot();
    }
    state.setRootKind('page');
    state.setCachedRoot({});
    return state.getCachedRoot();
}
/** Install a robust $navigateBack wrapper once that falls back to remounting the
 * original root component if there's no usable Frame history. This keeps dev UX
 * predictable when testing deep links or isolated component mounts.
 */
export function ensureBackWrapperInstalled(performResetRoot, getCore) {
    try {
        const g = getGlobalScope();
        // Provide global back-remount hooks for bridges to call
        if (!g.__nsAttemptBackRemount) {
            g.__nsAttemptBackRemount = () => {
                try {
                    const orig = g.__NS_HMR_ORIG_ROOT_COMPONENT__;
                    if (orig) {
                        performResetRoot(orig);
                        return true;
                    }
                }
                catch { }
                return false;
            };
        }
        if (!g.__NS_HMR_ON_NAVIGATE_BACK) {
            g.__NS_HMR_ON_NAVIGATE_BACK = () => {
                try {
                    g.__nsAttemptBackRemount && g.__nsAttemptBackRemount();
                }
                catch { }
            };
        }
        if (g.__NS_HMR_BACK_WRAPPED__)
            return;
        const originalBack = g.$navigateBack;
        // Mark wrapped before assigning to avoid re-entrancy races
        g.__NS_HMR_BACK_WRAPPED__ = true;
        g.$navigateBack = (...args) => {
            try {
                const F = getCore('Frame');
                const top = F?.topmost?.();
                if (top && top.canGoBack?.()) {
                    if (typeof originalBack === 'function')
                        return originalBack(...args);
                    // If originalBack is not a function, try Frame fallback
                    try {
                        return top.goBack?.();
                    }
                    catch { }
                    return;
                }
            }
            catch (e) {
                // fall through to fallback
            }
            // Fallback: reset to original root component if available
            const orig = g.__NS_HMR_ORIG_ROOT_COMPONENT__;
            if (orig) {
                try {
                    // Reuse the proven remount pipeline for consistency
                    performResetRoot(orig);
                    return;
                }
                catch (e) {
                    console.warn('[hmr-client] Fallback back nav failed:', e);
                }
            }
            console.warn('[hmr-client] No usable Frame and no original root component available; cannot navigate back.');
        };
    }
    catch { }
}
//# sourceMappingURL=index.js.map