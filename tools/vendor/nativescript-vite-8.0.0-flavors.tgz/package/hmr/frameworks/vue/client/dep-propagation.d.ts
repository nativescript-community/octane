/**
 * Reverse-import-graph propagation for non-SFC dependency edits (Vue flavor).
 *
 * Editing a `.vue` file flows through `ns:vue-sfc-registry-update` →
 * `loadSfcComponent` → `performResetRoot`, so the screen always reflects the
 * fresh artifact. Editing a plain `.ts`/`.js` module that an SFC imports does
 * NOT produce a registry update — the shared queue only evicts and re-imports
 * the changed module itself. The freshly-instantiated dep module is then
 * sitting in V8's cache while the live component instance still holds bindings
 * to the OLD module instance, so the visible UI never changes even though the
 * overlay reports the update as applied.
 *
 * This walker finds the `.vue` boundaries that (transitively) import the
 * changed modules so the Vue strategy can reload + remount them — the exact
 * counterpart of the Solid flavor's `.tsx` boundary BFS in the shared queue.
 *
 * Pure function (graph in, boundaries out) so the propagation decision is unit
 * testable without booting the device runtime.
 */
export interface DepGraphModuleLike {
    id: string;
    deps: string[];
}
export declare function normalizeDepGraphKey(id: string): string;
/**
 * BFS the reverse import graph from each changed non-`.vue` module up to the
 * NEAREST `.vue` boundaries. SFC boundaries terminate the walk (remounting a
 * boundary re-assembles its whole subtree, so walking past it would only
 * produce redundant ancestors). Returns query-stripped `.vue` ids in BFS
 * discovery order (nearest first), deduplicated.
 *
 * Changed ids that are themselves `.vue` files are ignored — those flow
 * through the SFC registry-update path and never enter the shared re-import
 * queue.
 */
export declare function findNearestSfcBoundaries(changedIds: readonly string[], graph: ReadonlyMap<string, DepGraphModuleLike>): string[];
/**
 * Reverse-walk from a changed `.vue` file to its `.vue` importers (ancestors),
 * nearest-first. Unlike {@link findNearestSfcBoundaries} this STARTS from a
 * `.vue` and does not stop at the first boundary — it returns the full ancestor
 * chain so the caller can remount the nearest one that's safely mountable as a
 * root (a child SFC with required props is not). The changed file is excluded.
 */
export declare function findSfcAncestors(changedVuePath: string, graph: ReadonlyMap<string, DepGraphModuleLike>, maxAncestors?: number): string[];
