import type { FrameworkServerStrategy } from './server/framework-strategy.js';
/**
 * A framework flavor contributed from outside this package.
 *
 * The built-in flavors (`angular`, `vue`, `react`, `solid`, `typescript`,
 * `javascript`) are wired by name inside `@nativescript/vite`. Everything a
 * flavor needs beyond a name is expressed here, so a framework can ship its
 * own HMR support as a package: the server half runs in the dev server
 * process; the client half is a module the device fetches and evaluates next
 * to the shared HMR client.
 */
export interface FrameworkFlavorDefinition {
    /**
     * The flavor name. It is what the config helper declares through
     * `baseConfig({ flavor })`, what the device receives as `__NS_TARGET_FLAVOR__`,
     * and what selects both strategies. Must not collide with a built-in name.
     */
    flavor: string;
    /**
     * The dev-server half. Most frameworks start from `typescriptServerStrategy`
     * (the generic device-module pipeline) and override `handleHotUpdate`.
     */
    server: FrameworkServerStrategy;
    /**
     * The device half: a module specifier resolvable from the app's root —
     * usually a package subpath such as `@my-framework/nativescript-vite/client`.
     * The module is served to the device as-is through `/ns/m`, so it must be
     * plain ESM with explicit `.js` import extensions, importing shared client
     * helpers only from `@nativescript/vite/hmr/client/framework.js`. It exports
     * the strategy as `default`, `clientStrategy`, or `<flavor>ClientStrategy`.
     */
    client: string;
}
/**
 * Register a flavor. Call it before `baseConfig({ flavor })` runs — from the
 * top of the framework's config helper is the natural place — so the HMR
 * plugins the base config installs can find the server strategy, and the
 * device bundle is seeded with the client strategy's URL. Registering the
 * same flavor again replaces the previous definition.
 */
export declare function registerFrameworkFlavor(definition: FrameworkFlavorDefinition): void;
export declare function getFrameworkFlavor(flavor: string): FrameworkFlavorDefinition | undefined;
/**
 * Package names that ship a registered flavor's client strategy. The device
 * pipeline treats them like `@nativescript/vite` itself: served per-module
 * through `/ns/m`, never through the vendor bundle or the plugin registry
 * shim, so the module's own relative imports and its imports of the shared
 * client surface resolve to the live client's canonical URLs.
 */
export declare function getFlavorClientPackages(): ReadonlySet<string>;
export declare function isBuiltInFlavor(flavor: string): boolean;
/**
 * The device-side URL path of a registered flavor's client strategy module —
 * `/ns/m/node_modules/<package>/<file>` — or `''` for a built-in / unknown
 * flavor. The specifier is resolved from the app root like any import, then
 * expressed relative to its package so the path holds whether the package is
 * installed or linked from a workspace.
 */
export declare function getClientStrategyDevicePath(flavor: string, projectRoot?: string): string;
