import type { ViteDevServer } from 'vite';
export interface NsRtRouteOptions {
    getGraphVersion(): number;
}
export declare function registerNsRtBridgeRoute(server: ViteDevServer, options: NsRtRouteOptions): void;
