/**
 * Early "pending" notification for HMR.
 *
 * When `handleHotUpdate(ctx)` first fires for a save event, the server
 * spends 7–200ms doing graph upserts, transforms and dependency
 * analysis BEFORE broadcasting `ns:angular-update` (or
 * `ns:css-updates`). During that window the client has no idea a
 * change is in flight, so the HMR-applying overlay only appears at
 * the tail end of the cycle and the user perceives the dev loop as
 * laggy.
 *
 * `ns:hmr-pending` is broadcast at the very start of `handleHotUpdate`
 * with just the file path + classified kind. The client reacts by
 * showing the 'received' overlay frame immediately. The authoritative
 * payload (`ns:angular-update` / `ns:css-updates`) follows once the
 * server is ready and walks the rest of the stage progression.
 *
 * This module is intentionally a pure helper so the message shape and
 * narrowing rules can be verified without spinning up a Vite dev
 * server.
 */
export function createHmrPendingMessage(input) {
    const allowed = ['ts', 'css', 'html', 'unknown'];
    const kind = allowed.includes(input.kind || '') ? input.kind : 'unknown';
    return {
        type: 'ns:hmr-pending',
        origin: typeof input.origin === 'string' ? input.origin : '',
        path: typeof input.path === 'string' ? input.path : '',
        kind,
        timestamp: typeof input.timestamp === 'number' && Number.isFinite(input.timestamp) ? input.timestamp : 0,
    };
}
//# sourceMappingURL=websocket-hmr-pending.js.map