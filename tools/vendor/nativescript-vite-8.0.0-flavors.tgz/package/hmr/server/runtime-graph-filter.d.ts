export declare function normalizeRuntimeGraphPath(value: string): string;
export declare function isRuntimeGraphExcludedPath(value: string): boolean;
export declare function shouldSkipRuntimeGraphDirectoryName(name: string): boolean;
export declare function shouldIncludeRuntimeGraphFile(value: string, filePattern: RegExp): boolean;
export declare function matchesRuntimeGraphModuleId(value: string, appPrefix: string, filePattern: RegExp): boolean;
