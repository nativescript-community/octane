export interface NsRtBridgeOptions {
    /** Version segment from `/ns/rt/<ver>`. Retained for the URL dispatcher; the bridge body intentionally ignores it. */
    rtVer: string;
    /** Prologue installed verbatim before the bridge body (typically the require URL guard). */
    requireGuardSnippet: string;
    /**
     * The discovered ESM export names of the underlying vendor package
     * (`nativescript-vue`, including its `@vue/runtime-core` re-export
     * chain). Each name becomes `export const <name> = (__ensure().<name>);` —
     * a single canonical specifier (`/ns/rt`) forwards *every* symbol the
     * vendor publishes.
     *
     * Required: discovery is the only source of truth. There is no hand-curated
     * fallback — if discovery cannot see the package, the bridge serves no
     * passthroughs and the call site is expected to surface that as a config
     * error rather than silently degrade.
     */
    vendorExports: Iterable<string>;
}
/**
 * Build the `/ns/rt` runtime bridge module text.
 *
 * Single-realm policy: every named export the vendor package publishes
 * appears as `export const X = (__ensure().X);` — a constant binding, not a
 * function wrapper. Constant bindings preserve identity for Vue's Symbol
 * markers (`Fragment`, `Teleport`, …) AND work transparently for functions
 * (`ref`, `createApp`, …) since the user code calls the underlying value
 * directly. Calling `__ensure()` at module evaluation time is safe because
 * the vendor bundle is registered earlier in the boot graph (vendor.mjs →
 * `__nsVendorRegistry`), and the bridge resolves the same `nativescript-vue`
 * record everyone else uses.
 *
 * HMR-specific shims (`$navigateTo`, `$navigateBack`, `$showModal`) and the
 * Vite client polyfill (`vite__injectQuery`) are emitted as overrides that
 * replace the would-be passthrough — those exports route through the HMR
 * navigator instead of the vendor's native version, so the bridge must
 * provide the override, not the discovered original.
 */
export declare function buildNsRtBridgeModule(options: NsRtBridgeOptions): string;
/**
 * Resolve the set of names the bridge should re-export for `nativescript-vue`
 * given a project root. Static discovery via `enumeratePackageExports` is the
 * only source — there is no curated fallback. If `nativescript-vue` is not
 * resolvable from `projectRoot`, the returned set is empty and the bridge
 * built from it will not emit passthroughs; the caller should treat that as
 * the misconfiguration it is rather than mask it with a stale baseline.
 *
 * Caching lives inside `enumeratePackageExports`, so repeated calls in a dev
 * session are effectively free.
 */
export declare function discoverNsvBridgeExports(projectRoot: string): Set<string>;
