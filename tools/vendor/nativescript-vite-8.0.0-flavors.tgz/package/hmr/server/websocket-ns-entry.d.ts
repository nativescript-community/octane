import type { ViteDevServer } from 'vite';
/**
 * Dependencies the device-bootstrap routes need from the HMR plugin closure.
 * The three project-path values are computed once in `websocket.ts`; injecting
 * them (rather than recomputing) keeps a single source of truth.
 */
export interface RegisterNsEntryRoutesOptions {
    verbose: boolean;
    appRootDir: string;
    defaultMainEntry: string;
    defaultMainEntryVirtual: string;
    getGraphVersion(): number;
}
/**
 * Registers the device bootstrap endpoints:
 *   - `GET /ns/entry-rt[?v=<ver>]` — serves the compiled entry runtime module
 *     (built `entry-runtime.js`, or a transformed `entry-runtime.ts` fallback), and
 *   - `GET /ns/entry[/<ver>]` — a script-safe wrapper that fetches the entry
 *     runtime and starts the app with `{ origin, main, ver }`.
 */
export declare function registerNsEntryRoutes(server: ViteDevServer, options: RegisterNsEntryRoutesOptions): void;
