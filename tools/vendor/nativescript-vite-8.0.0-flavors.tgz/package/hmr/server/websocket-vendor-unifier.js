import { setDeviceModuleHeaders } from './route-helpers.js';
import { getServerOrigin } from './server-origin.js';
export function shouldHandleVendorUnifierPath(pathname) {
    if (/^\/ns\/(?:rt|core)(?:\/|$)/.test(pathname)) {
        return false;
    }
    if (!/(\.m?js$|\.ts$|\/node_modules\/|\/\.vite\/deps\/|^\/@id\/|^\/@fs\/)/.test(pathname)) {
        return false;
    }
    if (/\.css($|\?)/.test(pathname)) {
        return false;
    }
    return true;
}
export function maybeRewriteVendorModule(code, strategy, origin, version) {
    const rewrite = strategy.rewriteVendorSpec;
    if (!rewrite) {
        return code;
    }
    return rewrite(code, origin, version);
}
export function registerVendorUnifierHandler(server, options) {
    server.middlewares.use(async (req, res, next) => {
        try {
            const reqUrl = req.url || '';
            const urlObj = new URL(reqUrl, 'http://localhost');
            const pathname = urlObj.pathname || '';
            if (!shouldHandleVendorUnifierPath(pathname))
                return next();
            const transformed = await server.transformRequest(reqUrl);
            if (!transformed?.code)
                return next();
            const strategy = options.getStrategy();
            const rewritten = maybeRewriteVendorModule(transformed.code, strategy, getServerOrigin(server), options.getGraphVersion());
            if (rewritten === transformed.code)
                return next();
            setDeviceModuleHeaders(res);
            res.statusCode = 200;
            res.end(rewritten);
        }
        catch {
            return next();
        }
    });
}
//# sourceMappingURL=websocket-vendor-unifier.js.map