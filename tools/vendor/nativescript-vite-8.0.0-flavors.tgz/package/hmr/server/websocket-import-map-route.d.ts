import type { ViteDevServer } from 'vite';
import type { FrameworkServerStrategy } from './framework-strategy.js';
export interface RegisterImportMapRouteOptions {
    /** The active framework strategy — only its `flavor` is consulted. */
    getStrategy: () => FrameworkServerStrategy | undefined;
}
/**
 * Registers the device import-map endpoint: `GET /ns/import-map.json`.
 *
 * Returns the import map + runtime config consumed by ns:module `configureLoader()`
 * on the device during cold boot. Extracted verbatim from
 * `createHmrWebSocketPlugin`; the only injected dependency is the active
 * framework strategy (for its `flavor`).
 */
export declare function registerImportMapRoute(server: ViteDevServer, options: RegisterImportMapRouteOptions): void;
