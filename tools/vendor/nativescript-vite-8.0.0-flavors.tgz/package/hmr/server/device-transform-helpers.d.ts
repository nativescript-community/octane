declare function rewriteVitePrebundleImportsForDevice(code: string, preserveVendorImports: boolean): string;
declare function buildNodeModuleProvenancePrelude(sourceId?: string): string;
declare function shouldRemapImport(spec: string): boolean;
declare function removeNamedImports(code: string, names: string[]): string;
declare function normalizeImportPath(spec: string, importerDir: string): string | null;
declare function findDependencyFileName(depFileMap: Map<string, string>, key: string): string | undefined;
declare function collectMixedRuntimePluginHttpRootPackages(code: string, projectRoot: string): Set<string>;
/**
 * Check if a path is an application module (not node_modules, not vendor, not relative)
 * This is generic and works for ANY project structure.
 *
 * Examples of application imports: /core/v4/store.ts, /src/utils/helper.ts, /custom/module.ts
 * Examples of NON-application imports: node_modules/..., ~/vendor.mjs, ./relative.ts, ../parent.ts
 */
declare function isApplicationImport(importPath: string): boolean;
declare function stripToProjectRelative(importPath: string, projectRoot?: string): string;
/**
 * Convert absolute application import to relative .mjs path for Documents folder
 * /core/v4/store.ts → ./core/v4/store.mjs
 */
declare function getProjectRelativeImportPath(importPath: string, projectRoot?: string): string | null;
declare function toAppModuleBaseId(importPath: string, projectRoot?: string): string | null;
declare function toNodeModulesHttpModuleId(importPath: string): string | null;
export { rewriteVitePrebundleImportsForDevice, buildNodeModuleProvenancePrelude, shouldRemapImport, removeNamedImports, normalizeImportPath, findDependencyFileName, collectMixedRuntimePluginHttpRootPackages, isApplicationImport, stripToProjectRelative, getProjectRelativeImportPath, toAppModuleBaseId, toNodeModulesHttpModuleId };
