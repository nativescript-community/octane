export declare function canonicalizeNsMImportPath(p: string): string;
export interface InboundLegacyNsMSpec {
    cleanedSpec: string;
    bootTaggedRequest: boolean;
    forcedVer: string | null;
}
/**
 * Single seam for BOTH directions of legacy `/ns/m` tag handling:
 *
 *   - `'inbound-request-spec'`: strip `__ns_boot__`/`__ns_hmr__` decorations
 *     from a raw request spec, reporting what was stripped.
 *   - `'outbound-served-code'`: collapse every emitted `/ns/m` URL in served
 *     code to its canonical stable form (requires `origin`).
 *
 * Current servers never EMIT tags; both directions exist purely to tolerate
 * stale cached device code.
 */
export declare function collapseLegacyNsMTags(value: string, mode: 'inbound-request-spec'): InboundLegacyNsMSpec;
export declare function collapseLegacyNsMTags(value: string, mode: 'outbound-served-code', origin: string): string;
