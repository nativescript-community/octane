export declare function canonicalizeTransformRequestCacheKey(url: string, projectRoot: string): string;
export type TransitiveImporterModuleLike = {
    id?: string | null;
    file?: string | null;
    importers?: Iterable<TransitiveImporterModuleLike> | null;
};
/**
 * Purge stale transform-cache state for a changed file before a hot update is
 * re-served. Invalidates Vite's module graph for the file + its bounded
 * transitive importers (so `transformRequest` re-runs the pipeline) and clears
 * `sharedTransformRequest`'s result cache (the `/ns/m/` route probes many
 * candidate extensions per spec, each a distinct cache key, so targeted
 * invalidation alone can miss the key a previous serve populated).
 *
 * Shared by the per-flavor `handleHotUpdate` tails (Vue, Solid). `label` only
 * affects verbose log lines.
 */
export declare function purgeTransformCachesForHotUpdate(options: {
    file: string;
    server: {
        config?: {
            root?: string;
        };
        moduleGraph?: any;
    };
    sharedTransformRequest?: {
        invalidateMany: (urls: Iterable<string>) => void;
        clear: () => void;
    } | null;
    verbose?: boolean;
    label?: string;
}): void;
export declare function collectTransitiveImportersForInvalidation(options: {
    modules: Iterable<TransitiveImporterModuleLike> | undefined | null;
    isExcluded?: (id: string) => boolean;
    maxDepth?: number;
}): TransitiveImporterModuleLike[];
