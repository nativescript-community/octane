/**
 * Framework-agnostic CSS delivery for HMR. Beyond `app.css`, every CSS source (a
 * JS/TS `import './x.css'`, a Vue SFC `<style>`) needs an explicit bridge to the
 * device's tagged-CSS API — under HMR there's no DOM for Vite's default CSS
 * module to inject into, so it would otherwise be dropped.
 *
 * Bridge: a device-side applier `globalThis.__NS_REGISTER_CSS__(tag, cssText)`
 * installed at client boot (see `hmr/client/index.ts`, `hmr/entry-runtime.ts`),
 * plus a snippet (built here) emitted into each CSS-bearing module that calls
 * it. The per-source `tag` lets hot-updates replace a source's rules without
 * touching siblings. Flavor-specific extraction (SFC blocks vs. file) feeds
 * these shared builders.
 */
export declare const CSS_MODULE_RE: RegExp;
/**
 * Strip a leading BOM and `@charset` (sass emits one for non-ASCII content);
 * NativeScript's styling engine has no use for either.
 */
export declare function normalizeCssForDevice(css: string): string;
/** Register a CSS string literal under `tag`. `''` for empty CSS. */
export declare function buildCssRegisterSnippet(tag: string, cssText: string): string;
/**
 * Register CSS held in an in-scope module variable under `tag`. Used by the
 * generic `.css` handler (reuses Vite's `?inline` binding). For an imported file
 * `tag` is its root-relative path — the same tag the `.css` live-edit path uses,
 * so edits replace instead of stacking.
 */
export declare function buildCssRegisterSnippetFromVar(tag: string, varName: string): string;
