import { existsSync, readFileSync, statSync } from 'node:fs';
import * as path from 'node:path';
import { normalizeCoreSub } from '../../helpers/ns-core-url.js';
import { getGlobalScope } from '../shared/runtime/global-scope.js';
/**
 * Full JS identifier alphabet — Unicode-aware, NOT ASCII `\w`. Angular's
 * runtime API surface is `ɵɵdefineInjectable`-style (U+0275 is ID_Start);
 * an ASCII filter silently drops every such export from generated shims.
 */
export const JS_IDENTIFIER_RE = /^[$_\p{ID_Start}][$\u200c\u200d\p{ID_Continue}]*$/u;
export function extractDirectExportedNames(code) {
    const names = new Set();
    const declRe = /\bexport\s+(?:async\s+)?(?:function|class)\s+([$_\p{ID_Start}][$\p{ID_Continue}]*)/gu;
    let match;
    while ((match = declRe.exec(code)) !== null) {
        names.add(match[1]);
    }
    const namespaceRe = /\bexport\s+namespace\s+([$_\p{ID_Start}][$\p{ID_Continue}]*)/gu;
    while ((match = namespaceRe.exec(code)) !== null) {
        names.add(match[1]);
    }
    const varRe = /\bexport\s+(?:const|let|var)\s+([^=;{]+)/g;
    while ((match = varRe.exec(code)) !== null) {
        const decl = match[1].trim();
        if (decl.startsWith('{')) {
            const inner = decl.replace(/^\{|\}$/g, '');
            for (const part of inner.split(',')) {
                const name = part.split(':')[0].trim();
                if (JS_IDENTIFIER_RE.test(name))
                    names.add(name);
            }
        }
        else {
            const name = decl.split(/[\s,=]/)[0].trim();
            if (JS_IDENTIFIER_RE.test(name))
                names.add(name);
        }
    }
    const directBraceRe = /\bexport\s*\{([^}]+)\}(?!\s*from)/g;
    while ((match = directBraceRe.exec(code)) !== null) {
        for (const part of match[1].split(',')) {
            const trimmed = part.trim();
            const asMatch = trimmed.match(/(\S+)\s+as\s+(\S+)/);
            const name = asMatch ? asMatch[2] : trimmed.split(/\s/)[0];
            if (name && JS_IDENTIFIER_RE.test(name) && name !== 'default') {
                names.add(name);
            }
        }
    }
    return Array.from(names);
}
export function parseExportSpecList(specList) {
    return String(specList || '')
        .split(',')
        .map((part) => part.trim())
        .filter(Boolean)
        .map((part) => {
        const asMatch = part.match(/(\S+)\s+as\s+(\S+)/i);
        if (asMatch) {
            return { importedName: asMatch[1].trim(), exportedName: asMatch[2].trim() };
        }
        const name = part.split(/\s/)[0]?.trim() || '';
        return { importedName: name, exportedName: name };
    })
        .filter(({ exportedName, importedName }) => JS_IDENTIFIER_RE.test(exportedName) && exportedName !== 'default' && JS_IDENTIFIER_RE.test(importedName));
}
function runtimeModuleIdForFile(modulePath, rootEntryPath) {
    const cleanedPath = String(modulePath || '').replace(/[?#].*$/, '');
    const cleanedRoot = String(rootEntryPath || '').replace(/[?#].*$/, '');
    if (!cleanedPath || !cleanedRoot)
        return null;
    const rootDir = path.dirname(cleanedRoot);
    let rel = path.relative(rootDir, cleanedPath).replace(/\\/g, '/');
    if (!rel || rel === 'index.ts' || rel === 'index.js' || rel === 'index.mjs') {
        return '@nativescript/core';
    }
    rel = rel.replace(/\.(?:ts|js|mjs)$/, '');
    rel = rel.replace(/\/index$/, '');
    return `@nativescript/core/${rel}`;
}
function runtimeModuleIdFromLocalSpecifier(spec, currentModuleId) {
    if (!spec.startsWith('.'))
        return spec || null;
    const base = currentModuleId.replace(/^@nativescript\/core(?:\/|$)/, '');
    const baseDir = base ? `/${base}` : '/';
    let rel = path.posix.normalize(path.posix.join(baseDir, spec)).replace(/^\/+/, '');
    rel = rel.replace(/\.(?:ts|js|mjs)$/, '');
    rel = rel.replace(/\/index$/, '');
    return rel ? `@nativescript/core/${rel}` : '@nativescript/core';
}
function canonicalCoreSubpathForFile(modulePath, rootEntryPath) {
    const cleanedPath = String(modulePath || '').replace(/[?#].*$/, '');
    const cleanedRoot = String(rootEntryPath || '').replace(/[?#].*$/, '');
    if (!cleanedPath || !cleanedRoot)
        return null;
    const rootDir = path.dirname(cleanedRoot);
    let rel = path.relative(rootDir, cleanedPath).replace(/\\/g, '/');
    if (!rel || rel === 'index.ts' || rel === 'index.js' || rel === 'index.mjs') {
        return null;
    }
    rel = rel.replace(/\.(?:ts|js|mjs)$/, '.js');
    return rel;
}
function canonicalCoreSubpathFromLocalSpecifier(spec, currentCanonicalSubpath) {
    if (!spec.startsWith('.'))
        return null;
    const baseDir = currentCanonicalSubpath ? path.posix.dirname(currentCanonicalSubpath) : '.';
    const rel = path.posix.normalize(path.posix.join(baseDir, spec)).replace(/^\.?\/?/, '');
    if (!rel)
        return null;
    if (/\.(?:ts|js|mjs)$/i.test(rel)) {
        return rel.replace(/\.(?:ts|js|mjs)$/i, '.js');
    }
    return `${rel.replace(/\/+$/, '')}/index.js`;
}
export async function resolveRuntimeCoreModulePath(normalizedSubpath, resolveModuleId) {
    const cleanedSubpath = String(normalizedSubpath || '').replace(/^\/+/, '');
    const candidates = [];
    if (!cleanedSubpath || cleanedSubpath === 'index.js') {
        candidates.push('@nativescript/core');
    }
    else {
        if (/\/index\.js$/i.test(cleanedSubpath)) {
            const packageSubpath = cleanedSubpath.replace(/\/index\.js$/i, '');
            if (packageSubpath) {
                candidates.push(`@nativescript/core/${packageSubpath}`);
            }
        }
        candidates.push(`@nativescript/core/${cleanedSubpath}`);
    }
    for (const candidate of candidates) {
        try {
            const resolved = await resolveModuleId(candidate);
            if (resolved) {
                return String(resolved).replace(/[?#].*$/, '');
            }
        }
        catch { }
    }
    return null;
}
function appendCoreExportOrigin(map, exportedName, origin) {
    if (!/^[A-Za-z_$][\w$]*$/.test(exportedName) || exportedName === 'default')
        return;
    const existing = map[exportedName] || (map[exportedName] = []);
    if (existing.some((entry) => entry.moduleId === origin.moduleId && entry.mode === origin.mode && entry.importedName === origin.importedName)) {
        return;
    }
    existing.push(origin);
}
function resolveLocalExportTarget(spec, importerId) {
    const importerPath = String(importerId || '').replace(/[?#].*$/, '');
    if (!importerPath)
        return null;
    const importerDir = path.dirname(importerPath);
    // Include platform-specific variants (.ios.js / .android.js / .visionos.js).
    // @nativescript/core ships only platform-specific files for many submodules
    // (e.g. `./application/index.ios.js`, no plain `./application/index.js`), so
    // a plain Node-style resolution misses them and the recursive export-name
    // walk fails to follow `export * from './application'`. Without this, the
    // /ns/core bridge's named-export list omits `Application`, and any static
    // `import { Application } from '@nativescript/core'` through the bridge
    // fails with "module does not provide an export named 'Application'".
    //
    // Prefer .ios variants at the top since the HMR dev server is iOS-first;
    // .android variants are still tried so Android serving also works.
    const platformVariants = ['.ios.ts', '.ios.js', '.ios.mjs', '.android.ts', '.android.js', '.android.mjs', '.visionos.ts', '.visionos.js', '.visionos.mjs'];
    const candidates = [path.resolve(importerDir, spec), path.resolve(importerDir, `${spec}.ts`), path.resolve(importerDir, `${spec}.js`), path.resolve(importerDir, `${spec}.mjs`), ...platformVariants.map((ext) => path.resolve(importerDir, `${spec}${ext}`)), path.resolve(importerDir, spec, 'index.ts'), path.resolve(importerDir, spec, 'index.js'), path.resolve(importerDir, spec, 'index.mjs'), ...platformVariants.map((ext) => path.resolve(importerDir, spec, `index${ext}`))];
    for (const candidate of candidates) {
        if (existsSync(candidate) && !statSync(candidate).isDirectory()) {
            return candidate;
        }
    }
    return null;
}
// NOTE: `expandStarExports` in websocket-served-module-helpers.ts implements
// the same transitive export-name semantics for arbitrary node_modules
// packages (transformer-based rather than filesystem-based). If you change
// export-name collection rules here, check that walker too — a shallow or
// diverging implementation surfaces on device as a link-time
// "does not provide an export named ..." with no server-side trace.
export function collectStaticExportNamesFromFile(modulePath, seen = new Set()) {
    return Object.keys(collectStaticExportOriginsFromFile(modulePath, modulePath, seen));
}
export function collectStaticExportOriginsFromFile(modulePath, rootEntryPath = modulePath, seen = new Set()) {
    const cleanedPath = String(modulePath || '').replace(/[?#].*$/, '');
    const cleanedRoot = String(rootEntryPath || '').replace(/[?#].*$/, '');
    if (!cleanedPath || !cleanedRoot || seen.has(cleanedPath) || !existsSync(cleanedPath)) {
        return {};
    }
    seen.add(cleanedPath);
    let code = '';
    try {
        code = readFileSync(cleanedPath, 'utf8');
    }
    catch {
        return {};
    }
    const currentModuleId = runtimeModuleIdForFile(cleanedPath, cleanedRoot) || '@nativescript/core';
    const currentCanonicalSubpath = canonicalCoreSubpathForFile(cleanedPath, cleanedRoot);
    // Use a null-prototype map so keys like `toString`, `constructor`, or
    // `hasOwnProperty` — which DO appear as real exports in some core
    // subpaths (e.g. `@nativescript/core/ui/gestures/gestures-common`
    // re-exports `toString`) — don't collide with Object.prototype's own
    // properties. Previously `origins['toString']` returned the inherited
    // Function, and the subsequent `existing.some(...)` call threw
    // "existing.some is not a function", causing the whole subpath's
    // export discovery to bail and fall back to a pure `export *` which
    // in turn leaked into the "hasKey not provided" downstream crash.
    const origins = Object.create(null);
    for (const name of extractDirectExportedNames(code)) {
        appendCoreExportOrigin(origins, name, { moduleId: currentModuleId, mode: 'named', importedName: name, canonicalSubpath: currentCanonicalSubpath || undefined });
    }
    const starAsRe = /\bexport\s+\*\s+as\s+([A-Za-z_$][\w$]*)\s+from\s+["']([^"']+)["']/g;
    let match;
    while ((match = starAsRe.exec(code)) !== null) {
        const exportedName = match[1];
        const spec = match[2];
        const resolvedTarget = spec.startsWith('.') ? resolveLocalExportTarget(spec, cleanedPath) : null;
        const moduleId = resolvedTarget ? runtimeModuleIdForFile(resolvedTarget, cleanedRoot) : spec.startsWith('.') ? runtimeModuleIdFromLocalSpecifier(spec, currentModuleId) : spec;
        const canonicalSubpath = resolvedTarget ? canonicalCoreSubpathForFile(resolvedTarget, cleanedRoot) : spec.startsWith('.') ? canonicalCoreSubpathFromLocalSpecifier(spec, currentCanonicalSubpath) : undefined;
        if (!moduleId)
            continue;
        appendCoreExportOrigin(origins, exportedName, { moduleId, mode: 'module', canonicalSubpath: canonicalSubpath || undefined });
    }
    const namedReExportRe = /\bexport\s*\{([^}]+)\}\s*from\s*["']([^"']+)["']/g;
    while ((match = namedReExportRe.exec(code)) !== null) {
        const specList = match[1];
        const spec = match[2];
        const resolvedTarget = spec.startsWith('.') ? resolveLocalExportTarget(spec, cleanedPath) : null;
        const moduleId = resolvedTarget ? runtimeModuleIdForFile(resolvedTarget, cleanedRoot) : spec.startsWith('.') ? runtimeModuleIdFromLocalSpecifier(spec, currentModuleId) : spec;
        const canonicalSubpath = resolvedTarget ? canonicalCoreSubpathForFile(resolvedTarget, cleanedRoot) : spec.startsWith('.') ? canonicalCoreSubpathFromLocalSpecifier(spec, currentCanonicalSubpath) : undefined;
        if (!moduleId)
            continue;
        for (const { exportedName, importedName } of parseExportSpecList(specList)) {
            appendCoreExportOrigin(origins, exportedName, { moduleId, mode: 'named', importedName, canonicalSubpath: canonicalSubpath || undefined });
        }
    }
    const directBraceRe = /\bexport\s*\{([^}]+)\}(?!\s*from)/g;
    while ((match = directBraceRe.exec(code)) !== null) {
        for (const { exportedName, importedName } of parseExportSpecList(match[1])) {
            appendCoreExportOrigin(origins, exportedName, { moduleId: currentModuleId, mode: 'named', importedName, canonicalSubpath: currentCanonicalSubpath || undefined });
        }
    }
    // Tolerate trailing comments on `export * from '…'` lines. @nativescript/core
    // has lines like `export * from './layouts'; // barrel export`, and the
    // previous strict `[ \t]*$` anchor refused to match them — which silently
    // skipped recursion into ./layouts, omitting GridLayout/LayoutBase (and
    // any name reached through a similarly-commented star re-export) from the
    // /ns/core bridge's named-export list.
    const starRe = /^[ \t]*export\s+\*\s+from\s+["']([^"']+)["'][^\n]*$/gm;
    while ((match = starRe.exec(code)) !== null) {
        const spec = match[1];
        if (!spec.startsWith('.'))
            continue;
        const resolvedTarget = resolveLocalExportTarget(spec, cleanedPath);
        const moduleId = resolvedTarget ? runtimeModuleIdForFile(resolvedTarget, cleanedRoot) : runtimeModuleIdFromLocalSpecifier(spec, currentModuleId);
        const canonicalSubpath = resolvedTarget ? canonicalCoreSubpathForFile(resolvedTarget, cleanedRoot) : canonicalCoreSubpathFromLocalSpecifier(spec, currentCanonicalSubpath);
        if (!resolvedTarget)
            continue;
        const childOrigins = collectStaticExportOriginsFromFile(resolvedTarget, cleanedRoot, seen);
        for (const [exportedName, entries] of Object.entries(childOrigins)) {
            if (moduleId) {
                appendCoreExportOrigin(origins, exportedName, { moduleId, mode: 'named', importedName: exportedName, canonicalSubpath: canonicalSubpath || undefined });
            }
            for (const entry of entries) {
                appendCoreExportOrigin(origins, exportedName, entry);
            }
        }
    }
    return origins;
}
export async function normalizeCoreExportOriginsForRuntime(exportOrigins, resolveModuleId, rootModulePath) {
    const cleanedRoot = String(rootModulePath || '').replace(/[?#].*$/, '');
    if (!cleanedRoot || !exportOrigins || typeof exportOrigins !== 'object') {
        return exportOrigins;
    }
    const resolutionCache = new Map();
    const normalizedOrigins = {};
    for (const [exportedName, entries] of Object.entries(exportOrigins)) {
        normalizedOrigins[exportedName] = await Promise.all((entries || []).map(async (entry) => {
            if (!entry?.moduleId || !entry.moduleId.startsWith('@nativescript/core')) {
                return entry;
            }
            let resolvedPath = resolutionCache.get(entry.moduleId);
            if (resolvedPath === undefined) {
                try {
                    resolvedPath = (await resolveModuleId(entry.moduleId)) || null;
                }
                catch {
                    resolvedPath = null;
                }
                resolvedPath = resolvedPath ? String(resolvedPath).replace(/[?#].*$/, '') : null;
                resolutionCache.set(entry.moduleId, resolvedPath);
            }
            if (!resolvedPath) {
                return entry;
            }
            const canonicalSubpath = canonicalCoreSubpathForFile(resolvedPath, cleanedRoot);
            if (!canonicalSubpath || canonicalSubpath === entry.canonicalSubpath) {
                return entry;
            }
            return { ...entry, canonicalSubpath };
        }));
    }
    return normalizedOrigins;
}
export function hasModuleDefaultExport(moduleCode) {
    if (!moduleCode || typeof moduleCode !== 'string')
        return false;
    return /\bexport\s+default\b/.test(moduleCode) || /\bexport\s*\{[^}]*\bdefault\b[^}]*\}/.test(moduleCode);
}
/**
 * Parse an incoming `/ns/core` bridge request.
 *
 * Accepted shapes:
 *   - `/ns/core`               → package main
 *   - `/ns/core/<sub>`         → subpath form (`<sub>` may carry a
 *                                `.js`/`/index`/platform-suffix tail
 *                                that we strip via `normalizeCoreSub`
 *                                and report through `canonicalPath` so
 *                                the middleware can 301)
 *
 * Anything else returns `null` so the middleware falls through to
 * `next()` and a downstream 404 surfaces the offending emitter.
 *
 * URL contract:
 *   - No version segment. `/ns/core/<digits>` was an experimental
 *     cache-busting shape that split iOS's HTTP-ESM module cache from
 *     the unversioned URL emitted by the runtime import map. Removed.
 *   - No `?p=<sub>` query form. The canonical path form
 *     `/ns/core/<sub>` is the only spelling every emitter produces.
 */
export function parseCoreBridgeRequest(pathname, _searchParams, _currentGraphVersion) {
    if (!pathname)
        return null;
    if (!(pathname === '/ns/core' || pathname === '/ns/core/' || pathname.startsWith('/ns/core/'))) {
        return null;
    }
    const afterCore = pathname.replace(/^\/ns\/core\/?/, '');
    if (afterCore.startsWith('/')) {
        return null;
    }
    const sub = afterCore || '';
    const normalizedSub = sub ? sub.replace(/^\/+/, '') : null;
    let canonicalPath;
    if (normalizedSub) {
        const canonical = normalizeCoreSub(normalizedSub);
        const expectedPath = canonical ? `/ns/core/${canonical}` : '/ns/core';
        if (pathname !== expectedPath) {
            canonicalPath = expectedPath;
            try {
                const g = getGlobalScope();
                g.__NS_BRIDGE_NONCANON__ || (g.__NS_BRIDGE_NONCANON__ = { count: 0, samples: [] });
                g.__NS_BRIDGE_NONCANON__.count++;
                if (g.__NS_BRIDGE_NONCANON__.samples.length < 10) {
                    g.__NS_BRIDGE_NONCANON__.samples.push({ raw: normalizedSub, canonical, pathname });
                }
            }
            catch { }
        }
    }
    return {
        sub: normalizedSub || '',
        normalizedSub,
        key: normalizedSub ? `@nativescript/core/${normalizedSub}` : '@nativescript/core',
        canonicalPath,
    };
}
//# sourceMappingURL=websocket-core-bridge.js.map