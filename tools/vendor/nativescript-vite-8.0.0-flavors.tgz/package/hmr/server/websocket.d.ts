import type { Plugin } from 'vite';
/**
 * Build the server-side HMR WebSocket plugin for `flavor`, or `undefined` when
 * the flavor has no server strategy. Built-in flavors come from
 * `STRATEGY_REGISTRY`; a framework shipped outside this package contributes
 * its strategy through `registerFrameworkFlavor` (see `framework-flavors.ts`).
 */
export declare function hmrWebSocketPluginForFlavor(flavor: string, opts: {
    verbose?: boolean;
}): Plugin | undefined;
