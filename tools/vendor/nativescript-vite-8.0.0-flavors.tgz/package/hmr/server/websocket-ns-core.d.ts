import type { TransformResult, ViteDevServer } from 'vite';
import { type CoreBundleService } from './core-bundle.js';
type SharedTransformRequestFn = (url: string, timeoutMs?: number) => Promise<TransformResult | null>;
/**
 * Plugin-closure dependencies the `/ns/core` bridge needs: the shared transform
 * runner (holds/derives per-server state and doubles as a testability seam),
 * injected to keep the bridge in its own module. The device origin comes from
 * the directly-imported `getServerOrigin` (spy via the module in tests).
 */
export interface RegisterNsCoreRouteOptions {
    getGraphVersion(): number;
    sharedTransformRequest: SharedTransformRequestFn;
    /**
     * Injectable core-bundle service (testability seam). When omitted, the
     * shared process-wide service is used — unless `NS_CORE_PER_MODULE=1`
     * disables bundle mode entirely.
     */
    coreBundle?: CoreBundleService | null;
}
/**
 * Registers the `@nativescript/core` device bridge on the dev server:
 *   - a catch-all that rewrites stray `/node_modules/@nativescript/core/*`
 *     requests to the canonical `/ns/core[/<sub>]` URL,
 *   - `GET /ns/core-bundle.mjs` (bundle mode) — the single-eval core bundle, and
 *   - `GET /ns/core[/<sub>]` — the canonical core URL space. In bundle mode
 *     (default) these serve thin shims over the bundle; with
 *     `NS_CORE_PER_MODULE=1` (core maintainers editing core source in the
 *     monorepo) each core module is served/transformed individually so core
 *     edits participate in HMR. Either way this URL family is the ONE place
 *     @nativescript/core reaches the device (single module realm, shared class
 *     identities, one-time `register()`).
 */
export declare function registerNsCoreRoute(server: ViteDevServer, options: RegisterNsCoreRouteOptions): void;
export {};
