import type { HmrContext } from 'vite';
import type { WebSocketServer } from 'ws';
import type { FrameworkServerStrategy } from './framework-strategy.js';
import type { HmrModuleGraph } from './hmr-module-graph.js';
import type { SharedTransformRequestRunner } from './shared-transform-request.js';
import type { CssUpdateItem } from '../shared/protocol.js';
import type { BootstrapRootComponent } from '../frameworks/angular/server/angular-root-component.js';
/**
 * Dependencies injected into each strategy's `handleHotUpdate` (and the shared
 * {@link runHotUpdatePrologue} it runs first). These hold per-server instance
 * state (`wss`, `moduleGraph`, the file maps, `sharedTransformRequest`) or are
 * plugin-closure accessors. Pure transform helpers (`cleanCode`,
 * `rewriteImports`, `processSfcCode`, `collectImportDependencies`) are NOT on the
 * context — the strategies that need them import them directly from
 * `websocket-device-transform.ts`. `getServerOrigin` is likewise imported
 * directly here from `server-origin.ts` (spy via the module in tests).
 */
export interface NsHotUpdateContext {
    wss: WebSocketServer | null;
    moduleGraph: HmrModuleGraph;
    strategy: FrameworkServerStrategy;
    verbose: boolean;
    sfcFileMap: Map<string, string>;
    depFileMap: Map<string, string>;
    sharedTransformRequest: SharedTransformRequestRunner;
    getHmrSourceRootsCached: () => string[];
    getBootstrapEntryRelPath: () => string;
    isSocketClientOpen: (client: {
        readyState?: number;
        OPEN?: number;
    } | null | undefined) => boolean;
    getHmrSocketRole: (client: {
        __nsHmrClientRole?: string;
    } | null | undefined) => string;
    shouldRemapImport: (spec: string) => boolean;
    rememberAngularReloadSuppression: (root: string, file: string, ttlMs?: number) => void;
    /**
     * Resolves the Angular bootstrap (root) component, or `null` when it
     * can't be statically determined. Used to force root-component template
     * edits through the reboot path instead of Analog's in-place update,
     * which is destructive for the root view (see {@link BootstrapRootComponent}).
     */
    getRootComponentIdentity: () => BootstrapRootComponent | null;
    getGraphInitialPopulationPromise: () => Promise<void> | null;
    appRootDir: string;
}
/** Always-on per-update timing + diagnostics, mutated in place across the prologue and the framework tail. */
export interface HmrUpdateMetrics {
    file: string;
    kind: string;
    t0: number;
    tAfterAwait: number;
    tAfterFramework: number;
    tEnd: number;
    invalidated: number;
    recipients: number;
    narrowed: boolean | undefined;
    emitted: boolean;
}
/** Per-invocation locals computed by {@link runHotUpdatePrologue} and consumed by the per-flavor tail. */
export interface HotUpdatePrologueState {
    root: string;
    updateRel: string;
    metrics: HmrUpdateMetrics;
    emitSummary: () => void;
    /** App CSS output changed during an Angular TS edit; attach it to the reboot message. */
    deferredCssUpdates?: CssUpdateItem[];
}
/**
 * Shared, framework-agnostic prologue for every strategy's `handleHotUpdate`:
 * scope gating, update-metrics setup, the `ns:hmr-pending` broadcast, awaiting the
 * initial graph population, the common module-graph upsert, CSS hot-update +
 * Tailwind content-CSS broadcast, and the project-scope filter. Returns `null`
 * when one of those steps fully handles the change (every such path resolves to
 * Vite's `undefined` result, so the caller just returns), otherwise the
 * per-invocation {@link HotUpdatePrologueState} (`root`, `updateRel`, the live
 * `metrics` object, the idempotent `emitSummary`) the per-flavor tail consumes.
 * Exported so per-flavor strategies can own `prologue + their tail`.
 */
export declare function runHotUpdatePrologue(ctx: HmrContext, deps: NsHotUpdateContext): Promise<HotUpdatePrologueState | null>;
