import { createHash } from 'node:crypto';
export function createNsMResponseMemo(options) {
    const maxEntries = Math.max(1, Math.floor(options?.maxEntries ?? 2000));
    const entries = new Map();
    return {
        buildKey(spec, inputCode, context) {
            const inputHash = createHash('sha1').update(inputCode).digest('hex');
            return `${spec}\u0000${context}\u0000${inputHash}`;
        },
        get(key) {
            const value = entries.get(key);
            if (value !== undefined) {
                // LRU touch: re-insert so iteration order tracks recency.
                entries.delete(key);
                entries.set(key, value);
            }
            return value;
        },
        set(key, body) {
            if (entries.has(key))
                entries.delete(key);
            entries.set(key, body);
            if (entries.size > maxEntries) {
                const oldest = entries.keys().next().value;
                if (oldest !== undefined)
                    entries.delete(oldest);
            }
        },
        size: () => entries.size,
        clear: () => entries.clear(),
    };
}
//# sourceMappingURL=ns-m-response-memo.js.map