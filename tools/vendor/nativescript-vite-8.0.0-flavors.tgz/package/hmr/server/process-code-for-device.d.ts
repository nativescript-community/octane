import type { FrameworkServerStrategy } from './framework-strategy.js';
interface ProcessCodeForDeviceOptions {
    resolvedSpecifierOverrides?: Map<string, string>;
    /**
     * The request being served carries `?ns_worker=1` — it is part of a
     * worker realm's module graph (marker propagated by the /ns/m route), so
     * vendor imports must take the per-module HTTP form regardless of the
     * module's own filename.
     */
    workerRealm?: boolean;
}
/**
 * True when the served module id names a worker ENTRY by the NativeScript
 * `.worker` filename convention (`zip.worker.ts`, `effect.worker`, …). The
 * /ns/m route strips script extensions, so match both the extensionless and
 * extension-carrying forms, ignoring any query suffix.
 */
export declare function isWorkerEntryModuleId(sourceId?: string): boolean;
/**
 * Inline the app's nativescript.config JSON where a served module default-
 * imports it. @nativescript/core's `profiling/index.ts` and
 * `ui/styling/style-scope.ts` do `import appConfig from '~/package.json'`,
 * which Vite resolves to the `nsvite:nsconfig-json` virtual module and emits
 * as `/@id/__x00__nsvite:nsconfig-json`. The generic /@id/ virtual-import
 * strip in processCodeForDevice would delete that import and leave a bare
 * `appConfig` reference — a `ReferenceError: appConfig is not defined` at
 * module eval (hit when monorepo core source is served through /ns/m).
 * Replacing the import with `const <name> = <config-json>;` mirrors what the
 * production build (config-as-json.ts) and the dev core bundle
 * (core-bundle.ts's nsConfigPlugin) already provide.
 */
export declare function inlineNsConfigVirtualImports(code: string): string;
export declare function computeHotContextId(sourceId: string | undefined, projectRoot: string | undefined): string | null;
export declare function buildHotContextPrelude(hotContextId: string): string;
declare function collectImportDependencies(code: string, importerPath: string): Set<string>;
/**
 * Clean code: remove Vite/Vue noise, rewrite to vendor
 */
export interface CleanCodeOptions {
    /**
     * The module evaluates in a worker realm. The main realm installs
     * `@nativescript/core/globals` once from the entry, so a served module's
     * own globals import is redundant there and is stripped; a worker realm
     * has no entry but the worker script itself, and that import is its only
     * source of timers, `console` and the other runtime globals.
     */
    workerRealm?: boolean;
}
declare function cleanCode(code: string, strategy: FrameworkServerStrategy, options?: CleanCodeOptions): string;
/**
 * Process code for device: inject globals, remove framework imports
 */
declare function processCodeForDevice(code: string, isVitePreBundled: boolean, preserveVendorImports?: boolean, isNodeModule?: boolean, sourceId?: string, options?: ProcessCodeForDeviceOptions): string;
export { processCodeForDevice, cleanCode, collectImportDependencies };
