import type { TransformResult } from 'vite';
export interface NsMRequestContext {
    requestUrl: string;
    spec: string;
    forcedVer: string | null;
    bootTaggedRequest: boolean;
    serverRoot: string;
    /**
     * Optional monorepo workspace root for the dev server. When the app
     * lives under `apps/<name>/` inside a hoisted-`node_modules` workspace
     * (Nx / Rush / Turborepo / pnpm / yarn workspaces / npm workspaces),
     * `serverRoot` is the app dir but most packages live at the workspace
     * root. Candidates that resolve there are routed through `/@fs/...`
     * to bypass the package's `package.json#exports` gating which would
     * otherwise refuse internal sub-paths like `css-tree/lib/syntax/...`.
     */
    workspaceRoot?: string | null;
    candidates: string[];
    transformCandidates: string[];
}
export type NsMRequestContextResult = {
    kind: 'next';
} | {
    kind: 'response';
    statusCode: number;
    code: string;
} | {
    kind: 'context';
    value: NsMRequestContext;
};
export interface ResolveNsMTransformedModuleOptions {
    context: NsMRequestContext;
    transformRequest: (url: string, timeoutMs?: number) => Promise<TransformResult | null>;
    resolveId: (id: string) => Promise<string | null>;
    /** Matches `pluginContainer.load`'s LoadResult (which includes `void`). */
    loadVirtualId: (id: string) => Promise<string | {
        code?: string;
    } | TransformResult | null | void>;
    timeoutMs?: number;
}
export interface NsMResolvedTransform {
    transformed: TransformResult | null;
    resolvedCandidate: string | null;
}
export declare function createNsMRequestContext(requestUrl: string, serverRoot: string, appVirtualWithSlash: string, workspaceRoot?: string | null): NsMRequestContextResult;
export declare function resolveNsMTransformedModule(options: ResolveNsMTransformedModuleOptions): Promise<NsMResolvedTransform>;
