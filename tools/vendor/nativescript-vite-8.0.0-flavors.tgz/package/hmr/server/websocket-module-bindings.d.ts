export interface EnsureNativeScriptModuleBindingsOptions {
    preserveNonPluginVendorImports?: boolean;
    resolvedSpecifierOverrides?: Map<string, string>;
    /**
     * Rewrite vendor/plugin imports to their `/ns/m/node_modules/<pkg>` HTTP
     * ESM form instead of the `__nsVendorRequire` registry shim.
     *
     * Worker realms need this: the vendor registry (`__nsVendorRegistry` /
     * `__nsRequire`) is installed by the MAIN realm's dev-session bootstrap
     * and never exists inside a `new Worker(...)` context, so the registry
     * shim's fallback to the native `require()` fails for every vendor
     * package (observed with `@nativescript/zip` in a zip worker on a fresh
     * install — the first boot's DB unzip was the first code path to ever
     * exercise a vendor require inside a worker). The HTTP form gives the
     * worker its own realm-local copy via the deps-bundle bridge — the same
     * isolation semantics webpack's per-worker bundles had.
     */
    vendorImportsAsHttp?: boolean;
}
export declare function ensureNativeScriptModuleBindings(code: string, options?: EnsureNativeScriptModuleBindingsOptions): string;
export declare function getProcessCodeResolvedSpecifierOverrides(sourceId: string | undefined, projectRoot: string): Map<string, string> | undefined;
