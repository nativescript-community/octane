/**
 * Import Map Generator for NativeScript HMR
 *
 * Generates an import map that the iOS/Android runtime consumes via
 * ns:module configureLoader(). This is the single source of truth for module
 * resolution on the device.
 *
 * Resolution strategy:
 *   Every bare npm specifier → HTTP URL (`/ns/m/node_modules/<pkg>`).
 *     Package roots in the vendor collection get EXACT entries whose served
 *     body is a deps-bundle shim (see deps-bundle.ts), so "many specifiers,
 *     one instance" holds via the single bundle realm — no custom URL scheme.
 *   @nativescript/core → HTTP bridge URL (/ns/core)
 *   Trailing-slash prefix entries cover subpath imports
 *     (e.g. @nativescript/tanstack-router/solid) for every package.
 *
 * The runtime matches map keys literally: it reverse-engineers none of Vite's
 * rewrites (`/node_modules/.vite/deps/solid-js.js?v=…`, `/@id/…`, `/@fs/…`).
 * Every specifier form that reaches the device must therefore either be a key
 * in this map or be rewritten by the server before it is served — the /ns/m
 * pipeline (`processCodeForDevice`) turns prebundled-dep paths back into bare
 * ids and resolves package-internal paths to full `/ns/m/node_modules/…` URLs.
 */
import type { FrameworkServerStrategy } from './framework-strategy.js';
export interface ImportMap {
    imports: Record<string, string>;
}
export interface ImportMapOptions {
    /** Origin of the Vite dev server (e.g. "http://192.168.1.5:5173") */
    origin: string;
    /** Framework flavor (vue, angular, solid, typescript) — framework identity. */
    flavor: string;
    /**
     * Active framework strategy. Its `importMapEntries(origin)` +
     * `volatilePatterns()` hooks supply the framework-specific pieces of the
     * import map and volatile-pattern list.
     * Optional: when omitted, the map/patterns carry only the shared
     * vendor/core/HTTP entries.
     */
    strategy?: FrameworkServerStrategy;
    /** Additional entries to add to the import map */
    extraEntries?: Record<string, string>;
}
/**
 * Generate an import map from the current vendor manifest.
 *
 * Vendor package roots map to `${origin}/ns/m/node_modules/<pkg>` — served
 * as deps-bundle shims (thin re-exports out of `__NS_DEPS_MODULES__`, the
 * single-evaluation bundle realm), so every specifier of a package resolves
 * to one instance. Manifest aliases collapse onto their canonical package's
 * URL, preserving the "many specifiers, one instance" semantics.
 *
 * IMPORTANT: Vendor entries are EXACT only (no trailing-slash prefixes).
 * Subpath imports like solid-js/store or @nativescript/tanstack-router/solid
 * are separate entry points with different exports — they must NOT resolve
 * to the package root. They fall through to the HTTP trailing-slash prefix
 * entries from discoverInstalledPackages().
 *
 * @nativescript/core is mapped to the HTTP bridge endpoint.
 * Everything else falls through to the runtime's normal resolution.
 */
export declare function generateImportMap(options: ImportMapOptions): ImportMap;
/**
 * Get volatile URL patterns for the current framework.
 * These patterns tell the runtime to always re-fetch matching URLs
 * instead of using cached modules.
 */
export declare function getVolatilePatterns(strategy?: FrameworkServerStrategy): string[];
/**
 * The URL canonicalization vocabulary handed to the runtime via
 * `configureLoader({ canonicalization })`. The runtime owns the *mechanism*
 * (fragment strip, cache-buster param drop, param sort — it keys the module
 * registry inside the engine's synchronous resolve walk); this server owns
 * the *vocabulary*, because every name in it is a route this server defines:
 *
 * - `stripParams`: Vite's `import` marker and `t`/`v` cache stamps — pure
 *   cache busters that must not create distinct module identities.
 * - `forPathPrefixes`: the dev endpoints under which query normalization is
 *   safe. Everything else (public/remote URLs) keeps its query verbatim,
 *   since for general HTTP modules the query can be identity (auth,
 *   content versioning, routing).
 * - `preserveQueryFor`: strategy-owned paths whose query IS the module
 *   identity (e.g. Angular's `/@ng/component?c=<id>&t=<ts>` — each `t` is a
 *   distinct metadata recompile).
 */
export declare function getCanonicalization(strategy?: FrameworkServerStrategy): {
    stripParams: string[];
    forPathPrefixes: string[];
    preserveQueryFor: string[];
};
/**
 * Serialize the import map + volatile patterns + canonicalization vocabulary
 * into the config object that ns:module configureLoader() expects.
 */
export declare function buildRuntimeConfig(options: ImportMapOptions): {
    importMap: string;
    volatilePatterns: string[];
    canonicalization: ReturnType<typeof getCanonicalization>;
};
