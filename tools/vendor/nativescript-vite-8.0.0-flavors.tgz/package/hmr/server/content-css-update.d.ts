import type { ViteDevServer } from 'vite';
import type { WebSocketServer } from 'ws';
import type { CssUpdateItem } from '../shared/protocol.js';
export interface ContentCssUpdateOptions {
    server: ViteDevServer;
    file: string;
    root: string;
    wss: WebSocketServer;
    isSocketClientOpen: (client: {
        readyState?: number;
        OPEN?: number;
    } | null | undefined) => boolean;
    /**
     * The active framework strategy's `defersContentCssToFrameworkUpdate`
     * verdict for this file: `true` routes the update into the framework's own
     * message (returned as `deferredCssUpdates`) instead of broadcasting.
     */
    deferToFrameworkUpdate: boolean;
    verbose: boolean;
}
export interface ContentCssUpdateResult {
    /** Present when the framework tail must carry the CSS update in its own message. */
    deferredCssUpdates?: CssUpdateItem[];
    /** Open sockets the standalone `ns:css-updates` broadcast reached. */
    recipients: number;
}
/**
 * Tailwind / content-scanning CSS routing for non-CSS edits.
 *
 * Background: when a `.html` template or `.ts` file scanned by Tailwind's
 * `content` config gains a brand-new utility class (e.g. a `pt-6` never used
 * before), the booted CSS bundle has no rule for it — the template HMR swaps
 * the markup, the class lookup misses, and the layout regresses.
 *
 * In a stock Vite setup the `vite:css` plugin registers each PostCSS content
 * dependency as an importer of the CSS module, so a content edit invalidates
 * the CSS through the moduleGraph. NS HMR breaks that chain: `app.css` loads
 * through `virtual:ns-app-css` whose `load` hook calls `preprocessCSS(...)`
 * and emits a JS module — the CSS is never a moduleGraph node, so the importer
 * chain never forms. `mainEntryPlugin` bridges the gap by tracking the
 * `preprocessCSS` dep set on the server (see `AppCssState`).
 *
 * When the changed file is in that set, regenerate the stylesheet and compare
 * with the previous output. Ordinary content edits are skipped; output that
 * actually changed is either broadcast as `ns:css-updates` or — when the
 * framework's own update message must carry it (Angular TS reboots, via the
 * `defersContentCssToFrameworkUpdate` strategy hook) — returned as
 * `deferredCssUpdates` so the device serializes CSS with the framework's
 * update cycle instead of racing view-tree teardown.
 *
 * Never throws: refresh is non-throwing by contract and the broadcast guards
 * each send.
 */
export declare function processContentCssUpdate(opts: ContentCssUpdateOptions): Promise<ContentCssUpdateResult>;
