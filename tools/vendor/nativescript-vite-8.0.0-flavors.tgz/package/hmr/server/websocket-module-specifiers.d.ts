import type { VendorManifest } from '../shared/vendor/manifest.js';
export declare function extractVitePrebundleId(spec: string): string | null;
export declare function getFlattenedManifestMap(manifest: VendorManifest): Map<string, string>;
export declare function normalizeNativeScriptCoreSpecifier(spec: string): string;
export declare function normalizeNodeModulesSpecifier(spec: string): string | null;
export declare function isEsmFrameworkPackageSpecifier(spec: string): boolean;
export declare function isCoreGlobalsReference(spec: string): boolean;
export declare function isNativeScriptCoreModule(spec: string): boolean;
export declare function isNativeScriptPluginModule(spec: string): boolean;
/** A registered flavor's client package is dev tooling the device loads per-module, like `@nativescript/vite`. */
export declare function isFlavorClientPackageSpecifier(spec: string): boolean;
export declare function getBlockedDeviceNodeModulesReason(spec: string): string | null;
export declare function isLikelyNativeScriptRuntimePluginSpecifier(spec: string, projectRoot?: string): boolean;
export declare function isLikelyNativeScriptPluginSpecifier(spec: string, projectRoot?: string): boolean;
export declare function tryReadRawExplicitJavaScriptModule(spec: string, projectRoot: string): {
    code: string;
    resolvedId: string;
} | null;
export declare function resolveVendorFromCandidate(specifier: string | null | undefined): string | null;
/**
 * Resolve a candidate URL ('/node_modules/...', '/@fs/...', or an
 * absolute fs path) to a real file on disk under one of the allowed
 * roots, returning the absolute fs path or `null`.
 *
 * `workspaceRoot` is consulted ONLY when the candidate cannot be
 * resolved under `projectRoot` — this keeps the existing app-local
 * behaviour identical and adds a fallback for monorepos where
 * `node_modules/` is hoisted above the app dir (Nx, Rush, Turborepo,
 * etc.). Without this fallback, every `/ns/m/node_modules/<hoisted-pkg>`
 * request to the dev server's bridge fails with a "transform miss"
 * 404 even though the file is right there at the workspace root.
 */
export declare function resolveCandidateFilePath(candidate: string, projectRoot: string, workspaceRoot?: string | null): string | null;
/**
 * Rewrite a `/@fs/<abs-path>` URL into a `/ns/m/<rel>` URL so the chain
 * stays inside our HMR pipeline.
 *
 * Vite's transform output emits `/@fs/<abs-path>` for any module whose
 * resolved id lives outside the configured `root` — including hoisted
 * `node_modules/<pkg>/...` entries and workspace libraries in monorepos
 * (Nx, Rush, Turborepo, pnpm/yarn/npm workspaces, etc.). If we leave
 * those URLs untouched, the device fetches them through Vite's standard
 * middleware which does NOT apply our CJS/UMD-wrapping pipeline; UMD
 * modules like papaparse then crash because top-level `this` is
 * `undefined` in ESM context (the `(function(root, factory) { ... })(this,
 * function moduleFactory() { ... })` IIFE passes `undefined` as `root`
 * and the third branch tries to do `undefined.Papa = factory()`).
 *
 * The conversion preserves any `?...` / `#...` suffix and tries roots in
 * this order:
 *   1. `projectRoot` — app-local files; mirrors the URL shape we already
 *      emit for relative imports under the app's own dir.
 *   2. `workspaceRoot` — hoisted `node_modules` and monorepo workspace
 *      libs. The `/ns/m/` handler resolves these via its
 *      `buildFsCandidate` fallback that probes both roots.
 *
 * Returns `null` when the absolute path is outside both roots; the
 * caller should then leave the original `/@fs/` URL alone (defensive).
 */
export declare function rewriteFsAbsoluteToNsM(spec: string, projectRoot: string, workspaceRoot?: string | null): string | null;
/**
 * Filter `candidates` (variations of `spec` with different extensions /
 * `index.*`) down to those that exist on disk under `projectRoot` or
 * `workspaceRoot`. Workspace-root-only matches are rewritten to their
 * `/@fs/<abs-path>` form so the downstream `transformRequest` call can
 * load them directly without having to go through Vite's bare-specifier
 * resolver — which is gated by the package's `package.json#exports`
 * field and refuses internal sub-paths even when the file is on disk
 * (e.g. `css-tree/lib/syntax/index.js`).
 *
 * Candidates whose real path (after symlink resolution) lives OUTSIDE
 * any `node_modules` directory are also rewritten to `/@fs/<real-path>`.
 * Vite's built-in esbuild transform plugin excludes `node_modules` paths
 * from TS->JS conversion, so a workspace TypeScript package re-exposed
 * via `node_modules/<scope>/<pkg>` (a common monorepo pattern: e.g.
 * `node_modules/@blackout/plugins -> ../../plugins/src`) would otherwise
 * be served as raw TypeScript and fail at the device with `Missing
 * initializer in const declaration` on type annotations like
 * `export const X: string = '...'`. Routing through the realpath makes
 * Vite see a non-`node_modules` path and the TS transform applies.
 *
 * App-local candidates whose real path is also app-local are returned
 * unchanged so existing behaviour is preserved bit-for-bit.
 */
export declare function filterExistingNodeModulesTransformCandidates(spec: string, candidates: string[], projectRoot: string, workspaceRoot?: string | null): string[];
export declare function viteDepsPathToBareSpecifier(depPath: string): string | null;
export declare function resolveNodeModulesPackageBoundary(nodeModulesSpec: string, projectRoot: string): {
    packageName: string;
    subpath: string;
};
export declare function resolveInternalRuntimePluginBareSpecifier(spec: string, projectRoot: string): string | null;
export declare function shouldPreserveBareRuntimePluginSubpathImport(spec: string, projectRoot: string): boolean;
export declare function resolveVendorRouting(nodeModulesSpec: string, projectRoot: string): {
    route: 'vendor';
    bareSpec: string;
} | {
    route: 'http';
} | null;
