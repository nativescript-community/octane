/** Shim for a bare `vue`/`nativescript-vue` import. */
export declare function buildVueVendorShim(pkg: 'vue' | 'nativescript-vue'): string;
/** Shim for a bare `pinia` import. */
export declare function buildPiniaVendorShim(): string;
