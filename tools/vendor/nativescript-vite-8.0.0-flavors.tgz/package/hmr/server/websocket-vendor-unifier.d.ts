import type { ViteDevServer } from 'vite';
import type { FrameworkServerStrategy } from './framework-strategy.js';
export interface RegisterVendorUnifierHandlerOptions {
    getGraphVersion(): number;
    getStrategy(): FrameworkServerStrategy;
}
export declare function shouldHandleVendorUnifierPath(pathname: string): boolean;
export declare function maybeRewriteVendorModule(code: string, strategy: FrameworkServerStrategy, origin: string, version: number): string;
export declare function registerVendorUnifierHandler(server: ViteDevServer, options: RegisterVendorUnifierHandlerOptions): void;
