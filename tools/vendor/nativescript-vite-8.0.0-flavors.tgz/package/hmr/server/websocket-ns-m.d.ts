import type { TransformResult, ViteDevServer } from 'vite';
import { type DepsBundleService } from './deps-bundle.js';
import type { FrameworkServerStrategy } from './framework-strategy.js';
type SharedTransformRequestFn = (url: string, timeoutMs?: number) => Promise<TransformResult | null>;
type UpsertGraphModuleFn = (rawId: string, code: string, deps: string[], options?: {
    bumpVersion?: boolean;
    emitDeltaOnInsert?: boolean;
    broadcastDelta?: boolean;
}) => void;
/**
 * Plugin-closure dependencies the `/ns/m` device module server needs. The pure
 * transform/codegen functions are imported directly from
 * `websocket-device-transform.ts`; only genuine plugin state (graph version,
 * strategy, shared transform runner, graph upsert) is injected here.
 */
export interface RegisterNsModuleServerRouteOptions {
    verbose: boolean;
    appVirtualWithSlash: string;
    sfcFileMap: Map<string, string>;
    depFileMap: Map<string, string>;
    getGraphVersion(): number;
    getStrategy(): FrameworkServerStrategy;
    sharedTransformRequest: SharedTransformRequestFn;
    ensureInitialGraphPopulationStarted(server: ViteDevServer): void;
    upsertGraphModule: UpsertGraphModuleFn;
    /**
     * Injectable deps-bundle service (testability seam). When omitted, the
     * shared process-wide service is used — null when `NS_DEPS_PER_MODULE=1`
     * forces per-module node_modules serving.
     */
    depsBundle?: DepsBundleService | null;
    /**
     * Live-broadcast gate for AnalogJS `/@ng/component` metadata fetches.
     * When provided, only fetches whose `(c, t)` pair matches a recorded
     * `angular:component-update` broadcast are delegated to Analog's
     * middleware; everything else — most importantly the boot-time
     * `<Class>_HmrLoad(Date.now())` fetch every compiled component issues on
     * evaluation — is answered with the empty no-update stub. See the ledger
     * in `websocket-angular-hot-update.ts` for the full failure mode this
     * prevents (post-edit relaunch → boot-time `ɵɵreplaceMetadata` on the
     * root component → white screen).
     */
    isLiveAngularComponentUpdateFetch?(componentId: string, timestamp: number): boolean;
}
/**
 * Registers the `/ns/m/*` device module server: the HTTP endpoint every
 * NativeScript device uses to fetch app/source modules (and AnalogJS Angular
 * `/@ng/component` live-reload requests) as device-ready ESM. This is the
 * single hottest route in the HMR server.
 */
export declare function registerNsModuleServerRoute(server: ViteDevServer, options: RegisterNsModuleServerRouteOptions): void;
export {};
