// Pure helpers for the device code-transform subsystem: import-path
// normalization, node_modules/vendor specifier resolution, dependency
// collection support, and provenance preludes. Shared by
// process-code-for-device.ts and rewrite-imports.ts.
import * as path from 'path';
import { existsSync } from 'fs';
import * as PAT from './constants.js';
import { getProjectRootPath } from '../../helpers/project.js';
import { isLikelyNativeScriptRuntimePluginSpecifier, isNativeScriptCoreModule, isNativeScriptPluginModule, normalizeNativeScriptCoreSpecifier, normalizeNodeModulesSpecifier, resolveNodeModulesPackageBoundary, resolveVendorFromCandidate, viteDepsPathToBareSpecifier } from './websocket-module-specifiers.js';
import { collectTopLevelImportRecords } from './websocket-served-module-helpers.js';
// Bare specifiers and special skip patterns (virtual, data:, etc.)
const VENDOR_PACKAGES = /^[A-Za-z@][^:\/\s]*$/;
const SKIP_PATTERNS = /^(?:data:|blob:|node:|virtual:|vite:|\0|\/@@?id|\/__vite|__vite|__x00__)/;
// One warning per dep so vendor-manifest misses are visible without spamming
// the console on every served module.
const warnedVendorMisses = new Set();
/**
 * Vendor-manifest miss fallback — e.g. `emoji-regex`, a transitive dep of
 * @nativescript/core that is never part of the vendor bundle. Dropping the
 * import leaves the consumer with an undefined binding at runtime
 * ("emojiRegexModule is not defined"), so instead derive a bare specifier from
 * Vite's flattened prebundle id; the later rewriteImports pass routes it to
 * /ns/m/node_modules/<pkg> and the package is served over HTTP like any other
 * node_modules subpath.
 *
 * Vite's flattenId encodes `/` as `_`, so the decoding is ambiguous (package
 * names may legitimately contain `_`). For scoped ids the first `_` is the
 * scope slash. Each candidate is verified against node_modules on disk before
 * being committed; if nothing resolves, the first candidate is used anyway —
 * a loud 404 on device beats a silent undefined binding.
 */
function decodeFlattenedDepId(flat) {
    // Reverse Vite's flattenId, which encodes '.' as '__' and '/' (and ':') as
    // '_'. Split on the '__' (dot) boundaries first so a single '_' inside each
    // segment becomes a '/', then rejoin the segments with '.'. This avoids any
    // placeholder sentinel (a literal NUL would corrupt the served module).
    return flat
        .split('__')
        .map((segment) => segment.replace(/_/g, '/'))
        .join('.');
}
function packageIsInstalled(packageName) {
    if (!packageName)
        return false;
    try {
        return existsSync(path.join(getProjectRootPath(), 'node_modules', ...packageName.split('/'), 'package.json'));
    }
    catch {
        return false;
    }
}
function bareSpecifierFromFlatDepPath(depPath) {
    const flat = depPath.split('?')[0].replace(/\.m?js$/, '');
    // flattenId is lossy (names may contain '_'), so build candidates from the
    // most-decoded form down to the raw flat id and pick the first that maps to a
    // package actually present in node_modules. Without this, a NON-scoped subpath
    // dep such as `solid-js/web` (flattened to `solid-js_web`) was never decoded
    // back — only scoped ids were — so it resolved to the bogus package
    // `solid-js_web` and 404'd over HTTP on device.
    const candidates = [];
    const pushCandidate = (c) => {
        if (c && !candidates.includes(c))
            candidates.push(c);
    };
    pushCandidate(decodeFlattenedDepId(flat));
    if (flat.startsWith('@')) {
        // Scope-only decode: just the first '_' is the scope separator.
        pushCandidate(flat.replace('_', '/'));
    }
    pushCandidate(flat);
    let resolved = null;
    for (const candidate of candidates) {
        try {
            const { packageName } = resolveNodeModulesPackageBoundary(candidate, getProjectRootPath());
            // Require the resolved package to exist on disk so a decode that merely
            // *parses* (e.g. the bogus `solid-js_web`) does not win over the real one.
            if (packageName && packageIsInstalled(packageName)) {
                resolved = candidate;
                break;
            }
        }
        catch { }
    }
    const bareSpecifier = resolved || candidates[0];
    if (!warnedVendorMisses.has(depPath)) {
        warnedVendorMisses.add(depPath);
        console.warn(`[ns-vite] vendor-manifest miss: prebundled dep '${depPath}' is not in the vendor bundle — serving '${bareSpecifier}' over HTTP via /ns/m/node_modules/${resolved ? '' : ' (could not verify the package on disk; the specifier is a best-effort decode of the flattened id)'}.`);
    }
    return bareSpecifier;
}
function rewriteVitePrebundleImportsForDevice(code, preserveVendorImports) {
    const imports = collectTopLevelImportRecords(code);
    if (!imports.length) {
        return code;
    }
    const edits = [];
    for (const imp of imports) {
        const source = imp.source;
        const depMatch = source.match(/(?:^|\/)node_modules\/\.vite\/deps\/(.+)$/);
        const depPath = depMatch?.[1] || (source.startsWith('.vite/deps/') ? source.slice('.vite/deps/'.length) : null);
        if (!depPath) {
            continue;
        }
        let replacement = '';
        if (preserveVendorImports) {
            const canonical = resolveVendorFromCandidate(`.vite/deps/${depPath}`);
            let bareSpecifier = canonical || viteDepsPathToBareSpecifier(depPath);
            if (!bareSpecifier) {
                bareSpecifier = bareSpecifierFromFlatDepPath(depPath);
            }
            if (bareSpecifier) {
                replacement = imp.text.replace(source, bareSpecifier);
            }
        }
        edits.push({
            start: imp.start,
            end: imp.end,
            text: replacement,
        });
    }
    if (!edits.length) {
        return code;
    }
    let next = code;
    for (const edit of edits.sort((left, right) => right.start - left.start)) {
        next = next.slice(0, edit.start) + edit.text + next.slice(edit.end);
    }
    return next;
}
function buildNodeModuleProvenancePrelude(sourceId) {
    if (!sourceId) {
        return '';
    }
    const cleaned = sourceId.replace(PAT.QUERY_PATTERN, '');
    let normalized = normalizeNodeModulesSpecifier(cleaned);
    if (!normalized) {
        const viteDepsMatch = cleaned.match(/(?:^|\/)node_modules\/\.vite\/deps\/([^?#]+)/);
        if (viteDepsMatch?.[1]) {
            normalized = `.vite/deps/${viteDepsMatch[1]}`;
        }
    }
    if (!normalized) {
        return '';
    }
    let packageSpecifier = normalized;
    let via = 'node_modules';
    if (normalized.startsWith('.vite/deps/')) {
        via = 'vite-deps';
        packageSpecifier = viteDepsPathToBareSpecifier(normalized.slice('.vite/deps/'.length)) || normalized;
    }
    const rootPackage = resolveNodeModulesPackageBoundary(packageSpecifier, getProjectRootPath()).packageName;
    if (!rootPackage) {
        return '';
    }
    return `try { const __nsRecord = globalThis.__NS_RECORD_MODULE_PROVENANCE__; if (typeof __nsRecord === 'function') { __nsRecord(${JSON.stringify(rootPackage)}, ${JSON.stringify({ kind: 'http-esm', specifier: packageSpecifier, url: sourceId, via })}); } } catch {}\n`;
}
function shouldRemapImport(spec) {
    if (!spec || typeof spec !== 'string')
        return false;
    if (VENDOR_PACKAGES.test(spec))
        return false;
    if (isNativeScriptCoreModule(spec))
        return false;
    if (isNativeScriptPluginModule(spec))
        return false;
    if (resolveVendorFromCandidate(spec))
        return false;
    if (spec.startsWith('~/'))
        return false;
    if (SKIP_PATTERNS.test(spec))
        return false;
    if (!spec.startsWith('/') && !spec.startsWith('./') && !spec.startsWith('../')) {
        return false;
    }
    return true;
}
function removeNamedImports(code, names) {
    const regex = /^(\s*import\s*\{)([^}]*)(\}\s*from\s*['"][^'"]+['"];?)/gm;
    return code.replace(regex, (_m, p1, specList, p3) => {
        const srcMatch = /from\s*['"]\s*([^'"\s]+)\s*['"]/i.exec(_m);
        const src = (srcMatch?.[1] || '').toLowerCase();
        const isVueSource = /^(?:vue|nativescript-vue)(?:\b|\/)/i.test(src);
        if (!isVueSource) {
            return _m;
        }
        const remaining = specList
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
            .filter((entry) => {
            const base = entry.split(/\s+as\s+/i)[0].trim();
            return !names.includes(base);
        });
        if (!remaining.length)
            return '';
        return `${p1} ${remaining.join(', ')} ${p3}`;
    });
}
function normalizeImportPath(spec, importerDir) {
    if (!spec)
        return null;
    let key;
    if (spec.startsWith('/')) {
        key = spec;
    }
    else if (spec.startsWith('./') || spec.startsWith('../')) {
        key = path.posix.normalize(path.posix.join(importerDir, spec));
        if (!key.startsWith('/')) {
            key = `/${key}`;
        }
    }
    else {
        key = spec;
    }
    return key.replace(PAT.QUERY_PATTERN, '');
}
function findDependencyFileName(depFileMap, key) {
    const variants = new Set();
    const base = key.replace(PAT.QUERY_PATTERN, '');
    variants.add(base);
    const normalized = path.posix.normalize(base);
    variants.add(normalized);
    const withSlash = normalized.startsWith('/') ? normalized : `/${normalized}`;
    variants.add(withSlash);
    for (const variant of Array.from(variants)) {
        if (variant.endsWith('.js')) {
            variants.add(variant.replace(/\.js$/i, '.mjs'));
        }
        else if (variant.endsWith('.mjs')) {
            variants.add(variant.replace(/\.mjs$/i, '.js'));
        }
    }
    for (const variant of variants) {
        const value = depFileMap.get(variant);
        if (value) {
            return value;
        }
    }
    return undefined;
}
function isRuntimePluginRootEntrySpecifier(specifier, projectRoot) {
    if (!specifier) {
        return false;
    }
    const cleaned = specifier.replace(PAT.QUERY_PATTERN, '');
    const normalized = normalizeNodeModulesSpecifier(cleaned) || cleaned.replace(/^\/+/, '');
    if (!normalized) {
        return false;
    }
    const { packageName, subpath } = resolveNodeModulesPackageBoundary(normalized, projectRoot);
    if (!packageName || !isLikelyNativeScriptRuntimePluginSpecifier(packageName, projectRoot)) {
        return false;
    }
    if (!subpath) {
        return true;
    }
    if (subpath.includes('/')) {
        return false;
    }
    const pkgBaseName = packageName.split('/').pop() || '';
    const withoutExt = /(?:\.(?:ios|android|visionos))?\.(?:ts|tsx|js|jsx|mjs|mts|cts)$/i.test(subpath) ? subpath.replace(/\.[^.]+$/, '') : subpath;
    const withoutPlatform = withoutExt.replace(/\.(ios|android|visionos)$/i, '');
    return withoutPlatform === 'index' || withoutPlatform === pkgBaseName;
}
function collectMixedRuntimePluginHttpRootPackages(code, projectRoot) {
    const nonRootSubpathPackages = new Set();
    const rootEntryPackages = new Set();
    const visitSpecifier = (rawSpecifier) => {
        if (!rawSpecifier) {
            return;
        }
        const specifier = normalizeNativeScriptCoreSpecifier(rawSpecifier).replace(PAT.QUERY_PATTERN, '');
        if (!specifier) {
            return;
        }
        if (/^https?:\/\//.test(specifier) || specifier.startsWith('/ns/')) {
            return;
        }
        if (/^(?:\.|\/)/.test(specifier) && !specifier.includes('/node_modules/')) {
            return;
        }
        const normalized = normalizeNodeModulesSpecifier(specifier) || specifier.replace(/^\/+/, '');
        if (!normalized) {
            return;
        }
        const { packageName } = resolveNodeModulesPackageBoundary(normalized, projectRoot);
        if (!packageName || !isLikelyNativeScriptRuntimePluginSpecifier(packageName, projectRoot)) {
            return;
        }
        if (isRuntimePluginRootEntrySpecifier(normalized, projectRoot)) {
            rootEntryPackages.add(packageName);
            return;
        }
        nonRootSubpathPackages.add(packageName);
    };
    for (const pattern of [PAT.IMPORT_PATTERN_1, PAT.IMPORT_PATTERN_2, PAT.IMPORT_PATTERN_3, PAT.IMPORT_PATTERN_SIDE_EFFECT]) {
        pattern.lastIndex = 0;
        let match;
        while ((match = pattern.exec(code)) !== null) {
            visitSpecifier(match[2]);
        }
    }
    return new Set(Array.from(nonRootSubpathPackages).filter((packageName) => rootEntryPackages.has(packageName)));
}
// Application import helpers
/**
 * Check if a path is an application module (not node_modules, not vendor, not relative)
 * This is generic and works for ANY project structure.
 *
 * Examples of application imports: /core/v4/store.ts, /src/utils/helper.ts, /custom/module.ts
 * Examples of NON-application imports: node_modules/..., ~/vendor.mjs, ./relative.ts, ../parent.ts
 */
function isApplicationImport(importPath) {
    if (!importPath.startsWith('/')) {
        return false; // Relative paths (./..., ../...) are not application imports
    }
    // Exclude node_modules and special paths
    if (importPath.includes('node_modules') || importPath.startsWith('/@') || importPath.startsWith('~/')) {
        return false;
    }
    return true;
}
function stripToProjectRelative(importPath, projectRoot) {
    if (!importPath) {
        return '';
    }
    let normalized = importPath.replace(/\\/g, '/');
    normalized = normalized.replace(/^\/?@fs\//, '/');
    if (normalized.startsWith('file://')) {
        normalized = normalized.replace(/^file:\/\//, '/');
    }
    const documentsMarker = '/Documents/';
    const documentsIndex = normalized.indexOf(documentsMarker);
    if (documentsIndex !== -1) {
        return normalized.substring(documentsIndex + documentsMarker.length);
    }
    if (projectRoot) {
        const normalizedRoot = projectRoot.replace(/\\/g, '/').replace(/\/+$/, '');
        const rootIndex = normalized.indexOf(normalizedRoot);
        if (rootIndex !== -1) {
            const sliced = normalized.substring(rootIndex + normalizedRoot.length);
            return sliced.replace(/^\/+/, '');
        }
    }
    return normalized.replace(/^\/+/, '');
}
/**
 * Convert absolute application import to relative .mjs path for Documents folder
 * /core/v4/store.ts → ./core/v4/store.mjs
 */
function getProjectRelativeImportPath(importPath, projectRoot) {
    if (!importPath) {
        return null;
    }
    let normalized = importPath.replace(PAT.QUERY_PATTERN, '');
    normalized = normalized.replace(/\\/g, '/');
    if (normalized.startsWith('file://')) {
        normalized = normalized.replace(/^file:\/\//, '/');
    }
    const documentsMarker = '/Documents/';
    const documentsIndex = normalized.indexOf(documentsMarker);
    if (documentsIndex !== -1) {
        normalized = normalized.substring(documentsIndex + documentsMarker.length);
    }
    else if (projectRoot) {
        const normalizedRoot = projectRoot.replace(/\\/g, '/').replace(/\/+$/, '');
        const rootIndex = normalized.indexOf(normalizedRoot);
        if (rootIndex !== -1) {
            normalized = normalized.substring(rootIndex + normalizedRoot.length);
        }
    }
    normalized = normalized.replace(/^\/+/, '');
    if (!normalized) {
        return null;
    }
    if (normalized.startsWith('dep-')) {
        return null;
    }
    if (normalized.startsWith('sfc-')) {
        return null;
    }
    normalized = path.posix.normalize(normalized);
    if (!normalized) {
        return null;
    }
    normalized = normalized.replace(/\.(ts|js|tsx|jsx|mjs|mts|cts)$/i, '.mjs');
    if (!normalized.endsWith('.mjs')) {
        normalized = `${normalized}.mjs`;
    }
    return normalized.replace(/^\/+/, '');
}
function toAppModuleBaseId(importPath, projectRoot) {
    const projectRelative = getProjectRelativeImportPath(importPath, projectRoot);
    if (!projectRelative) {
        return null;
    }
    const base = projectRelative.replace(/\.mjs$/i, '');
    return `/${base}`;
}
function toNodeModulesHttpModuleId(importPath) {
    const nodeModulesSpecifier = normalizeNodeModulesSpecifier(importPath);
    if (!nodeModulesSpecifier) {
        return null;
    }
    return `/ns/m/node_modules/${nodeModulesSpecifier}`;
}
export { rewriteVitePrebundleImportsForDevice, buildNodeModuleProvenancePrelude, shouldRemapImport, removeNamedImports, normalizeImportPath, findDependencyFileName, collectMixedRuntimePluginHttpRootPackages, isApplicationImport, stripToProjectRelative, getProjectRelativeImportPath, toAppModuleBaseId, toNodeModulesHttpModuleId };
//# sourceMappingURL=device-transform-helpers.js.map