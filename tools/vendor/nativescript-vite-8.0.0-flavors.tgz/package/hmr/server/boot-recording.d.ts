export declare const BOOT_RECORDING_VERSION = 1;
/** Endpoints whose request marks the start of a device boot. */
export declare const BOOT_SIGNAL_PATHS: ReadonlySet<string>;
/**
 * True when a request path is served through the device module loader and is
 * therefore worth recording for the next boot's deps bundle. Matches the URL
 * spaces the HTTP ESM loader fetches: `/ns/m/**`, the `/ns/rt` + `/ns/core`
 * bridges, the core and deps bundles, Vue SFC artifacts, the served vendor
 * bundle, and the dev client bootstrap.
 */
export declare function isPrefetchableBootPath(pathWithSearch: string): boolean;
export declare function getBootRecordingFilePath(projectRoot: string, platform: string, flavor: string): string;
/** Load a persisted recording; null when absent, invalid, or mismatched. */
export declare function loadPersistedBootRecording(projectRoot: string, platform: string, flavor: string): string[] | null;
export type BootRecorderOptions = {
    platform: string;
    flavor: string;
    projectRoot: string;
    /** Recording window closes after this many ms without boot requests (default 5000). */
    idleWindowMs?: number;
    /** Windows with fewer recorded entries are discarded as non-boots (default 5). */
    minEntries?: number;
    /** Hard cap on the recorded list (default 5000). */
    maxEntries?: number;
    /** Disable disk persistence (tests). */
    persist?: boolean;
    now?: () => number;
    setTimer?: (handler: () => void, ms: number) => unknown;
    clearTimer?: (handle: unknown) => void;
    log?: (line: string) => void;
};
export type BootRecorder = {
    /**
     * Feed a request path (pathname + search). Boot-signal paths open a new
     * recording session and return null. Prefetchable paths inside an active
     * session return a finish callback the caller must invoke with the
     * response status code; only 2xx completions are recorded.
     */
    noteRequest(pathWithSearch: string): ((statusCode: number) => void) | null;
    /** Most recent completed (or persisted) recording; null when none. */
    getRecordedPaths(): string[] | null;
    /** Force-close the active session (idle close path; exposed for tests). */
    closeActiveSession(): void;
};
export declare function createBootRecorder(options: BootRecorderOptions): BootRecorder;
/**
 * Standard dev-server construction: resolves platform/flavor from the
 * project, honors `NS_VITE_HMR_DISABLE_BOOT_RECORDING` (returns null) and
 * `NS_VITE_HMR_BOOT_RECORD_IDLE_MS`.
 */
export declare function createBootRecorderFromEnv(projectRoot: string, log?: (line: string) => void): BootRecorder | null;
