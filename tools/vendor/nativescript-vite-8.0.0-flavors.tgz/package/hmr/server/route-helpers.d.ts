import type { ServerResponse } from 'node:http';
/**
 * Response headers for device-served ESM module endpoints: permissive CORS plus
 * aggressive no-store caching so the device never reuses a stale module across
 * HMR cycles.
 */
export declare function setDeviceModuleHeaders(res: ServerResponse): void;
