export type CoreExportOrigin = {
    moduleId: string;
    mode: 'named' | 'module';
    importedName?: string;
    canonicalSubpath?: string;
};
export type ParsedCoreBridgeRequest = {
    sub: string;
    normalizedSub: string | null;
    key: string;
    /**
     * Set when the incoming path's sub-spec is not in canonical form
     * (e.g. trailing `.js`, `/index`, platform suffix). The middleware
     * should emit a 301 redirect to this path so iOS only ever caches
     * the canonical URL.
     *
     * `normalizeCoreSub` strips `.js`/`.mjs`/`.cjs`/`.ts` extensions,
     * trailing `/index`, and platform suffixes (`.ios`, `.android`,
     * `.visionos`) because Vite's path resolver legitimately emits those
     * shapes when it follows a package's `exports` map to a
     * platform-specific file (`ui/text-base/index.ios.js`) for the
     * extensionless import (`@nativescript/core/ui/text-base`). The 301
     * is therefore a real canonicalisation step, not legacy back-compat:
     * the rewriter's URL has to round-trip through file-system resolution
     * occasionally, and the device must end up on the single canonical
     * URL so iOS's HTTP-ESM cache key is shared with every other
     * emitter (vendor `require`, import map, AST normaliser, etc.).
     */
    canonicalPath?: string;
};
/**
 * Full JS identifier alphabet — Unicode-aware, NOT ASCII `\w`. Angular's
 * runtime API surface is `ɵɵdefineInjectable`-style (U+0275 is ID_Start);
 * an ASCII filter silently drops every such export from generated shims.
 */
export declare const JS_IDENTIFIER_RE: RegExp;
export declare function extractDirectExportedNames(code: string): string[];
export declare function parseExportSpecList(specList: string): Array<{
    importedName: string;
    exportedName: string;
}>;
export declare function resolveRuntimeCoreModulePath(normalizedSubpath: string, resolveModuleId: (moduleId: string) => Promise<string | null> | string | null): Promise<string | null>;
export declare function collectStaticExportNamesFromFile(modulePath: string, seen?: Set<string>): string[];
export declare function collectStaticExportOriginsFromFile(modulePath: string, rootEntryPath?: string, seen?: Set<string>): Record<string, CoreExportOrigin[]>;
export declare function normalizeCoreExportOriginsForRuntime(exportOrigins: Record<string, CoreExportOrigin[]>, resolveModuleId: (moduleId: string) => Promise<string | null> | string | null, rootModulePath: string): Promise<Record<string, CoreExportOrigin[]>>;
export declare function hasModuleDefaultExport(moduleCode: string): boolean;
/**
 * Parse an incoming `/ns/core` bridge request.
 *
 * Accepted shapes:
 *   - `/ns/core`               → package main
 *   - `/ns/core/<sub>`         → subpath form (`<sub>` may carry a
 *                                `.js`/`/index`/platform-suffix tail
 *                                that we strip via `normalizeCoreSub`
 *                                and report through `canonicalPath` so
 *                                the middleware can 301)
 *
 * Anything else returns `null` so the middleware falls through to
 * `next()` and a downstream 404 surfaces the offending emitter.
 *
 * URL contract:
 *   - No version segment. `/ns/core/<digits>` was an experimental
 *     cache-busting shape that split iOS's HTTP-ESM module cache from
 *     the unversioned URL emitted by the runtime import map. Removed.
 *   - No `?p=<sub>` query form. The canonical path form
 *     `/ns/core/<sub>` is the only spelling every emitter produces.
 */
export declare function parseCoreBridgeRequest(pathname: string, _searchParams: URLSearchParams, _currentGraphVersion: number): ParsedCoreBridgeRequest | null;
