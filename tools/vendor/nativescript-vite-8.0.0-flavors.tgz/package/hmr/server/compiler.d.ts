export declare const NS_NATIVE_TAGS: Set<string>;
export declare function isNativeTag(tag: string): boolean;
