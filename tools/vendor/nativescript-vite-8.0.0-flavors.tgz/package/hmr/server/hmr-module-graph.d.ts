import type { WebSocket, WebSocketServer } from 'ws';
import type { FrameworkServerStrategy } from './framework-strategy.js';
export interface GraphModule {
    id: string;
    deps: string[];
    hash: string;
}
export interface UpsertOptions {
    emitDeltaOnInsert?: boolean;
    broadcastDelta?: boolean;
    bumpVersion?: boolean;
}
export interface HmrModuleGraphDeps {
    verbose: boolean;
    strategy: FrameworkServerStrategy;
    getWss: () => WebSocketServer | null;
    getPluginRoot: () => string | undefined;
}
export declare class HmrModuleGraph {
    private readonly deps;
    readonly modules: Map<string, GraphModule>;
    private readonly txnBatches;
    private _version;
    constructor(deps: HmrModuleGraphDeps);
    get version(): number;
    get size(): number;
    get(id: string): GraphModule | undefined;
    getTxnBatch(version: number): string[];
    computeHash(content: string): string;
    normalizeGraphId(raw: string): string;
    computeTxnOrderForChanged(changedIds: string[]): string[];
    private fullGraphPayload;
    emitFullGraph(ws: WebSocket): void;
    emitDelta(changed: GraphModule[], removed: string[]): void;
    upsert(rawId: string, code: string, deps: string[], options?: UpsertOptions): GraphModule | undefined;
    remove(id: string): void;
}
