/**
 * Absolute root of @nativescript/core when it is consumed from monorepo
 * source (`<workspace>/packages/core` in the NativeScript repo) rather than
 * node_modules. Returns null for standalone apps.
 */
export declare function getWorkspaceCoreSourceRoot(): string | null;
/**
 * True when a served module path points into @nativescript/core consumed from
 * monorepo source. These modules are library code: the app-source HMR passes
 * (AST normalization, /ns/rt underscore-helper alias injection) must NOT run
 * on them — they exist for compiled app/SFC output, and on core sources they
 * misread internals (e.g. `ClassInfo._getBase`) as Vue template helpers and
 * inject destructures that shadow real bindings or TDZ-crash on the circular
 * /ns/rt dependency. In standalone apps core lives under node_modules and is
 * already excluded by the node_modules check.
 */
export declare function isWorkspaceCoreModulePath(p: string | undefined | null): boolean;
/**
 * True when a served module path points into the @nativescript/vite package
 * routed via its monorepo build output (`dist/packages/vite/...`). Apps that
 * consume the package via `file:../../dist/packages/vite` get a node_modules
 * SYMLINK, and require.resolve follows it to the real dist path — so the
 * served URL carries no `node_modules/` segment and escapes the node_modules
 * library check. Like core source, this is library code: the app-source HMR
 * passes (AST normalization, /ns/rt alias injection) must not run on it —
 * e.g. the HMR client bundle already carries its own `__ns_rt_ns_re` import,
 * and a second injected one is a duplicate-declaration SyntaxError on device.
 */
export declare function isWorkspaceVitePackageModulePath(p: string | undefined | null): boolean;
export type ServedModuleKind = 'app' | 'library';
/**
 * Single classification point for the /ns/m served-module pipeline. The
 * app-source passes inside processCodeForDevice (AST normalization, /ns/rt
 * underscore-helper alias injection) must run ONLY on 'app' modules; 'library'
 * code is served as-is plus import rewriting. Three things count as library:
 *   - anything under node_modules
 *   - @nativescript/core consumed from monorepo source (packages/core)
 *   - the @nativescript/vite package served from its dist build output
 *     (file:../../dist/packages/vite symlinks resolve to the real dist path,
 *     so no node_modules segment appears in the URL)
 * Add the next workspace-library case HERE, not at a call site.
 */
export declare function classifyServedModule(p: string | undefined | null): ServedModuleKind;
export declare const MODULE_IMPORT_ANALYSIS_PLUGINS: any;
export type TopLevelImportRecord = {
    start: number;
    end: number;
    text: string;
    source: string;
    hasOnlyNamedSpecifiers: boolean;
    namedBindings: Array<{
        importedName: string;
        text: string;
    }>;
};
export declare function collectTopLevelImportRecords(code: string): TopLevelImportRecord[];
export declare function hoistTopLevelStaticImports(code: string): string;
export declare function buildBootProgressSnippet(bootModuleLabel: string): string;
/**
 * A worker entry served under HMR evaluates in a fresh isolate where nothing
 * has installed the runtime globals — `setTimeout`, `console` formatting,
 * `fetch` — that the main realm's entry installs once from
 * `@nativescript/core/globals`. The production worker build bundles that
 * module in; the dev serve adds the import when the script does not carry it
 * itself, so a worker behaves the same way on both paths.
 */
export declare function ensureWorkerEntryGlobalsImport(code: string): string;
export declare function stripCoreGlobalsImports(code: string): string;
export declare function ensureVariableDynamicImportHelper(code: string): string;
export declare function ensureGuardPlainDynamicImports(code: string): string;
export declare function ensureDynamicHmrImportHelper(code: string): string;
export declare function expandStarExports(code: string, server: {
    transformRequest(path: string): Promise<{
        code?: string;
    } | null | undefined>;
}, projectRoot: string, verbose?: boolean, sharedTransformer?: (url: string) => Promise<{
    code?: string;
} | null | undefined>, importerId?: string): Promise<string>;
export declare function repairImportEqualsAssignments(code: string): string;
export declare function canonicalizeRtImports(code: string, origin: string): string;
export declare function stripViteDynamicImportVirtual(code: string): string;
export declare function extractExportMetadata(code: string): {
    hasDefault: boolean;
    named: string[];
};
/**
 * Defensive export normalization for route-config modules: if a served module
 * defines `routes` and only exports it named, append a default-export alias so
 * both `import { routes }` and `import routes` resolve. Backing implementation
 * for `FrameworkServerStrategy.normalizeServedExports` (Vue/Solid/TS).
 */
export declare function ensureRoutesDefaultExport(code: string): string;
export declare function assertNoOptimizedArtifacts(code: string, contextLabel: string): void;
export declare function ensureDestructureCoreImports(code: string): string;
export declare function ensureDestructureRtImports(code: string): string;
export declare function dedupeRtNamedImportsAgainstDestructures(code: string): string;
export declare function deduplicateLinkerImports(code: string): string;
export declare function wrapCommonJsModuleForDevice(code: string, absolutePath?: string | null): string;
