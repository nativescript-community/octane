import type { ViteDevServer } from 'vite';
export declare function getServerOrigin(server: ViteDevServer): string;
