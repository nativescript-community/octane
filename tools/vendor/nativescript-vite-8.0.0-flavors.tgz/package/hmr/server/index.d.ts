import type { NsDevPlatform } from '../shared/runtime/browser-runtime-contract.js';
export declare function getHMRPlugins(opts: {
    platform: NsDevPlatform;
    flavor: string;
    verbose: boolean;
}): import("vite").Plugin<any>[];
