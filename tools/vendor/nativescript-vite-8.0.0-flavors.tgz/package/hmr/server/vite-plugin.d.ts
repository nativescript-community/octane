import type { Plugin } from 'vite';
import { type NsDevPlatform, type NsDevSessionDescriptor } from '../shared/runtime/browser-runtime-contract.js';
export declare function computeClientImportSpecifier(options: {
    projectRoot: string;
    clientFsPath: string;
}): string;
export declare function resolveProjectMainEntryPath(projectRoot: string): string;
export declare function createNsDevSessionDescriptor(options: {
    projectRoot: string;
    requestHost: string;
    platform: NsDevPlatform;
    sessionId: string;
    secure?: boolean;
    mainEntryPathname?: string;
}): NsDevSessionDescriptor;
export declare function createNsDevClientBootstrapCode(options: {
    wsUrl: string;
    origin: string;
    clientImport: string;
    hotContextImport?: string;
    verbose?: boolean;
}): string;
export declare function nsHmrClientVitePlugin(opts: {
    platform: NsDevPlatform;
    verbose?: boolean;
}): Plugin;
