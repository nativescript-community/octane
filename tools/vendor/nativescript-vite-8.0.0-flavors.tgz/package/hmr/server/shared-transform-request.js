export function createSharedTransformRequestRunner(transformRequest, onTimeout, options = {}) {
    const inFlight = new Map();
    const recentResults = new Map();
    const cacheGenerations = new Map();
    const queue = [];
    const maxConcurrent = Math.max(1, Math.floor(options.maxConcurrent ?? 1));
    const resultCacheTtlMs = Math.max(0, Math.floor(options.resultCacheTtlMs ?? 0));
    const getResultCacheKey = options.getResultCacheKey ?? ((url) => url);
    let activeCount = 0;
    const getCacheGeneration = (cacheKey) => cacheGenerations.get(cacheKey) ?? 0;
    const invalidateCacheKey = (cacheKey) => {
        cacheGenerations.set(cacheKey, getCacheGeneration(cacheKey) + 1);
        recentResults.delete(cacheKey);
    };
    const pruneRecentResults = () => {
        if (!recentResults.size) {
            return;
        }
        const now = Date.now();
        for (const [key, entry] of recentResults) {
            if (entry.expiresAt <= now) {
                recentResults.delete(key);
            }
        }
    };
    const rememberRecentResult = (url, result, generation) => {
        if (!result || resultCacheTtlMs <= 0) {
            return;
        }
        const cacheKey = getResultCacheKey(url);
        if (getCacheGeneration(cacheKey) !== generation) {
            return;
        }
        recentResults.delete(cacheKey);
        recentResults.set(cacheKey, {
            expiresAt: Date.now() + resultCacheTtlMs,
            result,
        });
        if (recentResults.size > 512) {
            const oldestKey = recentResults.keys().next().value;
            if (oldestKey) {
                recentResults.delete(oldestKey);
            }
        }
    };
    const runNext = () => {
        while (activeCount < maxConcurrent) {
            const next = queue.shift();
            if (!next) {
                return;
            }
            activeCount += 1;
            next();
        }
    };
    const schedule = (task) => {
        let resolveStarted = null;
        const started = new Promise((resolve) => {
            resolveStarted = resolve;
        });
        const execution = new Promise((resolve, reject) => {
            queue.push(() => {
                let started;
                resolveStarted?.();
                try {
                    started = Promise.resolve(task());
                }
                catch (error) {
                    started = Promise.reject(error);
                }
                started.then(resolve, reject).finally(() => {
                    activeCount = Math.max(0, activeCount - 1);
                    runNext();
                });
            });
            runNext();
        });
        return { execution, started };
    };
    const withTimeout = (entry, url, timeoutMs) => {
        if (!(timeoutMs > 0)) {
            return entry.execution;
        }
        return entry.started.then(() => new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                try {
                    onTimeout?.(url, timeoutMs);
                }
                catch { }
            }, timeoutMs);
            entry.execution.then(resolve, reject).finally(() => {
                clearTimeout(timer);
            });
        }));
    };
    const runner = ((url, timeoutMs = 120000) => {
        pruneRecentResults();
        const cacheKey = getResultCacheKey(url);
        const generation = getCacheGeneration(cacheKey);
        const recent = recentResults.get(cacheKey);
        if (recent && recent.expiresAt > Date.now()) {
            return Promise.resolve(recent.result);
        }
        // Key the in-flight map on the canonical `cacheKey`, not the raw URL,
        // so two concurrent calls for `/foo.ts?t=1` and `/foo.ts?t=2` share a
        // single transform rather than doing the same work twice. The cache
        // key already strips `?t=` and `?v=` cache-busters and sorts the
        // remaining query — see `canonicalizeTransformRequestCacheKey`. This
        // pairs with `rememberRecentResult`, which was always keyed by
        // cacheKey.
        const existingExecution = inFlight.get(cacheKey);
        if (existingExecution && existingExecution.generation === generation) {
            return withTimeout(existingExecution, url, timeoutMs);
        }
        const scheduled = schedule(async () => {
            const result = await Promise.resolve(transformRequest(url));
            rememberRecentResult(url, result, generation);
            return result;
        });
        const execution = scheduled.execution.finally(() => {
            if (inFlight.get(cacheKey)?.execution === execution) {
                inFlight.delete(cacheKey);
            }
        });
        const entry = { execution, started: scheduled.started, cacheKey, generation };
        inFlight.set(cacheKey, entry);
        return withTimeout(entry, url, timeoutMs);
    });
    runner.invalidate = (url) => {
        invalidateCacheKey(getResultCacheKey(url));
    };
    runner.invalidateMany = (urls) => {
        for (const url of urls || []) {
            runner.invalidate(url);
        }
    };
    runner.clear = () => {
        recentResults.clear();
        cacheGenerations.clear();
    };
    return runner;
}
//# sourceMappingURL=shared-transform-request.js.map