import type { ViteDevServer } from 'vite';
export interface RegisterTxnHandlerOptions {
    resolveTxnIds(version: number, fallbackChangedIds: string[]): string[];
}
export declare function buildTxnModuleCode(version: number, ids: string[]): string;
export declare function registerTxnHandler(server: ViteDevServer, options: RegisterTxnHandlerOptions): void;
