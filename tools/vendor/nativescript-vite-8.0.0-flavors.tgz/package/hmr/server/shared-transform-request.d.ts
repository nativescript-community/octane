import type { TransformResult } from 'vite';
export type SharedTransformRequestRunnerOptions = {
    maxConcurrent?: number;
    resultCacheTtlMs?: number;
    getResultCacheKey?: (url: string) => string;
};
export type SharedTransformRequestRunner = ((url: string, timeoutMs?: number) => Promise<TransformResult | null>) & {
    invalidate: (url: string) => void;
    invalidateMany: (urls: Iterable<string>) => void;
    clear: () => void;
};
export declare function createSharedTransformRequestRunner(transformRequest: (url: string) => Promise<TransformResult | null>, onTimeout?: (url: string, timeoutMs: number) => void, options?: SharedTransformRequestRunnerOptions): SharedTransformRequestRunner;
