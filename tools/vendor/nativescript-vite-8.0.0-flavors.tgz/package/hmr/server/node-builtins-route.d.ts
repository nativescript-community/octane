import type { ViteDevServer } from 'vite';
/**
 * Exact import-map entries mapping every `node:<name>` specifier to this
 * route. Exact (not trailing-slash prefix) entries for two reasons: the
 * import-map spec reserves trailing-slash keys for path prefixes, and the
 * native resolver only intercepts `node:`-prefixed specifiers — bare 'url'
 * must keep resolving to the npm package of that name.
 */
export declare function getNodeBuiltinImportMapEntries(origin: string): Record<string, string>;
/** The module body served for `node:<name>` during a dev session. */
export declare function buildNodeBuiltinShimModule(name: string): string;
export declare function registerNodeBuiltinsRoute(server: ViteDevServer): void;
