import * as path from 'path';
import { filterExistingNodeModulesTransformCandidates, getBlockedDeviceNodeModulesReason, resolveCandidateFilePath, tryReadRawExplicitJavaScriptModule } from './websocket-module-specifiers.js';
import { collapseLegacyNsMTags } from './websocket-ns-m-paths.js';
function normalizeAbsoluteFilesystemSpec(spec, serverRoot) {
    const toPosix = (value) => value.replace(/\\/g, '/');
    const rootPosix = toPosix(serverRoot);
    const specPosix = toPosix(spec);
    const isAbsoluteFilesystemPath = /^\//.test(specPosix) || /^[A-Za-z]:\//.test(spec);
    if (!isAbsoluteFilesystemPath) {
        return spec;
    }
    let relative = specPosix.startsWith(rootPosix) ? specPosix.slice(rootPosix.length) : path.posix.relative(rootPosix, specPosix);
    if (relative.startsWith('..')) {
        return spec;
    }
    if (!relative.startsWith('/')) {
        relative = `/${relative}`;
    }
    return relative;
}
export function createNsMRequestContext(requestUrl, serverRoot, appVirtualWithSlash, workspaceRoot) {
    try {
        const urlObj = new URL(requestUrl || '', 'http://localhost');
        if (!urlObj.pathname.startsWith('/ns/m')) {
            return { kind: 'next' };
        }
        let spec = urlObj.searchParams.get('path') || '';
        let forcedVer = urlObj.searchParams.get('v');
        let bootTaggedRequest = false;
        if (!spec) {
            const base = '/ns/m';
            const rest = urlObj.pathname.slice(base.length);
            if (rest && rest !== '/') {
                spec = rest;
            }
        }
        if (spec === '/__invalid_at__.mjs' || spec === '__invalid_at__.mjs') {
            return {
                kind: 'response',
                statusCode: 200,
                code: "// invalid '@' import stub\nexport {}\n",
            };
        }
        if (!spec) {
            return {
                kind: 'response',
                statusCode: 200,
                code: 'export {}\n',
            };
        }
        spec = spec.replace(/[?#].*$/, '');
        const decorated = collapseLegacyNsMTags(spec, 'inbound-request-spec');
        spec = decorated.cleanedSpec;
        bootTaggedRequest = decorated.bootTaggedRequest;
        forcedVer || (forcedVer = decorated.forcedVer);
        spec = normalizeAbsoluteFilesystemSpec(spec, serverRoot);
        if (spec.startsWith('@/')) {
            spec = appVirtualWithSlash + spec.slice(2);
        }
        if (spec.startsWith('./')) {
            spec = spec.slice(1);
        }
        const blockedNodeModulesReason = getBlockedDeviceNodeModulesReason(spec);
        if (blockedNodeModulesReason) {
            return {
                kind: 'response',
                statusCode: 404,
                code: `// [ns:m] blocked device import\nthrow new Error(${JSON.stringify(`[ns/m] ${blockedNodeModulesReason}`)});\nexport {};\n`,
            };
        }
        if (!spec.startsWith('/')) {
            spec = `/${spec}`;
        }
        const hasExt = /\.(ts|tsx|js|jsx|mjs|mts|cts|vue)$/i.test(spec);
        const baseNoExt = hasExt ? spec.replace(/\.(ts|tsx|js|jsx|mjs|mts|cts)$/i, '') : spec;
        const candidates = [...(hasExt ? [spec] : []), `${baseNoExt}.ts`, `${baseNoExt}.js`, `${baseNoExt}.tsx`, `${baseNoExt}.jsx`, `${baseNoExt}.mjs`, `${baseNoExt}.mts`, `${baseNoExt}.cts`, `${baseNoExt}.vue`, `${baseNoExt}/index.ts`, `${baseNoExt}/index.js`, `${baseNoExt}/index.tsx`, `${baseNoExt}/index.jsx`, `${baseNoExt}/index.mjs`];
        const transformCandidates = filterExistingNodeModulesTransformCandidates(spec, candidates, serverRoot, workspaceRoot);
        return {
            kind: 'context',
            value: {
                requestUrl,
                spec,
                forcedVer,
                bootTaggedRequest,
                serverRoot,
                workspaceRoot: workspaceRoot ?? null,
                candidates,
                transformCandidates,
            },
        };
    }
    catch {
        return { kind: 'next' };
    }
}
async function tryTransformRequest(transformRequest, url, timeoutMs) {
    try {
        return await transformRequest(url, timeoutMs);
    }
    catch {
        return null;
    }
}
function getLoadedCode(loadResult) {
    if (!loadResult) {
        return null;
    }
    if (typeof loadResult === 'string') {
        return loadResult;
    }
    return typeof loadResult.code === 'string' ? loadResult.code : null;
}
export async function resolveNsMTransformedModule(options) {
    const { context, transformRequest, resolveId, loadVirtualId, timeoutMs = 120000 } = options;
    const { spec, serverRoot, workspaceRoot, transformCandidates } = context;
    let transformed = null;
    let resolvedCandidate = null;
    if (spec.startsWith('/@id/')) {
        transformed = await tryTransformRequest(transformRequest, spec, timeoutMs);
        if (transformed?.code) {
            return { transformed, resolvedCandidate };
        }
        try {
            const rawId = spec.slice('/@id/'.length).replace(/__x00__/g, '\0');
            const loadedCode = getLoadedCode(await loadVirtualId(rawId));
            if (loadedCode) {
                return {
                    transformed: { code: loadedCode },
                    resolvedCandidate: rawId,
                };
            }
        }
        catch { }
    }
    const rawExplicitModule = tryReadRawExplicitJavaScriptModule(spec, serverRoot);
    if (rawExplicitModule) {
        return {
            transformed: { code: rawExplicitModule.code },
            resolvedCandidate: rawExplicitModule.resolvedId,
        };
    }
    for (const candidate of transformCandidates) {
        transformed = await tryTransformRequest(transformRequest, candidate, timeoutMs);
        if (transformed?.code) {
            resolvedCandidate = candidate;
            return { transformed, resolvedCandidate };
        }
    }
    const resolvedId = await resolveId(spec);
    if (resolvedId) {
        transformed = await tryTransformRequest(transformRequest, resolvedId, timeoutMs);
        if (transformed?.code) {
            return { transformed, resolvedCandidate: resolvedId };
        }
    }
    if (spec.includes('/node_modules/')) {
        const nodeModulesIndex = spec.lastIndexOf('/node_modules/');
        const bareSpecifier = spec.slice(nodeModulesIndex + '/node_modules/'.length);
        if (bareSpecifier && !bareSpecifier.startsWith('.')) {
            const resolvedBareId = await resolveId(bareSpecifier);
            if (resolvedBareId) {
                transformed = await tryTransformRequest(transformRequest, resolvedBareId, timeoutMs);
                if (transformed?.code) {
                    return { transformed, resolvedCandidate: resolvedBareId };
                }
            }
        }
    }
    const buildFsCandidate = (root) => {
        const rootPosix = root.replace(/\\/g, '/').replace(/\/$/, '');
        const absolutePosixPath = `${rootPosix}${spec.startsWith('/') ? '' : '/'}${spec}`;
        return `/@fs${absolutePosixPath}`;
    };
    const fsRootsToTry = [serverRoot, ...(workspaceRoot && path.resolve(workspaceRoot) !== path.resolve(serverRoot) ? [workspaceRoot] : [])];
    for (const root of fsRootsToTry) {
        const fsId = buildFsCandidate(root);
        if (resolveCandidateFilePath(fsId, serverRoot, workspaceRoot)) {
            transformed = await tryTransformRequest(transformRequest, fsId, timeoutMs);
            if (transformed?.code) {
                return { transformed, resolvedCandidate: fsId };
            }
        }
    }
    for (const candidate of transformCandidates) {
        const importHintCandidate = `${candidate}${candidate.includes('?') ? '&' : '?'}import`;
        transformed = await tryTransformRequest(transformRequest, importHintCandidate, timeoutMs);
        if (transformed?.code) {
            resolvedCandidate = importHintCandidate;
            return { transformed, resolvedCandidate };
        }
    }
    return {
        transformed: null,
        resolvedCandidate,
    };
}
//# sourceMappingURL=websocket-ns-m-request.js.map