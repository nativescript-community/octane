/**
 * Rewrites stray string-literal side-effect lines that reference @nativescript/core
 * into proper ESM import statements targeting the unified /ns/core bridge.
 *
 * Why: certain upstream transforms can accidentally turn a side-effect import like
 *   import '@nativescript/core/index.js'
 * into a naked string literal line:
 *   "@nativescript/core/index.js";
 * This trips the sanitizer's local-core-path detector and breaks HTTP ESM loading.
 *
 * This helper safely maps those literals to the canonical path form:
 *   import "/ns/core/<sub>";   // subpath form, no version, no ?p=
 * or, without subpath:
 *   import "/ns/core";
 */
export declare function normalizeStrayCoreStringLiterals(code: string): string;
/**
 * Merge a dangling "import { ... } from" that was split across lines with the
 * following side-effect import of the core bridge.
 *
 * Example:
 *   import { A, B } from\nimport "/ns/core/index";
 * becomes
 *   import { A, B } from "/ns/core/index";
 */
export declare function fixDanglingCoreFrom(code: string): string;
/**
 * Run the full "rescue any stray @nativescript/core references" pass over the
 * code in one call. This is the canonical entry point for NS-M served modules
 * (and any other consumer that wants the safety net). The three sub-passes
 * cover progressively rarer pipeline accidents:
 *
 *   1. `normalizeStrayCoreStringLiterals` — turns naked `"@nativescript/core/foo";`
 *      string literals (produced by some upstream transforms that bare-stringify
 *      side-effect imports) back into proper `import "/ns/core/foo";`.
 *   2. `fixDanglingCoreFrom` — merges multi-line accidents where a `from`
 *      clause got separated from its specifier across newlines.
 *   3. `normalizeAnyCoreSpecToBridge` — final regex sweep that catches any
 *      remaining `from "...@nativescript/core[/sub]..."` references that escaped
 *      both the AST normalizer and the import rewriter.
 *
 * Centralising the passes here ensures every NS-M emitter applies the same
 * safety net in the same order; drift between call sites re-introduces the
 * realm-split bug.
 *
 * Returns the (possibly) rewritten code; never throws.
 */
export declare function sanitizeStrayCoreReferences(code: string): string;
/**
 * Fallback: normalize ANY import spec that references '@nativescript/core' (including
 * absolute/relative or resolved forms like '/node_modules/@nativescript/core/index.js?v=...')
 * into the unified '/ns/core' bridge before fast-fail assertions.
 */
export declare function normalizeAnyCoreSpecToBridge(code: string): string;
/**
 * Description of the URL the bridge is currently serving, used to resolve
 * relative import specifiers (`./x`, `../x`) into absolute `/ns/core/<sub>`
 * URLs.
 *
 * Why this exists: Vite's `vite:import-analysis` pass usually rewrites every
 * relative specifier to an absolute (`/@fs/...` or `/node_modules/...`) ID
 * before code reaches us, but for files under `node_modules` some transform
 * paths leave relatives untouched. When the device fetches such a module at
 * `http://host/ns/core/utils/layout-helper` (no trailing slash, no `/index`)
 * V8/iOS apply RFC 3986 URL resolution and treat `layout-helper` as the
 * *file*, so `./layout-helper-common` becomes
 * `http://host/ns/core/utils/layout-helper-common` — a sibling that does not
 * exist (the real file lives at `…/layout-helper/layout-helper-common`).
 *
 * Passing a `RelativeBase` lets `rewriteSpec` resolve these specifiers
 * server-side and emit canonical absolute `/ns/core/<resolved>` URLs, so the
 * device never has to guess. When omitted, `rewriteSpec` falls back to the
 * pre-existing behaviour of leaving relatives alone.
 */
export type RelativeBase = {
    /**
     * Sub-path of the served module, without the leading `/ns/core/`. May be
     * the empty string for the package main (`/ns/core` itself).
     */
    sub: string;
    /**
     * `true` when the served file is a directory-index (e.g.
     * `…/utils/layout-helper/index.android.ts`); in that case `sub` already
     * names the *directory*, and `./x` resolves to `<sub>/x`.
     *
     * `false` for plain file modules (e.g. `…/utils/native-helper.ts`); the
     * resolution base is the parent directory of `sub`, so `./x` resolves to
     * `<sub-parent>/x`.
     */
    isDirectoryIndex: boolean;
};
/**
 * Detect whether a resolved module path is a directory-index file. Matches
 * `index.<platform?>.<ext>` shapes used across @nativescript/core (e.g.
 * `index.js`, `index.android.ts`, `index.ios.mjs`).
 */
export declare function isDirectoryIndexFilename(modulePath: string): boolean;
/**
 * Resolve a relative specifier (`./x`, `../x`) into a canonical
 * @nativescript/core sub-path, given the base described by `relBase`.
 *
 * `…/index.<platform>.<ext>` files mean `sub` IS the directory (so `./x` →
 * `<sub>/x`); plain files mean the resolution base is `sub`'s parent.
 *
 * Returned sub-path is sanitised by `buildCoreUrlPath`'s convention: trailing
 * `.(m)?(j|t)s` extensions are stripped so callers can directly emit
 * `/ns/core/<resolved>` without producing a non-canonical URL that the
 * bridge would 301-redirect later.
 */
export declare function resolveRelativeCoreSub(spec: string, relBase: RelativeBase): string | null;
/**
 * Minimal specifier rewriter for deep subpath core modules.
 *
 * Takes Vite's correctly-transformed ESM output and ONLY rewrites the
 * specifier strings inside import/export clauses. Does NOT:
 *   - Inject global defines
 *   - Run AST normalization
 *   - Convert named imports to default + destructure
 *   - Mangle newlines or code structure
 *
 * This replaces the heavy 5-pass pipeline (processCodeForDevice →
 * rewriteImports → deduplicateLinkerImports → CJS wrapping → etc.)
 * for deep subpath core modules where Vite already produces correct ESM.
 *
 * When `relBase` is supplied, relative specifiers (`./x`, `../x`) are
 * resolved server-side into canonical `/ns/core/<resolved>` URLs so the
 * device never has to guess where a directory-index file's siblings live.
 * See `RelativeBase` and `rewriteSpec` for the full rationale.
 */
export declare function rewriteSpecifiersForDevice(code: string, origin: string, ver: number, relBase?: RelativeBase): string;
/**
 * Determine whether a `/ns/core` bridge URL points to a real subpath module.
 *
 * Any `/ns/core/<sub>` module now serves real ESM content with real named
 * exports via Vite's transform pipeline, except for package-main aliases like
 * `/ns/core/index`, which should be treated like the main `/ns/core`
 * bridge and destructured from its default export.
 * The main proxy bridge (`/ns/core`) still only exports a default Proxy and
 * requires named imports to be destructured from it.
 *
 * This check is used in all named-import-to-default destructuring passes to
 * skip rewriting for real subpath modules — they have named exports that work
 * natively without conversion.
 */
export declare function isDeepCoreSubpath(url: string): boolean;
/**
 * Synthesize a `default` export for an ESM module that only has named/star
 * exports. Utility function — not currently called from the core bridge
 * handler since `ensureDestructureCoreImports` now skips deep subpaths.
 *
 * Handles all three @nativescript/core patterns:
 *   1. Direct declarations: export class X, export function Y, export const Z
 *   2. Named re-exports:   export { A, B } from '/path'
 *   3. Star re-exports:    export * from '/path'
 *
 * Returns the code unchanged if it already has a default export or CJS exports.
 */
export declare function synthesizeDefaultExport(moduleCode: string): string;
