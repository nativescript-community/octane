export type NsMResponseMemo = {
    buildKey(spec: string, inputCode: string, context: string): string;
    get(key: string): string | undefined;
    set(key: string, body: string): void;
    size(): number;
    clear(): void;
};
export declare function createNsMResponseMemo(options?: {
    maxEntries?: number;
}): NsMResponseMemo;
