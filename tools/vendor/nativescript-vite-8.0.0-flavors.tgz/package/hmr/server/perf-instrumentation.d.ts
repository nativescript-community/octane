export type ServerStartupBannerInput = {
    version: string;
    transformConcurrency: number;
    transformCacheMs: number;
    lazyInitialGraph: boolean;
    graphVersion: number;
};
export declare function formatServerStartupBanner(input: ServerStartupBannerInput): string;
/**
 * Classify a URL path into a coarse route category. Any pathname that
 * doesn't match a known NativeScript dev route is reported as `other`;
 * callers are expected to filter their own irrelevant routes before
 * calling `record()`.
 */
export declare function classifyBootRoute(pathname: string): BootRouteCategory;
export type BootRouteCategory = 'ns/m' | 'ns/rt' | 'ns/core' | 'ns/vendor' | 'ns/import-map' | 'ns/boot' | 'ns/hmr' | 'ns/other' | 'other';
export type ColdBootRequestCounter = {
    record: (url: string) => RecordHandle;
    finalize: () => void;
    getState: () => ColdBootCounterState;
};
export type RecordHandle = {
    finish: () => void;
};
export type ColdBootCounterState = {
    active: boolean;
    count: number;
    inFlight: number;
    maxConcurrent: number;
    startedAt: number | null;
    firstRequestUrl: string | null;
    perRoute: Partial<Record<BootRouteCategory, number>>;
};
export type ColdBootCounterOptions = {
    /**
     * Emit a rolling summary every N requests (default 100). Lower the
     * threshold in tests to keep them snappy. Set to 0 to disable rolling
     * summaries; a final summary still fires from `finalize()`.
     */
    summaryEvery?: number;
    /**
     * Cold-boot window closes when no new requests arrive within this
     * idle window (default 5000ms). The HMR edit loop reuses the same
     * handler, but it never bursts as heavily as cold boot. Raise this
     * via `NS_VITE_HMR_BOOT_TRACE_IDLE_MS` when profiling a slow boot
     * so inter-wave pauses don't close the counter prematurely.
     */
    idleWindowMs?: number;
    /** Defaults to `Date.now`; tests inject a deterministic clock. */
    now?: () => number;
    /** Defaults to `setTimeout`; tests can inject a fake timer. */
    setTimer?: (handler: () => void, ms: number) => unknown;
    /** Defaults to `clearTimeout`; tests can inject a fake timer. */
    clearTimer?: (handle: unknown) => void;
    /** Logger called for every summary line (rolling + final). */
    log: (line: string) => void;
};
export declare function createColdBootRequestCounter(options: ColdBootCounterOptions): ColdBootRequestCounter;
export type PopulateInitialGraphSummary = {
    moduleCount: number;
    durationMs: number;
    graphVersion: number;
    bumpedVersion: boolean;
};
export declare function formatPopulateInitialGraphSummary(input: PopulateInitialGraphSummary): string;
export type HmrUpdateKind = 'ts' | 'html' | 'css' | 'vue' | 'tsx' | 'jsx' | 'js' | 'mjs' | 'xml' | 'unknown';
/**
 * Classify a file's HMR update kind by extension. Used by the server-side
 * update summary so a quick log line tells us which pipeline ran. Returns
 * `'unknown'` for anything that doesn't match a known dev-time extension —
 * the caller decides whether to log it or skip it entirely.
 */
export declare function classifyHmrUpdateKind(file: string): HmrUpdateKind;
export type HmrUpdateSummary = {
    /** Project-relative or absolute path of the file that triggered HMR. */
    file: string;
    /** File classification. */
    kind: HmrUpdateKind;
    /** Time spent waiting for `populateInitialGraph` to complete (ms). */
    awaitMs: number;
    /** Time spent in framework-specific work (graph updates, invalidation). */
    frameworkMs: number;
    /** Time spent broadcasting the WebSocket message. */
    broadcastMs: number;
    /** End-to-end handler time. */
    totalMs: number;
    /** Number of modules invalidated by the update. */
    invalidated: number;
    /** Number of HMR clients the message was sent to. */
    recipients: number;
    /**
     * Angular-only narrowing decision: whether transitive-importer
     * invalidation was narrowed because the changed file lacks Angular
     * semantic decorators (`@Component`/`@Directive`/`@Pipe`/`@Injectable`/
     * `@NgModule`). `true` means narrow (importers preserved, ESM live
     * bindings carry the change). `false` means broad (importers also
     * invalidated). `null`/`undefined` means the field is not applicable
     * to this update (e.g. CSS, non-Angular flavor) and the field is
     * omitted from the summary line entirely.
     */
    narrowed?: boolean | null;
};
/**
 * Single-line summary for the server side of an HMR update. Always-on so
 * a 6-second `.ts` save is immediately visible without flipping verbose.
 * Format:
 *   [hmr-ws][update] kind=ts file=/src/foo.ts await=12ms framework=180ms broadcast=2ms total=194ms invalidated=23 recipients=1
 *
 * For Angular `.ts` updates, `narrowed=yes|no` is appended so the
 * narrowing decision is immediately visible without flipping verbose:
 *   [hmr-ws][update] kind=ts file=/src/app/foo.constants.ts ... invalidated=1 recipients=1 narrowed=yes
 *   [hmr-ws][update] kind=ts file=/src/app/foo.component.ts ... invalidated=132 recipients=1 narrowed=no
 */
export declare function formatHmrUpdateSummary(input: HmrUpdateSummary): string;
