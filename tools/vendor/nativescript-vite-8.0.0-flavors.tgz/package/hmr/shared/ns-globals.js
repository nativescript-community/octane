/* eslint-disable no-var -- ambient global declarations must use `var`: only `var`
   in `declare global` registers the property on `typeof globalThis` (see header). */
/**
 * Ambient typings for the `__NS_*` / `__ns*` globals the HMR runtime stashes on
 * `globalThis`. One `declare global` here replaces the scattered
 * `(globalThis as any).__NS_X` casts across the device client + entry runtime:
 * consumers read/write `globalThis.__NS_X` directly and get a real type, and the
 * per-file `declare const __NS_X__` duplicates collapse to this single source of
 * truth.
 *
 * Conventions:
 *   - Every key is `var … | undefined` — `var` (not `const`/`let`) is what adds the
 *     property to `typeof globalThis`, so both bare references (Vite `define`
 *     substitutions like `__NS_ENV_VERBOSE__`) and `globalThis.__NS_X` access
 *     type-check; `| undefined` reflects that these are populated lazily at runtime.
 *   - Primitive flags/counters/urls get precise types. Keys holding framework
 *     instances, native objects, ASTs, module registries, or arbitrary diagnostic
 *     payloads are intentionally `any` — typing them precisely would couple this
 *     shared file to device internals and risk breaking write sites elsewhere in
 *     the package.
 *   - The runtime dev-host API is NOT a global at all — it is the
 *     `ns:module` builtin module, read through
 *     `hmr/shared/runtime/browser-runtime-contract.ts`.
 *
 * This module emits no runtime code (ambient declaration only) and is picked up
 * project-wide via the package tsconfig include (all .ts files).
 */
export {};
//# sourceMappingURL=ns-globals.js.map