/**
 * Dev overlay public API: boot / connection / update stage setters plus the
 * auto-hide timing policy. Rendering is delegated to two backends behind the
 * shared snapshot/state model (`dev-overlay-shared.ts`):
 *
 * - `dev-overlay-ios.ts` — dedicated UIWindow above `UIWindowLevelAlert`, so
 *   the overlay stacks above modals/sheets/system alerts (preferred on iOS)
 * - `dev-overlay-tree.ts` — boot placeholder + in-tree toast chip (Android,
 *   and the fallback when the iOS window can't be built)
 */
import { type HmrBootStage, type HmrConnectionStage, type HmrOverlayPosition, type HmrOverlaySnapshot, type HmrOverlayStageInfo, type HmrUpdateStage } from './dev-overlay-snapshots.js';
export { createBootOverlaySnapshot, createConnectionOverlaySnapshot, createUpdateOverlaySnapshot } from './dev-overlay-snapshots.js';
export type { HmrBootStage, HmrConnectionStage, HmrOverlayPosition, HmrOverlaySnapshot, HmrOverlayStageInfo, HmrUpdateStage } from './dev-overlay-snapshots.js';
export { getHmrDevOverlayPosition } from './dev-overlay-shared.js';
export { computeAndroidToastMargin } from './dev-overlay-tree.js';
export type { AndroidSafeAreaInsets, AndroidToastMargin } from './dev-overlay-tree.js';
export { computeIosOverlayLayout, computeIosOverlayWindowLevel } from './dev-overlay-ios.js';
export type { IosOverlayLayout, IosRect, IosSafeInsets } from './dev-overlay-ios.js';
type HmrOverlayApi = {
    ensureBootPage: (verbose?: boolean) => any | null;
    setBootStage: (stage: HmrBootStage, info?: HmrOverlayStageInfo) => HmrOverlaySnapshot;
    setConnectionStage: (stage: HmrConnectionStage, info?: HmrOverlayStageInfo) => HmrOverlaySnapshot;
    setUpdateStage: (stage: HmrUpdateStage, info?: HmrOverlayStageInfo) => HmrOverlaySnapshot;
    hide: (reason?: string) => void;
    getSnapshot: () => HmrOverlaySnapshot;
};
/**
 * Imperative setter for the live-overlay position. Re-applies the
 * current snapshot so the change is visible without waiting for the
 * next HMR cycle. Useful during dev to A/B between top/bottom/center
 * without restarting the app.
 */
export declare function setHmrDevOverlayPosition(position: HmrOverlayPosition): void;
export declare function ensureHmrDevOverlayRuntimeInstalled(verbose?: boolean): HmrOverlayApi;
export declare function createHmrBootOverlayPage(verbose?: boolean): any | null;
export declare function setHmrBootStage(stage: HmrBootStage, info?: HmrOverlayStageInfo): HmrOverlaySnapshot;
export declare function setHmrConnectionStage(stage: HmrConnectionStage, info?: HmrOverlayStageInfo): HmrOverlaySnapshot;
export declare function setHmrUpdateStage(stage: HmrUpdateStage, info?: HmrOverlayStageInfo): HmrOverlaySnapshot;
export declare function hideHmrDevOverlay(reason?: string): void;
