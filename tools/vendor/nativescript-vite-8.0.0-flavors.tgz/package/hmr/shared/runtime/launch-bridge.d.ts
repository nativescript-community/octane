/**
 * Wrap every reachable `Application.ios`. Multiple `Application` instances can
 * coexist on device (the /ns/core bridge realm the APP graph imports, the
 * vendor-registry/deps-bundle realm, whatever landed on globalThis) — which
 * one an app's registration goes through depends on its import path, so wrap
 * them all. `explicitApplication` should be the /ns/core realm's Application
 * (what app code actually gets); extra candidates are best-effort.
 */
export declare function installLaunchNotificationBridge(explicitApplication?: any, extraCandidates?: any[]): boolean;
