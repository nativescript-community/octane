/**
 * Internals shared by the dev-overlay backends (boot placeholder, in-tree
 * live overlay, iOS UIWindow overlay): the per-session runtime state held on
 * `globalThis`, core-class resolution that respects the realm rule, and
 * snapshot/text formatting. Not part of the public overlay API — import
 * `dev-overlay.ts` for that.
 */
import { DEFAULT_SNAPSHOT } from './dev-overlay-snapshots.js';
import { getGlobalScope } from './global-scope.js';
import { getVendorRequire } from './vendor-resolve.js';
const DEFAULT_OVERLAY_POSITION = 'top';
export function getOverlayGlobal() {
    return getGlobalScope();
}
/**
 * Resolve the configured live-overlay position.
 *
 * Reads `globalThis.__NS_HMR_OVERLAY_POSITION__` so a project can
 * override the default at boot time (e.g. inside `app.ts` before the
 * Vite session bootstraps). Falls back to 'top' which gives the
 * toast-style chip with a slide-in animation and safe-area padding.
 */
export function getHmrDevOverlayPosition() {
    const g = getOverlayGlobal();
    const stored = g.__NS_HMR_OVERLAY_POSITION__;
    if (stored === 'top' || stored === 'bottom' || stored === 'center') {
        return stored;
    }
    return DEFAULT_OVERLAY_POSITION;
}
export function getRuntimeState() {
    const g = getOverlayGlobal();
    if (!g.__NS_HMR_DEV_OVERLAY_STATE__) {
        g.__NS_HMR_DEV_OVERLAY_STATE__ = {
            snapshot: { ...DEFAULT_SNAPSHOT },
            bootRefs: null,
            liveRefs: null,
            iosRefs: null,
            iosBuildFailed: false,
            verbose: false,
            updateAutoHideTimer: null,
            updateCycleStartedAt: 0,
        };
    }
    const state = g.__NS_HMR_DEV_OVERLAY_STATE__;
    // Backfill newer fields for legacy state objects (e.g. after hot reload)
    // so we never observe an undefined iosRefs/iosBuildFailed at runtime.
    if (typeof state.iosRefs === 'undefined')
        state.iosRefs = null;
    if (typeof state.iosBuildFailed === 'undefined')
        state.iosBuildFailed = false;
    if (typeof state.updateAutoHideTimer === 'undefined')
        state.updateAutoHideTimer = null;
    if (typeof state.updateCycleStartedAt !== 'number')
        state.updateCycleStartedAt = 0;
    return state;
}
export function resolveCoreExport(name) {
    const g = getOverlayGlobal();
    try {
        const reg = g.__nsVendorRegistry;
        if (reg && typeof reg.get === 'function') {
            const mod = reg.get('@nativescript/core');
            const ns = (mod && (mod.default ?? mod)) || mod;
            if (ns && ns[name]) {
                return ns[name];
            }
        }
    }
    catch { }
    try {
        if (g && g[name]) {
            return g[name];
        }
    }
    catch { }
    try {
        const req = getVendorRequire();
        if (req) {
            const mod = req('@nativescript/core');
            const ns = (mod && (mod.default ?? mod)) || mod;
            if (ns && ns[name]) {
                return ns[name];
            }
        }
    }
    catch { }
    try {
        const nativeReq = g.__nativeRequire;
        if (typeof nativeReq === 'function') {
            const mod = nativeReq('@nativescript/core', '/');
            const ns = (mod && (mod.default ?? mod)) || mod;
            if (ns && ns[name]) {
                return ns[name];
            }
        }
    }
    catch { }
    return undefined;
}
export function asColor(value) {
    try {
        const Color = resolveCoreExport('Color');
        if (Color) {
            return new Color(value);
        }
    }
    catch { }
    return value;
}
export function formatStatusText(snapshot) {
    const progressText = typeof snapshot.progress === 'number' ? ` (${Math.round(Number(snapshot.progress))}%)` : '';
    const primary = `${snapshot.phase || ''}${progressText}`.trim();
    return [primary, snapshot.detail].filter(Boolean).join('\n');
}
//# sourceMappingURL=dev-overlay-shared.js.map