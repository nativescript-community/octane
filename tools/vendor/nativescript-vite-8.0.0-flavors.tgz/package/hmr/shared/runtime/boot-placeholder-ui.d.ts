import type { HmrOverlaySnapshot } from './dev-overlay.js';
/**
 * Calibrated palette for the boot placeholder card. The card is
 * intentionally light so the small accent (brand badge + progress
 * fill) reads as the only "live" element on the screen.
 *
 * Tones map to the snapshot tone enum from `dev-overlay.ts`:
 *  - `info` (default) — calm slate + NS blue
 *  - `error` — dusty rose-on-white surface
 */
export type BootPlaceholderTone = 'info' | 'error';
export interface BootPlaceholderPalette {
    pageBackground: string;
    cardBackground: string;
    cardShadow: string;
    titleText: string;
    phaseText: string;
    detailText: string;
    progressTrack: string;
    progressFill: string;
    activityIndicator: string;
}
/**
 * Resolve the palette for a given tone. Unknown tones fall back to
 * the calm `info` palette
 */
export declare function getBootPlaceholderPalette(tone?: string | null): BootPlaceholderPalette;
/**
 * Animation contract for the boot placeholder.
 *
 * `entranceDurationMs` covers the one-shot fade + scale that fires
 * when the placeholder card first attaches to the visual tree.
 * `entranceFromScale` is the starting scale before easeOut to 1.
 *
 * `progressDurationMs` is the per-update fade for the progress fill's
 * `scaleX`. Pegged to 220 ms (just under the heartbeat's 250 ms tick)
 * so consecutive ticks chain into continuous motion rather than
 * waiting on the previous animation to settle.
 *
 * `brandPulseDurationMs` is one half-period of the brand badge's
 * opacity pulse. A full cycle is `brandPulseDurationMs * 2`. Keeping
 * it long (~1.2 s) makes the pulse feel ambient rather than nervous.
 */
export declare const BOOT_PLACEHOLDER_MOTION: {
    readonly entranceDurationMs: 380;
    readonly entranceFromScale: 0.94;
    readonly progressDurationMs: 220;
    readonly brandPulseDurationMs: 1200;
    readonly brandPulseMinOpacity: 0.55;
};
/**
 * Convert a 0–100 progress percentage into an `scaleX` factor that
 * the fill view can animate against. Clamps to [`minScale`, 1] so the
 * fill never collapses to an invisible hairline
 *
 * The default `minScale` of 0.01 keeps the bar visible during the
 * earliest moments of boot when progress is 0
 */
export declare function computeBootProgressFillScale(progress: number | null | undefined, minScale?: number): number;
/**
 * The "phase + percent" line we show as the primary status text
 * inside the card
 */
export declare function formatBootPrimaryLine(snapshot: Pick<HmrOverlaySnapshot, 'phase' | 'progress'> | null | undefined): string;
/**
 * The secondary detail line (e.g. "Loading the module graph…" or
 * "Evaluated 42 modules").
 */
export declare function formatBootDetailLine(snapshot: Pick<HmrOverlaySnapshot, 'detail'> | null | undefined): string;
