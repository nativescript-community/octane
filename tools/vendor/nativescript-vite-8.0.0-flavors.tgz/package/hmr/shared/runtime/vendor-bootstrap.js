import { getGlobalScope } from './global-scope.js';
// Vendor bootstrap runtime installer. This runs on device (virtual entry) and must avoid
// define-transform pitfalls (no dot-notation writes on globalThis; use defineProperty or bracket form).
export function installVendorBootstrap(vendorManifest, __nsVendorModuleMap, verbose) {
    const g = getGlobalScope();
    const setGlobal = (k, v) => {
        try {
            Object.defineProperty(g, k, { value: v, configurable: true, writable: true });
        }
        catch {
            try {
                g[k] = v;
            }
            catch { }
        }
    };
    const record = (key, details) => {
        try {
            const fn = g['__NS_RECORD_MODULE_PROVENANCE__'];
            if (typeof fn === 'function') {
                fn(key, details);
            }
        }
        catch { }
    };
    const manifest = vendorManifest ?? {};
    let registry = g['__nsVendorRegistry'];
    if (!registry)
        setGlobal('__nsVendorRegistry', (registry = new Map()));
    const aliases = new Map(Object.entries(manifest.aliases ?? {}));
    const modules = __nsVendorModuleMap ?? {};
    const previousHash = g['__nsVendorHash'];
    if (previousHash === manifest.hash && registry.size > 0) {
        return;
    }
    registry.clear();
    try {
        setGlobal('__nsVendorHash', manifest.hash);
    }
    catch { }
    try {
        setGlobal('__nsVendorManifest', manifest);
    }
    catch { }
    for (const id of Object.keys(modules)) {
        if (!aliases.has(id))
            aliases.set(id, id);
    }
    for (const [id, mod] of Object.entries(modules)) {
        registry.set(id, mod);
        record(id, {
            kind: 'vendor-bundle',
            specifier: id,
            via: 'vendor-bootstrap',
        });
    }
    const baseRequire = typeof g.require === 'function' ? g.require.bind(g) : undefined;
    if (!g['__nsBaseRequire'] && baseRequire) {
        try {
            setGlobal('__nsBaseRequire', baseRequire);
        }
        catch { }
    }
    const resolve = (id) => {
        const normalized = String(id ?? '').replace(/[?#].*$/, '');
        if (registry.has(normalized))
            return normalized;
        if (modules[normalized])
            return normalized;
        // direct alias
        const direct = aliases.get(normalized);
        if (direct)
            return direct;
        // normalize slashes for alias lookups
        const slashNorm = normalized.replace(/\\/g, '/');
        const aliasNormalized = aliases.get(slashNorm) || aliases.get(slashNorm);
        if (aliasNormalized)
            return aliasNormalized;
        return normalized;
    };
    try {
        setGlobal('__nsResolveVendor', resolve);
    }
    catch { }
    const ensureModule = (id) => {
        const canonical = resolve(id);
        if (registry.has(canonical)) {
            record(canonical, {
                kind: 'vendor-registry',
                specifier: id,
                via: 'vendor-bootstrap',
            });
            return registry.get(canonical);
        }
        if (modules[canonical]) {
            const mod = modules[canonical];
            registry.set(canonical, mod);
            record(canonical, {
                kind: 'vendor-bundle',
                specifier: id,
                via: 'vendor-bootstrap',
            });
            return mod;
        }
        const late = typeof g['__nsBaseRequire'] === 'function' ? g['__nsBaseRequire'] : typeof g.require === 'function' ? g.require.bind(g) : undefined;
        if (late) {
            const mod = late(id);
            record(canonical, {
                kind: 'base-require',
                specifier: id,
                via: 'vendor-bootstrap',
            });
            return mod;
        }
        throw new Error('[ns-vendor] Module not available: ' + id + ' (canonical: ' + canonical + ')');
    };
    const existingNsRequire = g['__nsRequire'];
    try {
        setGlobal('__nsRequire', typeof existingNsRequire === 'function'
            ? (id) => {
                try {
                    return ensureModule(id);
                }
                catch (error) {
                    try {
                        const mod = existingNsRequire(id);
                        record(resolve(id), {
                            kind: 'legacy-ns-require',
                            specifier: id,
                            via: 'vendor-bootstrap',
                        });
                        return mod;
                    }
                    catch {
                        const late = typeof g['__nsBaseRequire'] === 'function' ? g['__nsBaseRequire'] : typeof g.require === 'function' ? g.require.bind(g) : undefined;
                        if (late) {
                            const mod = late(id);
                            record(resolve(id), {
                                kind: 'base-require',
                                specifier: id,
                                via: 'vendor-bootstrap',
                            });
                            return mod;
                        }
                        throw error;
                    }
                }
            }
            : ensureModule);
    }
    catch { }
    try {
        setGlobal('__nsVendorAliases', aliases);
    }
    catch { }
    try {
        setGlobal('require', g['__nsRequire']);
    }
    catch { }
    try {
        setGlobal('__nsRequireIsShim', true);
    }
    catch { }
    try {
        setGlobal('__nsVendorRequire', g['__nsRequire']);
    }
    catch { }
    if (verbose) {
        console.info('[ns-entry] vendor manifest applied', (g['__nsVendorManifest'] || {}).hash);
    }
}
//# sourceMappingURL=vendor-bootstrap.js.map