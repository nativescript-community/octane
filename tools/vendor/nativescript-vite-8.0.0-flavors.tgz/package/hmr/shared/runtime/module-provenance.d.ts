export declare function installModuleProvenanceRecorder(verbose?: boolean): void;
