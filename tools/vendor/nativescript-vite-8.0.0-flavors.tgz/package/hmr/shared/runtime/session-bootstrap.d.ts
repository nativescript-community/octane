export declare function startBrowserRuntimeSession(defaultSessionUrl: string, verbose?: boolean): Promise<void>;
