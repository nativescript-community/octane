export type BootTraceSegment = {
    ok?: boolean;
    ms?: number;
    meta?: Record<string, unknown>;
};
export type BootTrace = {
    t0: number;
    t1?: number;
    session?: BootTraceSegment;
    importMap?: BootTraceSegment;
    entry?: BootTraceSegment;
    error?: {
        message: string;
    };
};
export declare function formatBootTimeline(trace: BootTrace): string;
export declare function publishBootTrace(trace: BootTrace): void;
