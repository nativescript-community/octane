/**
 * Internals shared by the dev-overlay backends (boot placeholder, in-tree
 * live overlay, iOS UIWindow overlay): the per-session runtime state held on
 * `globalThis`, core-class resolution that respects the realm rule, and
 * snapshot/text formatting. Not part of the public overlay API — import
 * `dev-overlay.ts` for that.
 */
import { type HmrOverlayPosition, type HmrOverlaySnapshot } from './dev-overlay-snapshots.js';
export type BootOverlayRefs = {
    page: any;
    root: any;
    titleLabel: any;
    statusLabel: any;
    activityIndicator?: any;
};
export type LiveOverlayRefs = {
    page: any;
    wrapper: any;
    overlay: any;
    titleLabel: any;
    statusLabel: any;
    wasVisible: boolean;
    currentPosition: HmrOverlayPosition;
};
export type IosOverlayRefs = {
    window: any;
    controller: any;
    backdrop: any;
    panel: any;
    titleLabel: any;
    statusLabel: any;
    wasVisible: boolean;
    currentPosition: HmrOverlayPosition;
};
export type HmrOverlayRuntimeState = {
    snapshot: HmrOverlaySnapshot;
    bootRefs: BootOverlayRefs | null;
    liveRefs: LiveOverlayRefs | null;
    iosRefs: IosOverlayRefs | null;
    iosBuildFailed: boolean;
    verbose: boolean;
    updateAutoHideTimer: ReturnType<typeof setTimeout> | null;
    updateCycleStartedAt: number;
};
export declare function getOverlayGlobal(): any;
/**
 * Resolve the configured live-overlay position.
 *
 * Reads `globalThis.__NS_HMR_OVERLAY_POSITION__` so a project can
 * override the default at boot time (e.g. inside `app.ts` before the
 * Vite session bootstraps). Falls back to 'top' which gives the
 * toast-style chip with a slide-in animation and safe-area padding.
 */
export declare function getHmrDevOverlayPosition(): HmrOverlayPosition;
export declare function getRuntimeState(): HmrOverlayRuntimeState;
export declare function resolveCoreExport(name: string): any;
export declare function asColor(value: string): any;
export declare function formatStatusText(snapshot: HmrOverlaySnapshot): string;
