/**
 * iOS UIWindow overlay backend. The live/connection/update overlay is
 * promoted to its own UIWindow (above `UIWindowLevelAlert`) so the dev
 * surface never gets obscured by modals, bottom sheets, or any other window
 * presented by the host app. Falls back to null (→ in-tree backend) on
 * Android, web, tests, or when scene/window construction fails.
 *
 * The layout math (`computeIosOverlayLayout`, `computeIosOverlayWindowLevel`)
 * is pure and deterministic so the rules stay unit-testable without booting a
 * simulator — see `dev-overlay.spec.ts`.
 */
import { type HmrOverlayPosition, type HmrOverlaySnapshot } from './dev-overlay-snapshots.js';
import { type HmrOverlayRuntimeState, type IosOverlayRefs } from './dev-overlay-shared.js';
/**
 * Returns the UIWindow level we use for the live/connection overlay. We lift
 * above `UIWindowLevelAlert` so system alerts (and any app-presented modal)
 * stack underneath. When the platform does not expose `UIWindowLevelAlert`
 * we fall back to the documented constant value (2000).
 */
export declare function computeIosOverlayWindowLevel(baseAlert?: number | null): number;
export type IosSafeInsets = {
    top: number;
    bottom: number;
    left: number;
    right: number;
};
export type IosRect = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type IosOverlayLayout = {
    backdrop: IosRect;
    panel: IosRect;
    title: IosRect;
    status: IosRect;
};
/**
 * Layout math for the live overlay when it runs inside its own UIWindow.
 * Pure, deterministic and independent of UIKit so we can verify the rules
 * (max panel width, position-aware placement, safe-area clamping, sane
 * defaults) from tests.
 *
 * `position` controls where the panel sits vertically:
 *   - 'top':    hugs `safeInsets.top + toastVerticalInset` so the chip
 *               sits just below the notch / Dynamic Island.
 *   - 'bottom': hugs `viewHeight - safeInsets.bottom - panelHeight -
 *               toastVerticalInset` so the chip sits just above the
 *               home indicator / nav bar.
 *   - 'center': original modal placement (vertically centered, clamped
 *               so it never crosses the top safe-area inset).
 */
export declare function computeIosOverlayLayout(input: {
    viewWidth: number;
    viewHeight: number;
    safeInsets?: IosSafeInsets | null;
    titleHeight: number;
    statusHeight: number;
    maxPanelWidth?: number;
    horizontalMargin?: number;
    panelPadding?: number;
    interLabelSpacing?: number;
    minTopInset?: number;
    position?: HmrOverlayPosition;
    toastVerticalInset?: number;
}): IosOverlayLayout;
type IosOverlayHost = {
    UIWindow: any;
    UIViewController: any;
    UIView: any;
    UILabel: any;
    UIColor: any;
    UIFont: any;
    UIApplication: any;
    UIScreen: any;
    UIWindowLevelAlert?: number;
};
/**
 * Returns the iOS UIKit symbols we rely on if we're running on an iOS runtime
 * with the metadata bridge available. Returns null on Android, web, or in
 * tests so callers can gracefully fall back to the in-tree overlay.
 */
export declare function getIosOverlayHost(): IosOverlayHost | null;
export declare function ensureIosOverlayRefs(state: HmrOverlayRuntimeState): IosOverlayRefs | null;
export declare function applySnapshotToIosRefs(refs: IosOverlayRefs | null, snapshot: HmrOverlaySnapshot): boolean;
export {};
