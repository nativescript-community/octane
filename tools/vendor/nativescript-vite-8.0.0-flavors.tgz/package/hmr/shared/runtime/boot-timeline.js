import { getGlobalScope } from './global-scope.js';
// Pure formatter so we can unit-test the exact string shape without
// touching `console.info` or `Date.now()`.
//
// Format:
//   [ns-boot] ok total=1234ms session=45ms importMap=67ms entry=1100ms
//   [ns-boot] FAILED total=230ms session=45ms ...: <message>
//
// Segment entries are only included when a numeric `ms` was recorded —
// this keeps the log compact when a particular phase was skipped (e.g.
// `__NS_IMPORT_MAP_CONFIGURED__` dedup) or never reached (early error).
export function formatBootTimeline(trace) {
    const status = trace.error ? 'FAILED' : 'ok';
    const parts = [];
    const push = (label, seg) => {
        if (seg && typeof seg.ms === 'number' && Number.isFinite(seg.ms)) {
            parts.push(`${label}=${Math.max(0, Math.round(seg.ms))}ms`);
        }
    };
    const total = typeof trace.t0 === 'number' && typeof trace.t1 === 'number' ? trace.t1 - trace.t0 : undefined;
    if (typeof total === 'number' && Number.isFinite(total)) {
        parts.push(`total=${Math.max(0, Math.round(total))}ms`);
    }
    push('session', trace.session);
    push('importMap', trace.importMap);
    push('entry', trace.entry);
    const suffix = trace.error?.message ? `: ${trace.error.message}` : '';
    return `[ns-boot] ${status} ${parts.join(' ')}${suffix}`.replace(/\s+$/, '');
}
// Install the trace on `globalThis` so diagnostics can pick it up. The key
// is distinct from the entry-runtime trace (`__NS_ENTRY_TRACE__`), which the
// entry runtime writes for its own phases. Exported for tests; the runtime
// path calls this from the session-bootstrap finally block.
export function publishBootTrace(trace) {
    try {
        getGlobalScope().__NS_BOOT_TRACE__ = trace;
    }
    catch { }
}
//# sourceMappingURL=boot-timeline.js.map