export declare function tryFinalizeBootPlaceholder(reason?: string, verbose?: boolean): boolean;
export declare function installRootPlaceholder(verbose?: boolean): void;
