/**
 * In-tree overlay backend: the boot placeholder page and the live/update
 * toast chip rendered inside the app's own view tree (Android, and the iOS
 * fallback when the UIWindow backend can't build). Pure margin math
 * (`computeAndroidToastMargin`) is exported separately so the safe-area rules
 * stay unit-testable without a device.
 */
import { type HmrOverlayPosition, type HmrOverlaySnapshot } from './dev-overlay-snapshots.js';
import { type BootOverlayRefs, type LiveOverlayRefs } from './dev-overlay-shared.js';
export declare function buildBootOverlayRefs(snapshot: HmrOverlaySnapshot): BootOverlayRefs | null;
export declare function applySnapshotToBootRefs(refs: BootOverlayRefs | null, snapshot: HmrOverlaySnapshot): void;
export declare function updateBootStatusLabel(snapshot: HmrOverlaySnapshot): void;
export type AndroidSafeAreaInsets = {
    top: number;
    bottom: number;
    left: number;
    right: number;
};
export type AndroidToastMargin = {
    top: number;
    right: number;
    bottom: number;
    left: number;
};
/**
 * Margin math for the in-tree (Android) live/update toast chip.
 *
 * NativeScript enables edge-to-edge on every Android activity
 * (`@nativescript/core` → `application.android.ts` → `enableEdgeToEdge`),
 * so the page content — and therefore the overlay wrapper we inject into
 * it — extends underneath the status bar and navigation bar. A fixed
 * top/bottom margin leaves the chip tucked behind the system bars, where
 * it gets clipped (Android 15 / API 35 enforces edge-to-edge, so this is
 * now the norm rather than the exception).
 *
 * This pure helper folds the system-bar safe-area insets into the chip's
 * margin so the toast always clears the status bar (top position) /
 * navigation bar (bottom position). It is deterministic and free of
 * native deps so the rules stay unit-testable — the runtime reads the
 * live insets via `readAndroidSafeAreaInsets()` and forwards them here.
 *
 *   - 'top':    margin.top    = baseVerticalInset + safeInsets.top
 *   - 'bottom': margin.bottom = baseVerticalInset + safeInsets.bottom
 *   - 'center': fixed `centerMargin` all around (vertically centered, so
 *               it never approaches the system bars on normal viewports).
 *
 * Horizontal margins always include the relevant safe-area inset so a
 * landscape display cutout / gesture pill doesn't clip the chip edge.
 */
export declare function computeAndroidToastMargin(input: {
    position: HmrOverlayPosition;
    safeInsets?: AndroidSafeAreaInsets | null;
    baseVerticalInset?: number;
    baseHorizontalInset?: number;
    centerMargin?: number;
}): AndroidToastMargin;
export declare function ensureLiveOverlayRefs(snapshot: HmrOverlaySnapshot): LiveOverlayRefs | null;
export declare function applySnapshotToLiveRefs(refs: Pick<LiveOverlayRefs, 'overlay' | 'titleLabel' | 'statusLabel'> & Partial<Pick<LiveOverlayRefs, 'wasVisible' | 'currentPosition'>>, snapshot: HmrOverlaySnapshot): void;
export declare function applySnapshotToLiveRefs(refs: null, snapshot: HmrOverlaySnapshot): void;
