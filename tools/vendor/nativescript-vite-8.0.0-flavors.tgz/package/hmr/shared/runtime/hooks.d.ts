export type NsHmrUpdatePayload = {
    type: 'full-graph' | 'delta';
    version: number;
    changedIds: string[];
    raw: any;
};
export type NsHmrUpdateHandler = (payload: NsHmrUpdatePayload) => void;
/**
 * Register a callback that will be invoked after each HMR batch
 * (full graph or delta) is applied on device.
 *
 * It is safe to call multiple times with the same `id`; the handler
 * will be replaced instead of stacking duplicates across module reloads.
 */
export declare function onHmrUpdate(handler: NsHmrUpdateHandler, id: string): void;
/** Remove a previously registered handler (use the same `id` you registered with). */
export declare function offHmrUpdate(id: string): void;
