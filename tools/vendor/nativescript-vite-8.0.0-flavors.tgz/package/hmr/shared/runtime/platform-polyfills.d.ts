/**
 * NativeScript Platform Polyfills for Vendor Bundle
 *
 * Generates self-contained JavaScript that establishes Web API polyfills
 * required by common frameworks (TanStack Router, SolidJS, etc.) in the
 * NativeScript runtime.
 *
 * This code is prepended to the vendor bundle output so it executes BEFORE
 * any vendor module code. This is critical because:
 *
 *   1. The vendor bundle is the first JS that runs (before HTTP-served modules)
 *   2. Vendor modules (e.g., @tanstack/router-core) may use AbortController,
 *      self, etc. during initialization or first method calls
 *   3. Per-package polyfills in HTTP-served modules run too late and are fragile
 *
 * The generated code is entirely self-contained (no imports/requires) and
 * handles three cases for each global:
 *   - Undefined → install polyfill
 *   - Exists but broken (e.g., non-constructible) → replace with polyfill
 *   - Already works → preserve existing implementation
 */
/**
 * Returns a JavaScript code string that establishes platform polyfills.
 * The returned code is safe to prepend to any ES module bundle.
 */
export declare function generatePlatformPolyfills(): string;
