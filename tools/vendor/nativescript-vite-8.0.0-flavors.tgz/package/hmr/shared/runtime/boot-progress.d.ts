/**
 * `'importing-main'` is the long HTTP-module-load phase (5–10s for a
 * real Angular app). The bar uses this range so the user sees ~62
 * percentage points of motion during the phase that actually takes
 * time, sandwiched between the cheap bootstrap stages
 * ('configuring-import-map' = 26) and the post-import wait
 * ('waiting-for-app' = 94 → 'app-root-committed' = 100).
 */
export declare const BOOT_IMPORT_PROGRESS_MIN = 30;
export declare const BOOT_IMPORT_PROGRESS_MAX = 92;
/** Ceiling guards against rounding into `'waiting-for-app'` (94). */
export declare const BOOT_IMPORT_PROGRESS_CEILING = 94;
export declare function computeBootImportProgress(input: {
    count?: number;
    elapsedMs?: number;
}): number;
/**
 * Render the second-line detail for the placeholder. Surfaces the
 * count + last-loaded module path once the snippet has fired, or a
 * generic "Loading the module graph…" line during the pre-snippet
 * window.
 *
 * No elapsed-ms readout: the primary line's percentage is the progress
 * signal, and the heartbeat's `elapsedMs` is wall-clock since the import
 * started — not a per-module timing — so surfacing it next to the
 * percentage read as a confusing, inaccurate duration.
 */
export declare function formatBootImportDetail(input: {
    count?: number;
    lastModule?: string;
}): string;
/**
 * Ratchet a candidate boot-import progress value against the highest
 * value any consumer has emitted so far (stored on
 * `globalThis.__NS_HMR_BOOT_LAST_PROGRESS__`). Reset by
 * `clearBootProgressState` between sessions.
 */
export declare function applyMonotonicBootProgress(candidate: number): number;
/**
 * Reset every boot-progress global so a re-bootstrapped session (e.g.
 * after `__reboot_ng_modules__`) starts a fresh ratchet rather than
 * inheriting the previous cycle's terminal values.
 */
export declare function clearBootProgressState(): void;
