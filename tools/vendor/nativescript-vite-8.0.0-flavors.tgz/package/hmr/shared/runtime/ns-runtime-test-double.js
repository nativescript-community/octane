/**
 * Stub `scope.require` to resolve `ns:module` to a fresh mutable module
 * object (returned), delegating every other specifier to any pre-existing
 * `require`. Calling again replaces the module object.
 */
export function installFakeNsRuntime(scope = globalThis) {
    const moduleObject = {};
    const previousRequire = scope.require;
    scope.require = (specifier) => {
        if (specifier === 'ns:module') {
            return moduleObject;
        }
        if (typeof previousRequire === 'function') {
            return previousRequire(specifier);
        }
        throw new Error(`No such built-in module: ${specifier}`);
    };
    return moduleObject;
}
//# sourceMappingURL=ns-runtime-test-double.js.map