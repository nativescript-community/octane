export type PlaceholderCtors = {
    Page: any;
    Label: any;
    Image: any;
    ActivityIndicator: any | null;
    StackLayout: any | null;
    GridLayout: any | null;
    ContentView: any | null;
    Color: any | null;
    verbose?: boolean;
};
export type PlaceholderRefs = {
    page: any;
    statusLabel: any;
    detailLabel: any | null;
    progressFill: any | null;
    activityIndicator: any | null;
};
export declare function buildPlaceholderPage(ctors: PlaceholderCtors): PlaceholderRefs;
