/**
 * Flip the dev-boot-complete signal from JS.
 *
 * Sets the JS-visible `__NS_HMR_BOOT_COMPLETE__` global (every existing
 * poller keys off it) AND — when the runtime exposes it — calls
 * ns:module `setDevBootComplete(value)` so the native atomic that gates
 * cold-boot-only behaviors (JS-thread runloop pump between synchronous
 * fetches) is disarmed/re-armed in lockstep.
 *
 * Safe on runtimes without the native setter (Android today, tests): the
 * JS global still flips and the native call is skipped.
 */
export declare function setDevBootComplete(value: boolean): void;
export declare function markDevBootComplete(): void;
