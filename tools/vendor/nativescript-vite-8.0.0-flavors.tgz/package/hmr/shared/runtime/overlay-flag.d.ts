/**
 * Overlay opt-out gate (`NS_VITE_PROGRESS_OVERLAY=0` → disabled). Accepts an
 * override so unit tests can force either state. Reads the build-time define
 * first (const-substituted into bundled modules); define substitution does not
 * reach raw-served client files, so the globalThis seed planted by the entry's
 * defines-seed module is the authoritative runtime fallback. Defaults to
 * enabled.
 */
export declare function resolveOverlayEnabled(override?: boolean): boolean;
