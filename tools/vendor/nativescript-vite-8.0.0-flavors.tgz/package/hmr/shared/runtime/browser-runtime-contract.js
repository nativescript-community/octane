export const NS_HOST_RUNTIME_MODULE_ID = 'ns-host://runtime';
export const NS_HOST_STYLE_ADAPTER_MODULE_ID = 'ns-host://style-adapter';
export const NS_DEFAULT_HOST_MODULES = [NS_HOST_RUNTIME_MODULE_ID, NS_HOST_STYLE_ADAPTER_MODULE_ID];
export const NS_DEV_SESSION_REQUIRED_FIELDS = ['sessionId', 'origin', 'entryUrl', 'clientUrl', 'wsUrl', 'platform'];
export const NS_DEFAULT_DEV_FEATURE_FLAGS = {
    fullReload: true,
    cssHmr: true,
};
function isNonEmptyString(value) {
    return typeof value === 'string' && value.length > 0;
}
export function isNsDevPlatform(value) {
    return value === 'ios' || value === 'android' || value === 'visionos';
}
export function assertNsDevSessionDescriptor(session) {
    if (!session || typeof session !== 'object') {
        throw new Error('Invalid NativeScript dev session descriptor');
    }
    const candidate = session;
    for (const key of NS_DEV_SESSION_REQUIRED_FIELDS) {
        if (!isNonEmptyString(candidate[key])) {
            throw new Error(`Missing dev session field: ${key}`);
        }
    }
    if (!isNsDevPlatform(candidate.platform)) {
        throw new Error(`Invalid dev session platform: ${String(candidate.platform)}`);
    }
    if (candidate.hostModules != null) {
        if (!Array.isArray(candidate.hostModules) || candidate.hostModules.some((value) => !isNonEmptyString(value) || !String(value).startsWith('ns-host://'))) {
            throw new Error('Invalid dev session hostModules');
        }
    }
    if (candidate.runtimeConfigUrl != null && !isNonEmptyString(candidate.runtimeConfigUrl)) {
        throw new Error('Invalid dev session runtimeConfigUrl');
    }
    if (candidate.features != null) {
        if (typeof candidate.features !== 'object') {
            throw new Error('Invalid dev session features');
        }
    }
}
/**
 * Resolve the dev host API from the `ns:module` builtin module via the
 * runtime's global CJS `require` (installed on the global object by
 * ModuleInternal). Always read through this function rather than requiring
 * the builtin directly so every consumer resolves the contract identically —
 * and degrades to an empty surface off-device (tests, non-NativeScript
 * environments, runtimes without the builtin).
 */
export function readNsRuntimeDevHostApi(target = globalThis) {
    const requireFn = target.require;
    if (typeof requireFn !== 'function') {
        return {};
    }
    try {
        const api = requireFn('ns:module');
        return api && typeof api === 'object' ? api : {};
    }
    catch {
        // No such built-in module — a runtime predating ns:module or a
        // host whose require doesn't know the scheme.
        return {};
    }
}
export {};
//# sourceMappingURL=browser-runtime-contract.js.map