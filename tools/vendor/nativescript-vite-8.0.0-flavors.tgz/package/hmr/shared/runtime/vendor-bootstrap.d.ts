export declare function installVendorBootstrap(vendorManifest: any, __nsVendorModuleMap: Record<string, any>, verbose?: boolean): void;
