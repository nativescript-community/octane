export interface WorkerSweepResult {
    /** Workers whose `terminate()` was called successfully. */
    terminated: number;
    /** Workers whose `terminate()` threw (already dead, native error, …). */
    failed: number;
    /** Size of the tracked set before the sweep. */
    total: number;
}
/**
 * Patch the global `Worker` constructor so every construction is recorded in
 * `g.__NS_HMR_WORKERS__`. Idempotent (safe to call from every boot path);
 * transparent to callers — `instanceof`, prototype methods and statics all
 * resolve through the native constructor, and subclassing keeps working via
 * `new.target`.
 *
 * Returns `false` when the realm has no `Worker` (tests, worker realms with
 * workers disabled) or the global scope rejects the patch.
 */
export declare function installWorkerConstructorTracking(g: any, options?: {
    verbose?: boolean;
}): boolean;
/**
 * Terminate every worker in the tracked set and clear it. Per-worker
 * failures are counted, never thrown — a single misbehaving worker must not
 * abort the HMR cycle that triggered the sweep. Clearing unconditionally
 * keeps the set from growing unbounded across cycles.
 */
export declare function sweepTrackedWorkers(g: any): WorkerSweepResult;
