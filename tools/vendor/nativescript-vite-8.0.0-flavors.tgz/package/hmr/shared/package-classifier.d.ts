export interface PackageRuntimeInfo {
    rootPackageName: string;
    hasPackageJson: boolean;
    hasExports: boolean;
    mainEntries: Set<string>;
    hasNativeScriptMetadata: boolean;
}
export declare function extractRootPackageName(spec: string): string;
export declare function getPackageRuntimeInfo(spec: string, projectRoot: string): PackageRuntimeInfo;
