import { readFileSync } from 'fs';
import path from 'path';
import { createRequire } from 'node:module';
const packageRuntimeInfoCache = new Map();
export function extractRootPackageName(spec) {
    if (!spec)
        return '';
    if (spec.startsWith('@')) {
        const parts = spec.split('/');
        return parts.length >= 2 ? `${parts[0]}/${parts[1]}` : spec;
    }
    return spec.split('/')[0];
}
export function getPackageRuntimeInfo(spec, projectRoot) {
    const rootPackageName = extractRootPackageName(String(spec || ''));
    if (!rootPackageName) {
        return {
            rootPackageName: '',
            hasPackageJson: false,
            hasExports: false,
            mainEntries: new Set(),
            hasNativeScriptMetadata: false,
        };
    }
    const resolvedProjectRoot = path.resolve(projectRoot || process.cwd());
    const cacheKey = `${resolvedProjectRoot}::${rootPackageName}`;
    const cached = packageRuntimeInfoCache.get(cacheKey);
    if (cached) {
        return cached;
    }
    const info = {
        rootPackageName,
        hasPackageJson: false,
        hasExports: false,
        mainEntries: new Set(),
        hasNativeScriptMetadata: false,
    };
    try {
        const projectRequire = createRequire(path.join(resolvedProjectRoot, 'package.json'));
        const packageJsonPath = projectRequire.resolve(`${rootPackageName}/package.json`);
        const pkg = JSON.parse(readFileSync(packageJsonPath, 'utf-8'));
        info.hasPackageJson = true;
        info.hasExports = !!pkg.exports && typeof pkg.exports === 'object';
        for (const field of ['module', 'main']) {
            const value = pkg[field];
            if (value && typeof value === 'string') {
                info.mainEntries.add(value.replace(/^\.\//, ''));
            }
        }
        info.hasNativeScriptMetadata = (typeof pkg.nativescript === 'object' && pkg.nativescript !== null) || typeof pkg.peerDependencies?.['@nativescript/core'] === 'string' || typeof pkg.dependencies?.['@nativescript/core'] === 'string';
    }
    catch {
        // Package metadata unavailable — leave defaults and let callers fall back to heuristics.
    }
    packageRuntimeInfoCache.set(cacheKey, info);
    return info;
}
//# sourceMappingURL=package-classifier.js.map