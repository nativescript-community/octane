/**
 * Wire protocol for the `ns:*` HMR messages exchanged over the dev-server
 * WebSocket between the Vite dev server and the on-device client.
 *
 * This is the single source of truth for message shapes. Server emit sites
 * annotate their payload objects with the matching interface here, so a field
 * rename or type drift becomes a compile error at the emit site instead of a
 * silent runtime mismatch the device only discovers at parse time. The client
 * dispatch (`switch (msg.type)`) consumes the `ServerToClientMessage` union and
 * uses {@link assertNeverNsMessage} for exhaustiveness.
 *
 * Pure types + one pure helper only — this module is in `hmr/shared` and must
 * not import from `hmr/server` or `hmr/client`.
 *
 * Direction is encoded by the two unions:
 *   - {@link ServerToClientMessage} — dev server → device (9 messages)
 *   - {@link ClientToServerMessage} — device → dev server (2 messages)
 */
/**
 * Exhaustiveness guard for `switch (msg.type)` dispatch over the message unions.
 * Reaching it means a new message type was added to the union but not handled;
 * TypeScript flags the unhandled branch at compile time and this throws if a
 * truly unexpected payload arrives at runtime.
 */
export function assertNeverNsMessage(message) {
    throw new Error(`Unhandled ns:* HMR message: ${JSON.stringify(message)}`);
}
//# sourceMappingURL=protocol.js.map