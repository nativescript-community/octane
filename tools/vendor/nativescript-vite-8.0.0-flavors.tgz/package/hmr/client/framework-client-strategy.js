/**
 * Client-side framework strategy contract (device HMR runtime).
 *
 * The server-side seam (`hmr/server/framework-strategy.ts`) has a mirror here:
 * each framework that needs bespoke on-device HMR behavior implements this and
 * is selected by `TARGET_FLAVOR` (Vue, Angular, Solid, TypeScript, React all
 * ship one under `hmr/frameworks/<flavor>/client/`).
 *
 * All members are optional except `install`. A missing hook means "use the
 * shared default".
 *
 * Keeping this file free of any framework import is deliberate: it lets the
 * shared client depend only on the contract, so the concrete per-flavor module
 * can later be loaded through a single dynamic `import()` (the device-bundle
 * win) without the shared client statically pulling in every framework client.
 */
export {};
//# sourceMappingURL=framework-client-strategy.js.map