/**
 * JS-owned `import.meta.hot` implementation (Vite-style injected hot contexts).
 *
 * `import.meta.hot` is HMR *policy* and lives entirely in this package — the
 * native runtimes expose no hot API. The dev server injects
 *
 *   import.meta.hot = globalThis.__NS_HOT_REGISTRY__?.createHotContext('<canonical-id>')
 *
 * at the top of every served app module (see `processCodeForDevice`), and this
 * module owns every registry the hot API needs. The registry is installed on
 * `globalThis.__NS_HOT_REGISTRY__` by `installNsHotRegistry()`, which the
 * `/__ns_dev__/client` bootstrap runs before the entry graph evaluates.
 *
 * Process-wide singleton: state is stashed on globalThis so that a second
 * copy of this module (e.g. loaded under a different URL) shares the same
 * registries instead of splitting them.
 *
 * No circulars — don't import from other hmr/client/* modules here.
 */
export interface NsHotEventPayload {
    [key: string]: unknown;
}
type HotCallback = (...args: unknown[]) => unknown;
export interface NsHotRegistry {
    createHotContext(ownerId: string): NsHotContext;
    canonicalHotKey(id: string): string;
    /** Drain `hot.dispose(cb)` callbacks (all modules, or a key subset). Returns count executed. */
    runDispose(keys?: readonly string[]): number;
    /** Drain `hot.prune(cb)` callbacks (all modules, or a key subset). Returns count executed. */
    runPrune(keys?: readonly string[]): number;
    /** True when any module (or any module in the key subset) called `hot.decline()`. */
    hasDeclined(keys?: readonly string[]): boolean;
    /**
     * Accept callbacks registered by `key`'s CURRENT evaluation (a copy; an
     * argument-less `hot.accept()` contributes a no-op). They belong to the
     * module instance being replaced, so a framework strategy must read them
     * BEFORE eviction — `createHotContext` resets them the moment the fresh body
     * evaluates — and invoke them with the fresh namespace afterwards (Vite's
     * accept contract). A non-empty result is what makes a module a
     * self-accepting HMR boundary.
     */
    getAcceptCallbacks(key: string): HotCallback[];
    /**
     * Modules whose CURRENT evaluation accepts updates to `depKey` through the
     * dependency form of `hot.accept`. Each callback takes the array Vite
     * passes (`[freshNamespace]`, `[undefined]` when the dependency does not
     * evaluate in this realm). Same lifetime rule as `getAcceptCallbacks`.
     */
    getDepAcceptors(depKey: string): Array<{
        owner: string;
        callback: HotCallback;
    }>;
    /** True when `ownerKey`'s current evaluation accepts `depKey` via the dependency form. */
    acceptsDep(ownerKey: string, depKey: string): boolean;
    /** Fire `hot.on(event, cb)` listeners. Returns the number of listeners invoked. */
    dispatchHotEvent(event: string, payload?: unknown): number;
    listHotEventListeners(): Record<string, number>;
    /** Wire `hot.send(...)` to the active WebSocket (installed by the full client). */
    setSendToServer(fn: ((event: string, data?: unknown) => void) | null): void;
    /** Override the full-reload behavior (`hot.invalidate()`, declined modules). */
    setFullReloadHandler(fn: ((message?: string) => void) | null): void;
    requestFullReload(message?: string): void;
}
export interface NsHotContext {
    readonly data: Record<string, unknown>;
    accept(...args: unknown[]): void;
    acceptExports(exportNames: string[], cb?: HotCallback): void;
    dispose(cb: HotCallback): void;
    prune(cb: HotCallback): void;
    decline(): void;
    invalidate(message?: string): void;
    on(event: string, cb: HotCallback): void;
    off(event: string, cb: HotCallback): void;
    send(event: string, data?: unknown): void;
}
declare global {
    var __NS_HOT_REGISTRY__: NsHotRegistry | undefined;
    var __NS_DEV_ENTRY_URL__: string | undefined;
}
/**
 * Install (or return the already-installed) process-wide hot registry.
 * Idempotent — safe to call from the bootstrap client, the full client and
 * tests; the first installation wins.
 */
export declare function installNsHotRegistry(): NsHotRegistry;
/** Read the installed registry (installing lazily so callers never race). */
export declare function getNsHotRegistry(): NsHotRegistry;
export declare function createHotContext(ownerId: string): NsHotContext;
export {};
