/**
 * HMR client entry for NativeScript devices.
 *
 * Avoid importing from '@nativescript/core' and other framework modules here to prevent creating a second module realm via HTTP ESM.
 * Always resolve core classes and Application from the vendor realm or globalThis at runtime.
 * The HMR client is evaluated via HTTP ESM on device; static imports would create secondary instances.
 *
 * This entry owns boot-time side effects (core aliases, launch-notification
 * bridge, CSS register) and wires the seams together:
 * - `ws-transport.ts` — socket connect/reconnect + connection overlay
 * - `protocol-dispatch.ts` — routes parsed wire messages
 * - `update-pipeline.ts` — graph state + evict-then-reimport queue
 * - `root-reset.ts` — root-view replacement
 * - `strategy-loader.ts` — flavor detection + framework strategy loading
 */
export declare function initHmrClient(opts?: {
    wsUrl?: string;
}): void;
export default function startViteHMR(opts?: {
    wsUrl?: string;
}): void;
