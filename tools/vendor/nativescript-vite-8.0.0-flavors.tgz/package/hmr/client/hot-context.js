/**
 * JS-owned `import.meta.hot` implementation (Vite-style injected hot contexts).
 *
 * `import.meta.hot` is HMR *policy* and lives entirely in this package — the
 * native runtimes expose no hot API. The dev server injects
 *
 *   import.meta.hot = globalThis.__NS_HOT_REGISTRY__?.createHotContext('<canonical-id>')
 *
 * at the top of every served app module (see `processCodeForDevice`), and this
 * module owns every registry the hot API needs. The registry is installed on
 * `globalThis.__NS_HOT_REGISTRY__` by `installNsHotRegistry()`, which the
 * `/__ns_dev__/client` bootstrap runs before the entry graph evaluates.
 *
 * Process-wide singleton: state is stashed on globalThis so that a second
 * copy of this module (e.g. loaded under a different URL) shares the same
 * registries instead of splitting them.
 *
 * No circulars — don't import from other hmr/client/* modules here.
 */
const SCRIPT_EXT_RE = /\.(ts|tsx|js|jsx|mjs|mts|cts)$/i;
// Canonicalize a module identifier so cold-boot URLs, HMR re-import URLs and
// server-injected ids all land on the SAME hot entry (matching module identity
// in the runtime: one canonical URL per module, extensionless app-module form).
function canonicalHotKey(id) {
    if (typeof id !== 'string' || !id)
        return '';
    let key = id.trim();
    // Absolute URL → path.
    key = key.replace(/^https?:\/\/[^/]+/i, '');
    // Query/hash never contribute to identity.
    key = key.replace(/[?#].*$/, '');
    // Device-module route prefix.
    if (key.startsWith('/ns/m/'))
        key = key.slice('/ns/m'.length);
    // Inbound tolerance: collapse tagged spellings if one ever arrives
    // (the server never emits them).
    key = key.replace(/^\/__ns_boot__\/b1\//, '/').replace(/^\/__ns_hmr__\/[^/]+\//, '/');
    key = key.replace(SCRIPT_EXT_RE, '');
    if (!key.startsWith('/'))
        key = '/' + key;
    return key;
}
/**
 * Canonical hot key of a dependency specifier as written in `hot.accept` —
 * relative to the owner module's key (`./embers`, `../util/x`) or already
 * root-absolute (`/src/x`). Bare specifiers are not hot-acceptable (they are
 * vendor modules) and yield ''.
 */
function resolveDepHotKey(ownerKey, specifier) {
    if (typeof specifier !== 'string' || !specifier)
        return '';
    const spec = specifier.trim();
    if (/^https?:\/\//i.test(spec) || spec.startsWith('/'))
        return canonicalHotKey(spec);
    if (!spec.startsWith('.'))
        return '';
    const base = ownerKey.slice(0, ownerKey.lastIndexOf('/') + 1) || '/';
    const segments = base.split('/').filter(Boolean);
    for (const part of spec.split('/')) {
        if (part === '' || part === '.')
            continue;
        if (part === '..')
            segments.pop();
        else
            segments.push(part);
    }
    return canonicalHotKey('/' + segments.join('/'));
}
const VERBOSE = (() => {
    try {
        return globalThis.__NS_ENV_VERBOSE__ === true;
    }
    catch {
        return false;
    }
})();
function createRegistry() {
    const modules = new Map();
    const eventListeners = new Map();
    // depKey → owner keys whose current evaluation accepts it.
    const depAcceptors = new Map();
    let sendToServer = null;
    let fullReloadHandler = null;
    const entryFor = (key) => {
        let entry = modules.get(key);
        if (!entry) {
            entry = { data: {}, acceptCallbacks: [], acceptDeps: new Map(), disposeCallbacks: [], pruneCallbacks: [], declined: false };
            modules.set(key, entry);
        }
        return entry;
    };
    const keysToDrain = (keys) => {
        if (!keys || !keys.length)
            return Array.from(modules.keys());
        const wanted = new Set(keys.map((k) => canonicalHotKey(String(k))));
        return Array.from(modules.keys()).filter((k) => wanted.has(k));
    };
    const drain = (which, keys) => {
        let executed = 0;
        for (const key of keysToDrain(keys)) {
            const entry = modules.get(key);
            if (!entry)
                continue;
            const callbacks = entry[which].splice(0);
            for (const cb of callbacks) {
                try {
                    cb(entry.data);
                    executed++;
                }
                catch (err) {
                    // One bad callback must not break the HMR cycle.
                    console.warn(`[ns-hot] ${which === 'disposeCallbacks' ? 'dispose' : 'prune'} callback threw for ${key}:`, err?.message ?? err);
                }
            }
        }
        return executed;
    };
    // A graph reload replaces what the app owns and nothing else. `@nativescript/core`
    // (`/ns/core*`), the vendor bundle and per-file vendor modules (`/ns/m/node_modules/*`)
    // evaluate once per process: core re-evaluated in place would mint a second
    // `View` hierarchy the still-live native views fail `instanceof` against, and
    // vendor re-evaluation would split every singleton a plugin keeps. The
    // running dev client keeps its identity for the same reason.
    const isAppOwnedModuleUrl = (url, origin) => {
        if (!url.startsWith(origin))
            return false;
        const path = url.slice(origin.length).replace(/[?#].*$/, '');
        if (path.startsWith('/ns/m/'))
            return !path.startsWith('/ns/m/node_modules/');
        return path.startsWith('/ns/sfc') || path.startsWith('/ns/asm');
    };
    const jsFullReload = (message) => {
        const g = globalThis;
        const entryUrl = typeof g.__NS_DEV_ENTRY_URL__ === 'string' ? g.__NS_DEV_ENTRY_URL__ : '';
        if (!entryUrl) {
            console.warn('[ns-hot] full reload requested but no dev entry URL is known', message || '');
            registry.dispatchHotEvent('ns:full-reload-failed', { message: 'no dev entry URL is known' });
            return;
        }
        registry.dispatchHotEvent('vite:beforeFullReload', { message: message || '' });
        // Every app module is about to be replaced, so its `hot.dispose`
        // registrations are due now — the in-process analogue of the page
        // teardown a browser reload implies (an entry module uses this to
        // unmount the root it created before the re-evaluated entry mounts a
        // new one).
        registry.runDispose();
        try {
            // Evict every same-origin module EXCEPT the dev-client modules (the
            // running HMR client must keep its singleton identity) so the entry
            // re-import re-fetches and re-evaluates the whole app graph. The
            // `Application.run` patch (root-placeholder.ts) converts re-entry
            // into `resetRootView`, so no second UIApplicationMain is involved.
            const origin = entryUrl.replace(/^(https?:\/\/[^/]+).*$/i, '$1');
            // Inline `ns:module` require instead of `readNsRuntimeDevHostApi` —
            // this file stays import-free (see the header note) because it is
            // served to the device independently of the client bundle.
            let dev;
            try {
                dev = typeof g.require === 'function' ? g.require('ns:module') : undefined;
            }
            catch {
                dev = undefined;
            }
            const getUrls = dev?.getLoadedModuleUrls;
            const invalidate = dev?.invalidateModules;
            const list = typeof getUrls === 'function' ? getUrls() : [];
            const evict = (Array.isArray(list) ? list : []).filter((u) => typeof u === 'string' && isAppOwnedModuleUrl(u, origin));
            if (evict.length && typeof invalidate === 'function') {
                invalidate(evict);
            }
            if (VERBOSE) {
                console.info(`[ns-hot] full reload: evicted ${evict.length} modules, re-importing ${entryUrl}`);
            }
        }
        catch (err) {
            console.warn('[ns-hot] full reload eviction failed:', err?.message ?? err);
        }
        // Module re-evaluation drives the app reset; the settled import is the
        // only signal that the reloaded graph has finished evaluating.
        void import(/* @vite-ignore */ entryUrl)
            .then(() => {
            registry.dispatchHotEvent('ns:full-reload-complete', { message: message || '' });
        })
            .catch((err) => {
            console.warn('[ns-hot] full reload entry re-import failed:', err?.message ?? err);
            registry.dispatchHotEvent('ns:full-reload-failed', { message: String(err?.message ?? err) });
        });
    };
    const registry = {
        canonicalHotKey,
        createHotContext(ownerId) {
            const key = canonicalHotKey(ownerId);
            const entry = entryFor(key);
            // Fresh evaluation of the module: previous accept/dispose/prune
            // registrations belong to the replaced instance. `data` persists.
            entry.acceptCallbacks = [];
            for (const depKey of entry.acceptDeps.keys()) {
                const owners = depAcceptors.get(depKey);
                owners?.delete(key);
                if (owners && owners.size === 0)
                    depAcceptors.delete(depKey);
            }
            entry.acceptDeps = new Map();
            entry.disposeCallbacks = [];
            entry.pruneCallbacks = [];
            entry.declined = false;
            // Prune the previous evaluation's `hot.on` listeners (see
            // `HotModuleEntry.ownListeners`) — they close over the replaced
            // module instance and would otherwise fire forever.
            if (entry.ownListeners) {
                for (const [event, callbacks] of entry.ownListeners) {
                    const globalSet = eventListeners.get(event);
                    if (!globalSet)
                        continue;
                    for (const cb of callbacks) {
                        globalSet.delete(cb);
                    }
                    if (globalSet.size === 0) {
                        eventListeners.delete(event);
                    }
                }
            }
            const ownListeners = new Map();
            entry.ownListeners = ownListeners;
            return {
                get data() {
                    return entry.data;
                },
                accept(...args) {
                    const cb = args.find((a) => typeof a === 'function');
                    const deps = typeof args[0] === 'string' ? [args[0]] : Array.isArray(args[0]) ? args[0] : null;
                    if (deps === null) {
                        entry.acceptCallbacks.push(cb || (() => { }));
                        return;
                    }
                    for (const dep of deps) {
                        const depKey = resolveDepHotKey(key, String(dep));
                        if (!depKey)
                            continue;
                        entry.acceptDeps.set(depKey, cb || (() => { }));
                        let owners = depAcceptors.get(depKey);
                        if (!owners) {
                            owners = new Set();
                            depAcceptors.set(depKey, owners);
                        }
                        owners.add(key);
                    }
                },
                acceptExports(_exportNames, cb) {
                    entry.acceptCallbacks.push(cb || (() => { }));
                },
                dispose(cb) {
                    if (typeof cb === 'function')
                        entry.disposeCallbacks.push(cb);
                },
                prune(cb) {
                    if (typeof cb === 'function')
                        entry.pruneCallbacks.push(cb);
                },
                decline() {
                    entry.declined = true;
                },
                invalidate(message) {
                    registry.requestFullReload(message ? `${key}: ${message}` : `${key} invalidated`);
                },
                on(event, cb) {
                    if (typeof event !== 'string' || typeof cb !== 'function')
                        return;
                    let set = eventListeners.get(event);
                    if (!set) {
                        set = new Set();
                        eventListeners.set(event, set);
                    }
                    set.add(cb);
                    let own = ownListeners.get(event);
                    if (!own) {
                        own = new Set();
                        ownListeners.set(event, own);
                    }
                    own.add(cb);
                },
                off(event, cb) {
                    eventListeners.get(event)?.delete(cb);
                    ownListeners.get(event)?.delete(cb);
                },
                send(event, data) {
                    if (sendToServer) {
                        try {
                            sendToServer(event, data);
                        }
                        catch (err) {
                            console.warn('[ns-hot] hot.send failed:', err?.message ?? err);
                        }
                    }
                    else if (VERBOSE) {
                        console.warn(`[ns-hot] hot.send('${event}') dropped — no server socket wired yet`);
                    }
                },
            };
        },
        runDispose(keys) {
            return drain('disposeCallbacks', keys);
        },
        runPrune(keys) {
            return drain('pruneCallbacks', keys);
        },
        hasDeclined(keys) {
            for (const key of keysToDrain(keys)) {
                if (modules.get(key)?.declined)
                    return true;
            }
            return false;
        },
        getAcceptCallbacks(key) {
            const entry = modules.get(canonicalHotKey(String(key)));
            return entry ? entry.acceptCallbacks.slice() : [];
        },
        getDepAcceptors(depKey) {
            const owners = depAcceptors.get(canonicalHotKey(String(depKey)));
            if (!owners)
                return [];
            const out = [];
            for (const owner of owners) {
                const callback = modules.get(owner)?.acceptDeps.get(canonicalHotKey(String(depKey)));
                if (callback)
                    out.push({ owner, callback });
            }
            return out;
        },
        acceptsDep(ownerKey, depKey) {
            return modules.get(canonicalHotKey(String(ownerKey)))?.acceptDeps.has(canonicalHotKey(String(depKey))) === true;
        },
        dispatchHotEvent(event, payload) {
            const listeners = eventListeners.get(event);
            if (!listeners || !listeners.size)
                return 0;
            let invoked = 0;
            for (const cb of Array.from(listeners)) {
                try {
                    cb(payload);
                    invoked++;
                }
                catch (err) {
                    // Per-listener failures are swallowed so a single bad
                    // listener can't break the dispatch.
                    console.warn(`[ns-hot] listener for '${event}' threw:`, err?.message ?? err);
                }
            }
            return invoked;
        },
        listHotEventListeners() {
            const out = {};
            for (const [event, set] of eventListeners) {
                if (set.size)
                    out[event] = set.size;
            }
            return out;
        },
        setSendToServer(fn) {
            sendToServer = typeof fn === 'function' ? fn : null;
        },
        setFullReloadHandler(fn) {
            fullReloadHandler = typeof fn === 'function' ? fn : null;
        },
        requestFullReload(message) {
            if (fullReloadHandler) {
                try {
                    fullReloadHandler(message);
                    return;
                }
                catch (err) {
                    console.warn('[ns-hot] full-reload handler threw; using built-in reload:', err?.message ?? err);
                }
            }
            jsFullReload(message);
        },
    };
    return registry;
}
/**
 * Install (or return the already-installed) process-wide hot registry.
 * Idempotent — safe to call from the bootstrap client, the full client and
 * tests; the first installation wins.
 */
export function installNsHotRegistry() {
    const g = globalThis;
    if (g.__NS_HOT_REGISTRY__ && typeof g.__NS_HOT_REGISTRY__.createHotContext === 'function') {
        return g.__NS_HOT_REGISTRY__;
    }
    const registry = createRegistry();
    try {
        g.__NS_HOT_REGISTRY__ = registry;
    }
    catch { }
    return registry;
}
/** Read the installed registry (installing lazily so callers never race). */
export function getNsHotRegistry() {
    return installNsHotRegistry();
}
export function createHotContext(ownerId) {
    return getNsHotRegistry().createHotContext(ownerId);
}
//# sourceMappingURL=hot-context.js.map