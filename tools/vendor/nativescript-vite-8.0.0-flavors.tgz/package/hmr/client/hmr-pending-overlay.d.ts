export type HmrOverlayApiLike = {
    setUpdateStage?: (stage: string, info?: {
        detail?: string;
    }) => unknown;
} | null | undefined;
export type HmrPendingHandlerDeps = {
    /** Resolves the live overlay API. Returning null/undefined is treated as "no overlay installed". */
    getOverlay: () => HmrOverlayApiLike;
    /** Override the build-time gate for testing. Defaults to reading `__NS_HMR_PROGRESS_OVERLAY_ENABLED__` (or `true` when undefined). */
    overlayEnabled?: boolean;
};
export declare function buildHmrPendingDetail(filePath: string | undefined): string;
export declare function applyHmrPendingFrame(filePath: string | undefined, deps: HmrPendingHandlerDeps): boolean;
