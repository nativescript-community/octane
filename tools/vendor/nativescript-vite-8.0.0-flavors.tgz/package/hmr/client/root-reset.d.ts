/**
 * Root-view replacement — the "make the new code visible" half of an HMR cycle.
 *
 * `performResetRoot` swaps the app's root for a freshly-created component
 * (delegating construction to the flavor strategy's `createRoot`). Two paths:
 * an in-place `Frame.navigate` fast path for subsequent updates, and a full
 * `Application.resetRootView` for first mount / Frame roots / flavors that
 * opt out of the fast path.
 *
 * Realm rule applies here as everywhere in the client: core classes are
 * resolved through `getCore` / the vendor realm at call time, never via static
 * `@nativescript/core` imports.
 */
export declare function ensureCoreAliasesOnGlobalThis(): void;
export declare function performResetRoot(newComponent: any): Promise<boolean>;
