export declare const APP_CSS_TAG = "app.css";
export declare function applyCssText(cssText: string, tag?: string): void;
export declare function fetchText(url: string): Promise<string>;
export declare function handleCssUpdates(cssUpdates: any[], httpOrigin: string): Promise<void>;
export declare function handleCustomCss(cssText: string): void;
