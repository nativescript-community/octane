/**
 * Protocol dispatch — routes every parsed HMR wire message to the right
 * handler. Dispatch order is load-bearing: `ns:hmr-pending` short-circuits
 * before the strategy await; `angular:component-update` (custom event) must
 * `return` after registry dispatch so the reboot path never runs for in-place
 * template swaps.
 */
export declare function handleHmrMessage(ev: any): Promise<void>;
