export declare const ENV_VERBOSE: boolean;
/**
 * Defensively read a module's default export with progressive backoff.
 * If a TDZ error happens, retry several microtasks and finally one macrotask tick.
 */
export declare function safeReadDefault(mod: any): Promise<any | null>;
export declare function getCore(name: string): any;
export declare function setCurrentApp(app: any | null): void;
export declare function getCurrentApp(): any | null;
export declare function setRootFrame(frame: any | null): void;
export declare function getRootFrame(): any | null;
export declare function setHttpOriginForVite(origin: string | undefined): void;
export declare function getHttpOriginForVite(): string | undefined;
export declare function setHMRWsUrl(wsUrl: string | undefined): void;
export declare function getHMRWsUrl(): string | undefined;
interface HmrGraphModule {
    id: string;
    deps: string[];
    hash: string;
}
export declare function getGraphVersion(): number;
export declare function setGraphVersion(version: number): void;
export declare const graph: Map<string, HmrGraphModule>;
export declare const hmrMetrics: Record<string, any>;
interface PendingFetch {
    resolve: (v: any) => void;
    reject: (e: any) => void;
    spec: string;
    started: number;
}
export declare const pendingModuleFetches: Map<number, PendingFetch>;
export declare const moduleFetchCache: Map<string, string>;
/**
 * Canonical client-side HTTP-origin resolution for device fetches: a
 * message-supplied origin wins, then the origin the entry runtime installed,
 * then derivation from the HMR websocket URL (which itself has a localhost
 * fallback). Never returns an empty string.
 */
export declare function resolveHmrHttpOrigin(preferred?: unknown): string;
export declare function deriveHttpOrigin(wsUrl: string | undefined): string;
export declare function hasExplicitEviction(): boolean;
export declare function emitHmrModeBannerOnce(force?: boolean): void;
export declare function _resetHmrModeBannerForTests(): void;
export declare function invalidateModulesByUrls(urls: readonly string[]): boolean;
export declare function buildEvictionUrls(specs: readonly string[]): string[];
export declare function requestModuleFromServer(spec: string): Promise<string>;
export declare function safeDynImport(spec: string): Promise<any>;
export declare function normalizeSpec(raw: string): string;
export {};
