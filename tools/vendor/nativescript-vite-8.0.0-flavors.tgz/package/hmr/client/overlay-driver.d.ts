export { resolveOverlayEnabled } from '../shared/runtime/overlay-flag.js';
export type HmrUpdateOverlayStage = 'received' | 'evicting' | 'reimporting' | 'rebooting' | 'complete';
export type HmrUpdateOverlayInfo = {
    detail?: string;
    progress?: number | null;
};
/** Live overlay API installed by `shared/runtime/dev-overlay.ts`, or null. */
export declare function getOverlayApi(): any;
/** Drive the apply-progress overlay one stage forward. Soft-fails when the overlay is absent. */
export declare function setUpdateStage(stage: HmrUpdateOverlayStage, info?: HmrUpdateOverlayInfo): void;
