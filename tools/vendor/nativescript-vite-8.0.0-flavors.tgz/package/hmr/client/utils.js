/**
 * No circulars - don't import from other hmr/client/* modules here.
 */
import { getGlobalScope } from '../shared/runtime/global-scope.js';
import { getVendorRequire } from '../shared/runtime/vendor-resolve.js';
import { readNsRuntimeDevHostApi } from '../shared/runtime/browser-runtime-contract.js';
// Build-time verbose flag, read defensively so unit tests (where the
// `define` substitution doesn't run) don't blow up. Exported as the ONE
// canonical copy for client modules — on device these files are served raw
// (no define substitution), so the identifier resolves through the
// globalThis seed planted by the entry's defines-seed module, which this
// helper reads identically from any importer.
export const ENV_VERBOSE = (() => {
    try {
        return typeof __NS_ENV_VERBOSE__ === 'boolean' ? __NS_ENV_VERBOSE__ : false;
    }
    catch {
        return false;
    }
})();
/**
 * Defensively read a module's default export with progressive backoff.
 * If a TDZ error happens, retry several microtasks and finally one macrotask tick.
 */
export async function safeReadDefault(mod) {
    const isTdz = (err) => /before initialization|TDZ/i.test(String(err?.message || err || ''));
    // Attempt immediate read
    try {
        return mod?.default ?? mod ?? null;
    }
    catch (e) {
        if (!isTdz(e))
            throw e;
    }
    // A few microtask retries
    for (let i = 0; i < 4; i++) {
        await Promise.resolve();
        try {
            return mod?.default ?? mod ?? null;
        }
        catch (e) {
            if (!isTdz(e))
                throw e;
        }
    }
    // One macrotask tick (allow dependent modules to finish evaluating)
    await new Promise((r) => setTimeout(r, 0));
    try {
        return mod?.default ?? mod ?? null;
    }
    catch (e) {
        if (!isTdz(e))
            throw e;
    }
    // Final microtask after macrotask
    await Promise.resolve();
    return mod?.default ?? mod ?? null;
}
// Resolve a named export from @nativescript/core (UI classes, Application, the
// tagged-CSS helpers, etc.) via the vendor realm, globalThis, or device require.
export function getCore(name) {
    const g = globalThis;
    const pickApplicationApi = (candidate) => {
        if (!candidate)
            return undefined;
        const candidates = [candidate, candidate.Application, candidate.app, candidate.application];
        for (const entry of candidates) {
            if (entry && (typeof entry.run === 'function' || typeof entry.on === 'function' || typeof entry.resetRootView === 'function')) {
                return entry;
            }
        }
        return undefined;
    };
    if (name === 'Application') {
        try {
            const reg = g.__nsVendorRegistry;
            if (reg && typeof reg.get === 'function') {
                const mod = reg.get('@nativescript/core/application');
                const appModule = (mod && (mod.default || mod)) || mod;
                const picked = pickApplicationApi(appModule);
                if (picked)
                    return picked;
            }
        }
        catch { }
    }
    // 1) Prefer vendor registry to guarantee single realm
    try {
        const reg = g.__nsVendorRegistry;
        if (reg && typeof reg.get === 'function') {
            const mod = reg.get('@nativescript/core');
            const ns = (mod && (mod.default || mod)) || mod;
            if (name === 'Application') {
                const picked = pickApplicationApi(ns);
                if (picked)
                    return picked;
            }
            if (ns && ns[name])
                return ns[name];
        }
    }
    catch { }
    // 2) Fallback to global installed
    try {
        if (g && g[name])
            return g[name];
    }
    catch { }
    // 3) Device require (still resolves to vendor realm when available)
    try {
        const req = getVendorRequire();
        if (req) {
            if (name === 'Application') {
                const appMod = req('@nativescript/core/application');
                const appModule = (appMod && (appMod.default || appMod)) || appMod;
                const pickedFromAppModule = pickApplicationApi(appModule);
                if (pickedFromAppModule)
                    return pickedFromAppModule;
            }
            const mod = req('@nativescript/core');
            const ns = (mod && (mod.default || mod)) || mod;
            if (name === 'Application') {
                const picked = pickApplicationApi(ns);
                if (picked)
                    return picked;
            }
            if (ns && ns[name])
                return ns[name];
        }
    }
    catch { }
    // 4) Last resort: nativeRequire if available
    try {
        const nativeReq = g && g.__nativeRequire;
        if (typeof nativeReq === 'function') {
            try {
                if (name === 'Application') {
                    const appMod = nativeReq('@nativescript/core/application', '/');
                    const appModule = (appMod && (appMod.default || appMod)) || appMod;
                    const pickedFromAppModule = pickApplicationApi(appModule);
                    if (pickedFromAppModule)
                        return pickedFromAppModule;
                }
                const mod = nativeReq('@nativescript/core', '/');
                const ns = (mod && (mod.default || mod)) || mod;
                if (name === 'Application') {
                    const picked = pickApplicationApi(ns);
                    if (picked)
                        return picked;
                }
                if (ns && ns[name])
                    return ns[name];
            }
            catch { }
        }
    }
    catch { }
    return undefined;
}
// last mounted app instance
let CURRENT_APP = null;
export function setCurrentApp(app) {
    CURRENT_APP = app;
}
export function getCurrentApp() {
    return CURRENT_APP;
}
// last known root Frame
let ROOT_FRAME = null;
export function setRootFrame(frame) {
    ROOT_FRAME = frame;
}
export function getRootFrame() {
    return ROOT_FRAME;
}
/**
 * No on-device file materialization: dev runtime operates via HTTP-only URL-based ESM.
 * On-demand module fetch (browser-like dynamic import bridging)
 */
let httpOriginForVite;
export function setHttpOriginForVite(origin) {
    httpOriginForVite = origin;
}
export function getHttpOriginForVite() {
    return httpOriginForVite;
}
let hmrWsUrl = undefined;
export function setHMRWsUrl(wsUrl) {
    hmrWsUrl = wsUrl;
}
export function getHMRWsUrl() {
    return hmrWsUrl;
}
let graphVersion = 0;
export function getGraphVersion() {
    return graphVersion;
}
export function setGraphVersion(version) {
    graphVersion = version;
    try {
        globalThis.__NS_HMR_GRAPH_VERSION__ = version;
    }
    catch { }
}
export const graph = new Map();
// local metrics snapshot
export const hmrMetrics = {};
export const pendingModuleFetches = new Map();
export const moduleFetchCache = new Map(); // spec -> resolved HTTP URL
/**
 * Canonical client-side HTTP-origin resolution for device fetches: a
 * message-supplied origin wins, then the origin the entry runtime installed,
 * then derivation from the HMR websocket URL (which itself has a localhost
 * fallback). Never returns an empty string.
 */
export function resolveHmrHttpOrigin(preferred) {
    return (typeof preferred === 'string' && preferred) || getHttpOriginForVite() || deriveHttpOrigin(getHMRWsUrl());
}
export function deriveHttpOrigin(wsUrl) {
    try {
        // Prefer explicit HTTP origin provided by entry-runtime when available
        try {
            const g = getGlobalScope();
            if (g && typeof g.__NS_HTTP_ORIGIN__ === 'string' && /^https?:\/\//.test(g.__NS_HTTP_ORIGIN__)) {
                return String(g.__NS_HTTP_ORIGIN__);
            }
        }
        catch { }
        const url = new URL(wsUrl || 'ws://localhost:5173/ns-hmr');
        const http = url.protocol === 'wss:' ? 'https:' : 'http:';
        const origin = `${http}//${url.host}`;
        return origin;
    }
    catch {
        return 'http://localhost:5173';
    }
}
// Detect runtime support for explicit module eviction.
//
// The runtime's `invalidateModules(urls)` (ns:module) removes the canonical
// key for each URL from V8's module registry (`g_moduleRegistry`) AND marks
// the same keys "bust next fetch", so the runtime's next HTTP fetch for
// those URLs appends a one-shot `__ns_dev_nonce` query param that
// defeats CFNetwork/NSURLCache staleness. That pairing is what lets the
// client keep import URLs STABLE across saves — eviction (not URL
// mutation) is the freshness mechanism. The runtime contract requires
// this function; `hasExplicitEviction()` remains as a cheap assertion
// point (and for the mode banner).
export function hasExplicitEviction() {
    try {
        return typeof readNsRuntimeDevHostApi(getGlobalScope()).invalidateModules === 'function';
    }
    catch {
        return false;
    }
}
// One-time mode banner so the user can correlate an HMR slowdown with
// the active eviction strategy without grepping logs. Verbose-only.
let _hmrModeBannerEmitted = false;
export function emitHmrModeBannerOnce(force = false) {
    if (_hmrModeBannerEmitted && !force)
        return;
    _hmrModeBannerEmitted = true;
    if (!ENV_VERBOSE)
        return;
    try {
        const supported = hasExplicitEviction();
        const mode = supported ? 'explicit-eviction (stable URLs)' : 'DEGRADED (ns:module invalidateModules missing — stale modules will not be re-fetched)';
        console.info(`[hmr-client] module reload mode: ${mode}`);
    }
    catch { }
}
// Reset the banner — used by tests so mode flips during a single
// process are observable.
export function _resetHmrModeBannerForTests() {
    _hmrModeBannerEmitted = false;
}
// Explicit module eviction.
//
// Hands a list of canonical module URLs (or `/ns/m/...` paths) to the
// runtime so V8's module registry drops them. Returns true iff the
// runtime accepted the eviction; returns `false` (without throwing) when
// ns:module's `invalidateModules` is absent, which callers log as a
// degraded eviction rather than attempting any URL mutation. Empty
// inputs are no-ops.
export function invalidateModulesByUrls(urls) {
    emitHmrModeBannerOnce();
    if (!urls || !urls.length)
        return false;
    const fn = readNsRuntimeDevHostApi(getGlobalScope()).invalidateModules;
    if (typeof fn !== 'function')
        return false;
    try {
        fn.call(null, urls.slice());
        return true;
    }
    catch (error) {
        try {
            if (ENV_VERBOSE)
                console.warn('[hmr-client] ns:module invalidateModules threw', error?.message || error);
        }
        catch { }
        return false;
    }
}
// Build canonical eviction URLs for a list of specs. Each spec must be
// a project-relative path (e.g. `/src/foo.ts`) or a normalizable
// import id; node_modules and virtual specs are filtered out because
// the runtime canonicalizer routes them through different cache keys
// and evicting them would invalidate vendor modules unrelated to the
// HMR change. Output URLs are deduplicated and prefixed with the
// active dev-server origin.
// Strip script-source extensions (`.ts`, `.tsx`, `.js`, `.jsx`, `.mjs`,
// `.mts`, `.cts`) so eviction and dynamic re-import target the SAME
// canonical URL that the server's `rewriteImports` produces for static
// imports. Keep `.vue`, `.json`, `.css`, etc. — those are non-script
// asset URLs the server serves with their own extension preserved.
//
// Why this matters: V8's HTTP-module cache is keyed by URL string. The
// server-side rewrite turns
//
//     import Home from '../components/home'
//
// into
//
//     import Home from '/ns/m/src/components/home'  (no extension)
//
// via `toAppModuleBaseId` (`getProjectRelativeImportPath` collapses
// every script extension to `.mjs` and then strips it). If we evict
// `/ns/m/src/components/home.tsx` (the URL the dev re-import path
// happens to use), V8 still has the no-extension URL cached from the
// initial boot's static-import path — and the route file's re-import
// then resolves its `import Home from '../components/home'` to the
// stale cached module. Stripping here guarantees all three sites
// (static imports, dynamic re-imports, evictions) agree on one URL
// per module so a single eviction actually drops the right cache
// entry.
const SCRIPT_EXT_RE = /\.(ts|tsx|js|jsx|mjs|mts|cts)$/i;
function stripScriptExtension(specPath) {
    return specPath.replace(SCRIPT_EXT_RE, '');
}
export function buildEvictionUrls(specs) {
    const origin = httpOriginForVite || deriveHttpOrigin(hmrWsUrl);
    if (!origin)
        return [];
    const out = [];
    const seen = new Set();
    const addUrl = (url) => {
        if (seen.has(url))
            return;
        seen.add(url);
        out.push(url);
    };
    for (const raw of specs) {
        if (!raw || typeof raw !== 'string')
            continue;
        // Skip virtual / Vite-internal specs — they don't have a stable
        // HTTP cache identity and evicting them would be a no-op.
        if (/^\0|^\/?\0/.test(raw))
            continue;
        if (/plugin-vue:export-helper/.test(raw))
            continue;
        // Skip vendor-realm imports; the bundled vendor module is owned
        // by the runtime, not the dev server, so /ns/m eviction would
        // not match its cache key.
        if (/(^|\/)node_modules\//.test(raw))
            continue;
        const spec = normalizeSpec(raw);
        if (!spec)
            continue;
        const path = spec.startsWith('/') ? spec : '/' + spec;
        const canonical = stripScriptExtension(path);
        // Emit BOTH the canonical (no-extension) and original extensioned
        // URL: static rewritten imports key under the canonical id while
        // dynamic re-imports/prefetch may key under the extensioned one, so
        // evicting only one variant leaves a stale body in the other cache.
        addUrl(origin + '/ns/m' + canonical);
        if (path !== canonical) {
            addUrl(origin + '/ns/m' + path);
        }
    }
    return out;
}
export async function requestModuleFromServer(spec) {
    const isSfcArtifact = (s) => /(?:^|\/)sfc-[a-f0-9]{8}\.mjs$/i.test(s) || /\/_ns_hmr\/src\/sfc\//.test(s) || /__NSDOC__\/_ns_hmr\/src\/sfc\//.test(s);
    // Ignore Vite/virtual helper or empty specs
    if (/^\/?\0/.test(spec) || /plugin-vue:export-helper/.test(spec)) {
        return Promise.reject(new Error('virtual-helper-skip'));
    }
    // Short-circuit device artifact paths (SFC compiled files) – never ask the server for these
    try {
        if (isSfcArtifact(spec)) {
            return Promise.reject(new Error('artifact-path-disallowed'));
        }
    }
    catch { }
    // Special-case JSON package metadata requests at project root ONLY: some modules reference '/package.json' during dev.
    // Intentionally narrow match to '/package.json' to avoid intercepting relative imports that should be inlined.
    if (/^\/?package\.json(?:\/index)?$/.test(spec)) {
        // Let the server send the JSON-wrapped ESM code; we will write it as-is.
        // We still go through the normal request flow below, but short-circuit index heuristics.
    }
    // Strip script-source extensions so the dynamic re-import URL matches the
    // canonical URL rewriteImports produces for static imports (see
    // buildEvictionUrls); otherwise eviction clears only one of the two keys.
    const origin = httpOriginForVite || deriveHttpOrigin(hmrWsUrl);
    if (!origin)
        return Promise.reject(new Error('no-http-origin'));
    const rawPath = spec.startsWith('/') ? spec : '/' + spec;
    const canonicalPath = stripScriptExtension(rawPath);
    const url = origin + '/ns/m' + canonicalPath;
    // Canonical URL, always. Module identity IS the URL: freshness comes
    // from explicit eviction (ns:module `invalidateModules` marks the canonical
    // key "bust next fetch", so the runtime's next fetch appends a
    // one-shot `__ns_dev_nonce` query param that defeats OS-level HTTP
    // caches). Never emit a path tag or version segment for freshness —
    // the runtime treats the literal URL as module identity, so a tagged
    // URL would create a SECOND module identity instead of busting the
    // first one.
    emitHmrModeBannerOnce();
    moduleFetchCache.set(spec, url);
    return Promise.resolve(url);
}
// Centralized safe dynamic import wrapper to guard anomalous specifiers
export async function safeDynImport(spec) {
    const origin = httpOriginForVite || deriveHttpOrigin(hmrWsUrl);
    let finalSpec = spec;
    if (!finalSpec || finalSpec === '@') {
        finalSpec = (origin ? origin : '') + '/ns/m/__invalid_at__.mjs';
    }
    // Use native dynamic import. The /* @vite-ignore */ matters: this file
    // is served through Vite's transform pipeline on device (the vite
    // package is a file: dependency resolved from dist), and without it
    // Vite's import-analysis warns it "cannot be analyzed" on every boot.
    // The spec is always a full runtime URL — nothing for Vite to resolve.
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore - dynamic import expression
    return await import(/* @vite-ignore */ finalSpec);
}
// Normalize import specifiers for HTTP-only ESM runtime
export function normalizeSpec(raw) {
    if (typeof raw !== 'string')
        return raw;
    let spec = raw.trim();
    try {
        // Expand HTTP origin placeholder emitted by server rewrites
        if (spec.startsWith('/__NS_HTTP_ORIGIN__')) {
            const origin = httpOriginForVite || deriveHttpOrigin(hmrWsUrl);
            if (origin)
                return origin + spec.slice('__NS_HTTP_ORIGIN__'.length);
        }
        // If server emitted path-style endpoints inside modules, prefix with origin here
        if (spec.startsWith('/ns/m') || spec.startsWith('/ns/sfc')) {
            const origin = httpOriginForVite || deriveHttpOrigin(hmrWsUrl);
            if (origin)
                return origin + spec;
        }
    }
    catch { }
    // Strip query/hash (cache busters like ?t=, ?v= etc.)
    const before = spec;
    spec = spec.replace(/[?#].*$/, '');
    if (spec !== before) {
        try {
            hmrMetrics.specQueryStripped = (hmrMetrics.specQueryStripped || 0) + 1;
        }
        catch { }
    }
    if (spec.startsWith('@/')) {
        // Generic alias '@/' -> project root relative; avoid assuming '/src/' structure
        spec = '/' + spec.slice(2);
    }
    if (spec === '@') {
        // Map anomalous '@' sentinel to a safe stub module path.
        try {
            hmrMetrics.invalidAtSpec = (hmrMetrics.invalidAtSpec || 0) + 1;
        }
        catch { }
        return '/__invalid_at__.mjs';
    }
    return spec;
}
//# sourceMappingURL=utils.js.map