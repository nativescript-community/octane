/**
 * WebSocket transport — connect/reconnect candidate loop plus the connection
 * overlay state machine ('connecting' / 'reconnecting' / 'synchronizing' /
 * 'offline').
 *
 * Protocol handling is injected via `setHmrMessageHandler` (wired by the
 * client entry) so this module knows nothing about message shapes; it only
 * owns socket lifecycle and the "is the connection healthy" UX.
 */
/**
 * Called by the protocol dispatcher for every parsed message. The first
 * message after a (re)connect proves the pipe is healthy end-to-end, which is
 * what dismisses the connection overlay — `onopen` alone doesn't (the server
 * may accept the socket and still be mid-restart).
 */
export declare function noteHealthyHmrMessage(): void;
/** Wire the protocol dispatcher. Must be set before `connectHmr()` runs. */
export declare function setHmrMessageHandler(handler: (ev: any) => void): void;
/** Best-effort send; silently drops when the socket isn't open. */
export declare function sendHmrMessage(payload: unknown): void;
export declare function connectHmr(): void;
