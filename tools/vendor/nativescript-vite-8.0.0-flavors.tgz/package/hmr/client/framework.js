/** The process-wide `import.meta.hot` registry: accept/dispose callbacks, dependency acceptors, `hot.data`, events, full reload. */
export { getNsHotRegistry } from './hot-context.js';
/** Live mirror of the server's module graph (id → { deps, hash }). */
export { graph, getGraphVersion } from './utils.js';
/** Canonical-URL helpers and the evict + re-import primitives the shared queue uses. */
export { normalizeSpec, requestModuleFromServer, invalidateModulesByUrls, buildEvictionUrls, resolveHmrHttpOrigin, safeDynImport } from './utils.js';
/** `@nativescript/core` export lookup that resolves against the live core realm. */
export { getCore } from './utils.js';
export { ENV_VERBOSE } from './utils.js';
/** Drive the on-device "HMR update" overlay: 'received' | 'evicting' | 'reimporting' | 'rebooting' | 'complete'. */
export { setUpdateStage, getOverlayApi } from './overlay-driver.js';
/** Swap the live root view for a freshly loaded component (the reset path). */
export { performResetRoot } from './root-reset.js';
export { getGlobalScope } from '../shared/runtime/global-scope.js';
/** The `ns:module` builtin as the runtime exposes it (`invalidateModules`, `getLoadedModuleUrls`, …); `{}` off-device. */
export { readNsRuntimeDevHostApi } from '../shared/runtime/browser-runtime-contract.js';
//# sourceMappingURL=framework.js.map