/**
 * Flavor detection + framework client-strategy loading.
 *
 * The shared client talks to frameworks only through the client-strategy seam
 * (`framework-client-strategy.ts`). The strategy is loaded by ONE dynamic
 * per-flavor `import()` so a device only ever fetches its OWN framework's client
 * module — a Vue app never fetches the Angular client, and vice versa.
 *
 * The load is async (one HTTP-ESM fetch on device), so `CLIENT_STRATEGY_READY`
 * is awaited at the top of `handleHmrMessage` before any message is processed —
 * every strategy call site downstream of message processing therefore observes a
 * fully-installed strategy. `install()` itself is best-effort (idempotent dev
 * shims) and not boot-critical, so resolving it slightly after module load is
 * safe.
 */
import type { FrameworkClientStrategy } from './framework-client-strategy.js';
export declare const TARGET_FLAVOR: string;
export declare const TS_LIKE_FLAVOR: boolean;
export declare const APP_ROOT_VIRTUAL: any;
export declare const APP_VIRTUAL_WITH_SLASH: any;
export declare const APP_MAIN_ENTRY_SPEC: string;
export declare const CLIENT_STRATEGY_READY: Promise<void>;
/** Undefined until `CLIENT_STRATEGY_READY` resolves (or when the flavor ships no client strategy). */
export declare function getClientStrategy(): FrameworkClientStrategy | undefined;
