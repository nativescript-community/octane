/**
 * Update pipeline — graph state + the evict-then-reimport queue.
 *
 * Owns the client's view of the module graph (full-graph / delta application)
 * and the changed-module queue that turns a delta into fresh module bodies on
 * device. The ordering inside `processQueue` is load-bearing: explicit
 * eviction MUST complete before re-import, or V8's module registry serves the
 * stale cached module and the drain becomes a silent no-op.
 */
export declare function hasReceivedFirstFullGraph(): boolean;
export declare function markFullGraphReceived(): void;
export declare function applyFullGraph(payload: any): void;
export declare function applyDelta(payload: any): void;
export declare function processQueue(): Promise<void>;
/**
 * Full-graph resync fallback: the server chose to broadcast a fresh graph
 * instead of a delta (reconnect, version drift). Infer which modules changed
 * by hash-diffing against the previous snapshot and evict + re-import them —
 * same V8-cache pitfall as `processQueue`, same eviction-first ordering.
 * Without re-import, HTTP ESM caching means module bodies (and side effects)
 * won't re-run.
 */
export declare function reimportInferredFullGraphChanges(prevGraph: Map<string, {
    id: string;
    deps: string[];
    hash: string;
}>): Promise<void>;
