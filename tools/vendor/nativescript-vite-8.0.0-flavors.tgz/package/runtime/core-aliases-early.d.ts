export declare function installCoreAliasesEarly(verbose?: boolean): void;
