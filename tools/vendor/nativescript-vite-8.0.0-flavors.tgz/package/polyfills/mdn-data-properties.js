/**
 * Mock for mdn-data/css/properties.json
 * Returns empty object since css-tree has its own comprehensive data
 * This prevents css-tree from failing when trying to patch its data
 */
// Return empty object - css-tree will use its built-in data instead
export default {};
//# sourceMappingURL=mdn-data-properties.js.map