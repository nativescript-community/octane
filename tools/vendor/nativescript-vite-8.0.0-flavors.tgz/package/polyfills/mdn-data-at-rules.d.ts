/**
 * Mock for mdn-data/css/at-rules.json
 * Returns empty object since css-tree has its own comprehensive data
 * This prevents css-tree from failing when trying to patch its data
 */
declare const _default: {};
export default _default;
