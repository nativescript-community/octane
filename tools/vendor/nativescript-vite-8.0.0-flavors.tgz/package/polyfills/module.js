/**
 * Polyfill for Node.js 'module' built-in
 * Provides minimal implementation for NativeScript environment
 */
// Mock createRequire function that css-tree uses
export function createRequire(filename) {
    // Return a mock require function
    return function mockRequire(id) {
        // Handle css-tree's internal patch.json file
        if (id.includes('../data/patch.json') || id.includes('patch.json')) {
            // Return css-tree's patch structure
            return {
                atrules: {},
                properties: {},
                types: {},
            };
        }
        // For mdn-data files, return empty objects
        if (id.includes('mdn-data')) {
            return {};
        }
        // For any other requires, return empty object
        return {};
    };
}
// Also export as default for compatibility
export default {
    createRequire: createRequire,
};
//# sourceMappingURL=module.js.map