/**
 * Polyfill for Node.js 'module' built-in
 * Provides minimal implementation for NativeScript environment
 */
export declare function createRequire(filename: string): (id: string) => {
    atrules: {};
    properties: {};
    types: {};
} | {
    atrules?: undefined;
    properties?: undefined;
    types?: undefined;
};
declare const _default: {
    createRequire: typeof createRequire;
};
export default _default;
