export * from './configuration/base.js';
export * from './configuration/javascript.js';
export * from './configuration/typescript.js';
export { appComponentsPlugin, type AppComponentsOptions } from './helpers/app-components.js';
export { getCliFlags } from './helpers/cli-flags.js';
