import type { Plugin } from 'vite';
/**
 * Virtual module that registers @nativescript/core/ui with the bundler module
 * registry (so the XML builder's `global.loadModule('@nativescript/core/ui')`
 * resolves), registers short element names (Frame, StackLayout, …), imports the
 * bundler context, and applies View prototype guards.
 *
 * The entry (`virtual:entry-with-polyfills`, see main-entry.ts) imports this
 * module immediately after `bundle-entry-points`, so its body evaluates after
 * core's entry points but before the user's main module.
 *
 * History: this code used to be string-injected by a `transform` hook in
 * typescript.ts / javascript.ts that regex-matched the generated entry for the
 * literal `import '@nativescript/core/bundle-entry-points';`. main-entry.ts
 * later switched to `JSON.stringify(...)` (double quotes; a full dev-server URL
 * under HMR) and the marker silently stopped matching — no injection, and every
 * XML build failed with "Module 'Frame' not found". A dedicated virtual module
 * cannot drift like that.
 */
export declare const UI_REGISTRATION_VIRTUAL_ID = "virtual:ns-ui-registration";
export declare function createUiRegistrationPlugin(flavor: 'typescript' | 'javascript'): Plugin;
