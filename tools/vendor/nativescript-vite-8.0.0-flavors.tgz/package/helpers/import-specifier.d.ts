export declare function toStaticImportSpecifier(projectRoot: string, filePath: string): string;
