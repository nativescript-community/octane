import type { Platform } from './platform-types.js';
export declare function getCliFlags(): Record<string, string | boolean>;
/**
 * Resolve the active build platform.
 *
 * Prefers `NATIVESCRIPT_BUNDLER_ENV` (which the CLI reliably injects into the
 * dev-server process) over argv `--` flags: the post-`--` env flags parsed by
 * `getCliFlags()` aren't always present when the Vite `serve` process resolves
 * them, which previously left visionOS resolving as non-visionOS.
 *
 * @param flags optional pre-fetched flags object; defaults to `getCliFlags()`.
 */
export declare function resolvePlatform(flags?: Record<string, unknown>): Platform | undefined;
