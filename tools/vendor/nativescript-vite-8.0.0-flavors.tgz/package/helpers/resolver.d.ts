import type { Plugin } from 'vite';
export default function NativeScriptPlugin(options: {
    platform: 'ios' | 'android' | 'visionos';
}): Plugin;
