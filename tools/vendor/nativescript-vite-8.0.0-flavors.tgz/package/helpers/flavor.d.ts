/**
 * A flavor declared by a framework package in its own package.json:
 *
 *   "nativescript": { "vite": { "flavor": "octane", "config": { "import": "octaneConfig", "from": "@nativescript/vite-octane" } } }
 *
 * The dependency that carries it identifies the flavor for detection, and
 * `config` tells `nativescript-vite init` which helper to scaffold.
 */
export interface DeclaredViteFlavor {
    flavor: string;
    package: string;
    config?: {
        import: string;
        from: string;
    };
}
/** The first installed dependency that declares a Vite flavor, if any. */
export declare function findDeclaredViteFlavor(): DeclaredViteFlavor | null;
/**
 * Seed the flavor singleton from an explicit source of truth — the flavor the
 * user's config declared (e.g. `angularConfig()` → `baseConfig({ flavor:
 * 'angular' })`). Dependency-based detection reads only the project's OWN
 * package.json, which misses hoisted framework packages in monorepos (an Nx
 * app depending on a root-level `@nativescript/angular` detects as
 * 'javascript'). A wrong flavor silently disables flavor-gated build steps —
 * most critically the deps-bundle Angular linker, leaving `ɵɵngDeclare*`
 * partial declarations unlinked and crashing at runtime with "needs to be
 * compiled using the JIT compiler" the first time such a factory is pulled
 * (observed with `_PlatformLocation` during an HMR reboot).
 */
export declare function setProjectFlavor(flavor: string): void;
export declare function getProjectFlavor(): string;
/**
 * Utility to determine the project flavor based on installed dependencies
 * (vue, angular, react, svelete, typescript, javascript...)
 */
export declare function determineProjectFlavor(): string | false;
