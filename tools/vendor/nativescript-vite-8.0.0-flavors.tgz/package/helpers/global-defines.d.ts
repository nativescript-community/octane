/**
 * Opt-out flag for the HMR-applying progress overlay.
 *
 * Default: enabled. Set `NS_VITE_PROGRESS_OVERLAY=0` (or `false`) in
 * the environment to suppress the overlay if a developer finds it
 * distracting. We accept the same falsy spellings webpack-era tooling
 * used (`0`, `false`, `off`, `no`) and treat anything else as
 * enabled-by-default; this avoids surprising users who pass quoted
 * truthy strings ("1", "true").
 */
export declare function isHmrProgressOverlayEnabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * Canonical runtime define VALUES, shared by every emitter:
 *   1. Vite `define` substitution — `getGlobalDefines` below
 *   2. the bundle entry's `virtual:ns-defines-seed` module — main-entry.ts
 *   3. the dev server's per-module shim prelude + guarded platform seed —
 *      processCodeForDevice
 *
 * All three MUST agree. They used to be maintained by hand in three places,
 * and drift produced the HMR boot bug class where the bundle seed said
 * `__APPLE__ = true` while a served module's shim fell back to `false` and
 * ran Android code paths on iOS. Add new defines HERE, then thread them
 * through the builders below.
 */
export interface RuntimeDefineValues {
    __DEV__: boolean;
    __ANDROID__: boolean;
    __IOS__: boolean;
    __VISIONOS__: boolean;
    __APPLE__: boolean;
    __COMMONJS__: boolean;
    __NS_WEBPACK__: boolean;
    __NS_ENV_VERBOSE__: boolean;
    __UI_USE_XML_PARSER__: boolean;
    __UI_USE_EXTERNAL_RENDERER__: boolean;
    __CSS_PARSER__: string;
    __TEST__: boolean;
}
export declare function getRuntimeDefineValues(opts: {
    platform?: string;
    isDevMode: boolean;
    verbose: boolean;
}): RuntimeDefineValues;
/**
 * The COMPLETE set of globals the bundle entry's defines-seed module must
 * plant. Superset of {@link getRuntimeDefineValues}: also carries every
 * `__NS_*__` value that raw-served runtime files consume. Vite's `define`
 * substitution never reaches those files (the HMR client and framework
 * clients are served raw from node_modules/dist), so any define they read
 * MUST also exist on globalThis or its build-time fallback silently wins —
 * which is how `NS_VITE_PROGRESS_OVERLAY=0`
 * historically never reached the device, and how '/src'-defaulted app roots
 * broke 'app/'-rooted projects. Rule: add a define consumed by client code →
 * add it HERE, and read it with a `globalThis` fallback at the consumer.
 */
export declare function getRuntimeSeedValues(opts: {
    platform?: string;
    isDevMode: boolean;
    verbose: boolean;
    flavor: string;
    isCI?: boolean;
}): Record<string, unknown>;
/**
 * Unconditional `globalThis.<key> = <value>;` statements — the bundle entry's
 * defines-seed module body (evaluates as a leaf before any sibling import).
 * Accepts the full seed map; `Infinity` is serialized explicitly because
 * `JSON.stringify(Infinity)` is the string "null".
 */
export declare function buildGlobalSeedStatements(values: Record<string, unknown>): string[];
/** @deprecated kept for callers of the platform-only subset; prefer buildGlobalSeedStatements(getRuntimeSeedValues(...)) */
export declare function buildDefineSeedStatements(values: RuntimeDefineValues): string[];
/**
 * Guarded seed for the dev server's per-module prelude. Under HMR the bundle's
 * externalized core URL imports evaluate BEFORE the bundle body (ESM: imports
 * run before the importer), so the unconditional seed above has NOT run when
 * the HTTP core graph instantiates. Whichever served module evaluates first
 * runs this and seeds globalThis with the correct platform; later modules and
 * the bundle seed see it already set and no-op.
 */
export declare function buildGuardedDefineSeedStatement(values: RuntimeDefineValues): string;
/**
 * `const <key> = globalThis.<key> !== undefined ? globalThis.<key> : <canonical>;`
 * shim statements injected at the top of every HTTP-served module. The
 * fallbacks are the canonical values themselves, so a module snapshots correct
 * platform flags even if it evaluates before ANY seed has run.
 */
export declare function buildDefineShimStatements(values: RuntimeDefineValues): string[];
/**
 * Record the app's `__FOO__`-style `define` entries from the resolved Vite
 * config. `global.isIOS` / `import.meta.*` keys are ignored — only bare
 * `__FOO__` identifiers can appear free in app code and get mis-bound. Vite
 * `define` VALUES are JS-expression strings (e.g. `"true"`), so they pass
 * through verbatim; a non-string value is JSON-encoded defensively.
 *
 * `process.env.<KEY>` entries are captured SEPARATELY: production bundles get
 * them via Vite's textual substitution, but raw-served HMR modules read the
 * injected `globalThis.process.env` shim — without these entries every
 * dotenv-sourced value (webpack's dotenv-webpack behavior mirrored by app
 * configs via `define`) is silently `undefined` only under HMR (observed:
 * `SHARED_KEYCHAIN_GROUP` missing broke FCUUID shared-keychain device ids).
 * Define values are JS expressions — for the env shim we want the runtime
 * VALUE, so JSON-parse the common `JSON.stringify(...)`-encoded case and fall
 * back to the raw text for anything exotic.
 */
export declare function setUserDefineEntries(define: Record<string, unknown> | undefined): void;
/** The captured `process.env.<KEY>` define values (see setUserDefineEntries). */
export declare function getUserProcessEnvDefineEntries(): Record<string, string>;
/**
 * Per-module const shims for the captured user defines. `excludeKeys` are the
 * builtin defines already shimmed by {@link buildDefineShimStatements} — skipped
 * here so we never emit a duplicate `const` (a syntax error).
 */
export declare function buildUserDefineShimStatements(excludeKeys?: Iterable<string>): string[];
export declare function getGlobalDefines(opts: {
    platform: string;
    targetMode: string;
    verbose: boolean;
    flavor: string;
    isCI?: boolean;
}): {
    __ANDROID__: string;
    __IOS__: string;
    __VISIONOS__: string;
    __APPLE__: string;
    'global.isAndroid': string;
    'global.isIOS': string;
    __DEV__: string;
    __COMMONJS__: boolean;
    __NS_WEBPACK__: boolean;
    __non_webpack_require__: string;
    __NS_ENV_VERBOSE__: string;
    __NS_TARGET_FLAVOR__: string;
    __NS_CLIENT_STRATEGY_URL__: string;
    __NS_HMR_PROGRESS_OVERLAY_ENABLED__: string;
    __CSS_PARSER__: string;
    __UI_USE_XML_PARSER__: boolean;
    __UI_USE_EXTERNAL_RENDERER__: boolean;
    __TEST__: boolean;
    __CI__: string;
    __NS_APP_ROOT_DIR__: string;
    __NS_APP_ROOT_VIRTUAL__: string;
    'process.env.NODE_ENV': string;
};
