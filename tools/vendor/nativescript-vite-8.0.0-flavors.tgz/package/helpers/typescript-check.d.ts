import type { Plugin } from 'vite';
import type { Platform } from './platform-types.js';
export type PlatformType = Platform;
export type TypeCheckFlavor = 'typescript' | 'react' | 'solid' | 'vue' | 'angular' | 'javascript';
export type TypeCheckMode = 'off' | 'warn' | 'error';
export type TypeCheckSetting = boolean | TypeCheckMode | {
    enabled?: boolean;
    failOnError?: boolean;
    logDiagnostics?: boolean;
    mode?: TypeCheckMode;
};
export interface TypeCheckControlOptions {
    typeCheck?: TypeCheckSetting;
}
export declare function typescriptCheckPlugin(opts: {
    platform?: PlatformType;
    verbose?: boolean;
    failOnError?: boolean;
    logDiagnostics?: boolean;
}): Plugin;
export declare function vueTypeCheckPlugin(opts: {
    platform?: PlatformType;
    verbose?: boolean;
    failOnError?: boolean;
    logDiagnostics?: boolean;
}): Plugin;
export declare function getTypeCheckPlugins(flavor: TypeCheckFlavor, setting?: TypeCheckSetting): Plugin[];
