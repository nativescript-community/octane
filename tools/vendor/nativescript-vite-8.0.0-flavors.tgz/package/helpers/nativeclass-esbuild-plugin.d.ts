import type { Plugin as EsbuildPlugin } from 'esbuild';
import type { Platform } from './platform-types.js';
/**
 * Esbuild plugin that applies the NativeClass transformer to TypeScript/JavaScript files.
 * This is needed for vendor bundle generation which uses esbuild directly instead of Vite's
 * transform pipeline.
 */
export declare function createNativeClassEsbuildPlugin(platform: Platform): EsbuildPlugin;
