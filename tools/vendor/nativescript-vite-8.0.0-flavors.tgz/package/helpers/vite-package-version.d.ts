/**
 * Version of this @nativescript/vite package (not the app's dependency
 * declaration) — used by the startup banner and disk-cache keys. Resolution
 * prefers the package export map, then walks up from this module to the
 * package root (the export map does not always expose package.json).
 */
export declare function getVitePackageVersion(): string;
