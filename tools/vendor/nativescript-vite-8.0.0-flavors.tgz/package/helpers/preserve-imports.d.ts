import type { Plugin } from 'vite';
export declare function preserveImportsPlugin(): Plugin;
