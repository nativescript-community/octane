import type { Plugin } from 'vite';
export declare function getSourceMapJsCompatSubpath(id: string): string | null;
export declare function transformSourceMapJsCompatModule(code: string, id: string): string;
export declare const commonjsPlugins: (Plugin<any> | {
    name: string;
    enforce: string;
    resolveId(id: any): any;
    load(id: any): {
        code: string;
        moduleType: string;
    };
})[];
