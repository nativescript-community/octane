interface PostCssConfigOptions {
    platform: string;
    projectRoot: string;
    themeCoreRoot: string | undefined;
    postcssImport: any;
}
/**
 * Builds PostCSS configuration with a platform-aware postcss-import fallback.
 *
 * Reality check under Vite 8: whenever the compiled CSS still contains
 * `@import`, Vite UNSHIFTS its own bundled postcss-import ahead of every
 * user plugin in this config — so by the time these plugins run, the import
 * rules have already been inlined (or the build already failed on an
 * unresolvable specifier). Platform-variant rewriting (`foo.css` →
 * `foo.ios.css`) therefore happens BEFORE Vite sees the CSS:
 *   - module pipeline: the `ns-css-platform` plugin's transform hook
 *   - direct `preprocessCSS()` callers: `rewritePlatformCssImports()`
 *     (both in helpers/css-platform-plugin.ts)
 * A previous `ns-postcss-platform-import-rewrite` plugin here duplicated that
 * rewrite at the postcss layer; it was unreachable and has been removed.
 *
 * The postcss-import fallback below is retained as defense-in-depth for
 * preprocessor outputs (sass passes `@import "*.css"` through untouched) in
 * case an app's plugin order ever bypasses Vite's internal inliner.
 */
export declare function createPostCssConfig(opts: PostCssConfigOptions): "./postcss.config.js" | {
    plugins: any[];
};
export {};
