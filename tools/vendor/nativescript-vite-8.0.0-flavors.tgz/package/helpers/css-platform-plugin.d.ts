import type { Plugin } from 'vite';
/**
 * Vite plugin: ns-css-platform
 *
 * Provides platform specific CSS resolution. When a generic import fails (foo.css)
 * it will attempt to load foo.android.css or foo.ios.css depending on platform.
 * Also rewrites relative @import specifiers inside CSS files to platform variants
 * when the generic file does not exist but a platform suffixed version does.
 */
/**
 * Rewrites relative `@import "foo.css"` specifiers to their platform-suffixed
 * variants (`foo.android.css` / `foo.ios.css`) when the generic file does not
 * exist on disk but the platform one does. Returns the rewritten code, or
 * `null` when nothing changed.
 *
 * Exported so code paths that feed raw CSS straight into Vite's
 * `preprocessCSS()` (e.g. the `virtual:ns-app-css` module in `main-entry.ts`)
 * can apply the same rewrite — those paths bypass the plugin transform chain,
 * and Vite's internal postcss-import resolver never consults plugin
 * `resolveId` hooks, so without this pre-rewrite they fail with
 * "Unable to resolve @import".
 */
export declare function rewritePlatformCssImports(code: string, dir: string, platform: string): string | null;
export declare function createPlatformCssPlugin(platform: string): Plugin;
