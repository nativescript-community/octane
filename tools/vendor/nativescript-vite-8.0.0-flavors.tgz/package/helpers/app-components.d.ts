import type { Plugin } from 'vite';
import type { Platform } from './platform-types.js';
export interface AppComponentsOptions {
    /**
     * List of app component paths (relative to project root).
     * These are typically custom Android Activity or Application classes.
     * Example: ['./app/custom-activity.android.ts', './app/custom-application.android.ts']
     */
    appComponents?: string[];
    platform: Platform;
    verbose?: boolean;
}
/**
 * Plugin to handle NativeScript app components (custom Activity/Application classes)
 *
 * These components need to be bundled as separate entry points because:
 * 1. Custom Android Activity classes are loaded by the Android runtime before the main bundle
 * 2. Custom Android Application classes are loaded even earlier in the app lifecycle
 *
 * Usage in vite.config.ts:
 * ```ts
 * import { defineConfig } from 'vite';
 * import { typescriptConfig, appComponentsPlugin } from '@nativescript/vite';
 *
 * export default defineConfig(({ mode }) => {
 *   const config = typescriptConfig({ mode });
 *   config.plugins.push(
 *     appComponentsPlugin({
 *       appComponents: ['./app/custom-activity.android.ts'],
 *       platform: 'android'
 *     })
 *   );
 *   return config;
 * });
 * ```
 *
 * Or via environment variable:
 * NS_APP_COMPONENTS="./app/custom-activity.android,./app/custom-application.android" ns run android
 */
export declare function appComponentsPlugin(options: AppComponentsOptions): Plugin;
/**
 * Get resolved app components with their output file names
 * Used by main-entry.ts to inject imports for custom activities/applications
 */
export declare function getResolvedAppComponents(platform: string): Array<{
    absolutePath: string;
    outputName: string;
}>;
