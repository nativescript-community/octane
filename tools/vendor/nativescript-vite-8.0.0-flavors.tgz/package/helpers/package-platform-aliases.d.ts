import type { Plugin } from 'vite';
export declare function packagePlatformResolverPlugin(opts: {
    tsConfig: {
        paths?: Record<string, string[]>;
    } | null;
    verbose?: boolean;
    platform: string;
}): Plugin;
