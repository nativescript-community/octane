import type { Plugin } from 'vite';
/**
 * Absolute directory roots that the project's tsconfig `paths` aliases point at.
 *
 * Used to scope HMR to configured shared libraries in a monorepo: a file only
 * triggers an update if it lives under the app source dir or one of these
 * alias roots. When an alias targets a file (e.g. `@org/lib -> libs/lib/src/index.ts`)
 * the file's directory is returned so sibling source files in that library are
 * also in scope. Wildcard aliases (`@org/* -> libs/*`) contribute their resolved
 * base directory (`libs`).
 */
export declare function getTsConfigAliasRoots(opts: {
    paths?: Record<string, string[]>;
    baseUrl?: string;
}): string[];
export declare function createTsConfigSpecifierResolver(opts: {
    paths: Record<string, string[]>;
    baseUrl: string;
    platform: string;
    verbose?: boolean;
}): ((source: string) => string | null) | undefined;
/**
 * Vite `resolveId` plugin that maps tsconfig `paths` aliases to absolute module
 * ids. Thin wrapper over `createTsConfigSpecifierResolver`.
 */
export declare function createTsConfigPathsResolver(opts: {
    paths: Record<string, string[]>;
    baseUrl: string;
    platform: string;
    verbose?: boolean;
}): Plugin | undefined;
export declare function resolveProjectTsAlias(spec: string): string | null;
/**
 * Resolve an aliased specifier to a POSIX, project-root-relative path
 * (`@present/components/ui/BasePage.vue` → `/src/presentation/components/ui/BasePage.vue`) —
 * the form the HMR SFC routes use as their on-disk `base`. Returns `null` when
 * the alias doesn't match or resolves outside the project root.
 */
export declare function resolveProjectTsAliasRelative(spec: string, projectRoot: string): string | null;
type TsConfigOptions = {
    platform: string;
    verbose?: boolean;
};
export declare const getTsConfigData: (options: TsConfigOptions) => {
    paths: Record<string, string[]>;
    baseUrl: string;
};
export {};
