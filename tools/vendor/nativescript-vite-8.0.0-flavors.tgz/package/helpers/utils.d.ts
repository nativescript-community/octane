export declare function nsConfigToJson(): Record<string, any>;
/**
 * Resolves the NativeScript platform-specific file for a given module ID.
 * @param id The module ID to resolve.
 * @param platform The target platform (e.g., "ios", "android").
 * @returns The resolved file path or undefined if not found.
 */
export declare function resolveNativeScriptPlatformFile(id: string, platform: string): string | undefined;
/**
 * Utility to get all dependencies from the project package.json.
 * The result combines dependencies and devDependencies
 *
 * @returns string[] dependencies
 */
export declare function getAllDependencies(): string[];
/**
 * Check if a dependency is present in package.json
 */
export declare function hasDependency(packageName: string): boolean;
/**
 * Utility to get the path (usually nested in node_modules) of a dependency.
 *
 * @param dependencyName
 */
export declare function getDependencyPath(dependencyName: string): string | null;
/**
 * Get the version of a dependency from package.json
 */
export declare function getDependencyVersion(packageName: string): string | undefined;
export declare function getProjectAppPath(): string;
export declare function getProjectAppRelativePath(subPath?: string): string;
export declare function getProjectAppAbsolutePath(subPath?: string): string;
export declare function getProjectAppVirtualPath(subPath?: string): string;
export declare const GLOBAL_APP_CSS_CANDIDATES: string[];
/**
 * Resolve the project's global stylesheet, preferring `app.css` and falling
 * back to `styles.css`. Returns the absolute filesystem path of the first
 * candidate that exists under the app directory, or `null` when none are
 * present. All call sites share this single resolver so the entry generator,
 * the virtual-module loader, and the HMR watcher always agree on the same file.
 */
export declare function resolveProjectGlobalCssPath(projectRoot?: string): string | null;
