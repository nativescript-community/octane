import type { Platform } from './platform-types.js';
/**
 * Opt-in: skip the NativeClass ES5 downlevel entirely and let the iOS runtime handle plain
 * ES `class X extends NativeBase {}` declarations natively (the runtime registers the
 * Objective-C class lazily via new.target and also provides a global no-op `NativeClass`
 * decorator, so decorated sources keep working without any build-time rewriting).
 *
 * Enabled via `--env.nativeESClasses` or the NS_NATIVE_ES_CLASSES environment variable
 * (set NS_NATIVE_ES_CLASSES=0/false to force-disable). Android continues to require the
 * ES5 downlevel (the Static Binding Generator relies on it), so this never applies to
 * Android targets.
 */
export declare function isNativeESClassesEnabled(platform?: Platform): boolean;
/**
 * Apply the NativeClass transformer to a source string. Returns null if no change performed.
 */
export declare function transformNativeClassSource(code: string, fileName: string): {
    code: string;
    map: any;
};
