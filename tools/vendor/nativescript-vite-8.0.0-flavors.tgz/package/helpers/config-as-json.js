import { nsConfigToJson } from './utils.js';
const nsConfigVirtualId = '\0nsvite:nsconfig-json';
export default function nsConfigAsJsonPlugin() {
    // will hold your parsed config object
    let configObject;
    return {
        name: 'nsvite-nsconfig-as-json',
        // 1. Intercept imports of "~/package.json"
        resolveId(source) {
            if (source === '~/package.json') {
                return nsConfigVirtualId;
            }
            return null;
        },
        // 2. When Vite asks us to load that virtual ID...
        load(id) {
            if (id === nsConfigVirtualId) {
                configObject = nsConfigToJson();
                // c) Return an ESM wrapper so Vite can import it at build‑time
                return {
                    code: `export default ${JSON.stringify(configObject)};`,
                    moduleType: 'js',
                };
            }
            return null;
        },
        // 3. After Rollup has generated all chunks, emit a package.json asset
        //    into the output directory (dist/ by default)
        generateBundle(_options, _bundle) {
            // Lazy-init in case no module in the graph imported '~/package.json'
            // this build. (Under HMR with @nativescript/core external, the
            // `~/package.json` import that lived inside core's graph is gone, so
            // `load()` never fires. Without this guard, `configObject` is
            // undefined, `JSON.stringify` returns undefined, and rolldown's
            // emitFile rejects it with "Missing field `inner` on
            // BindingEmittedAsset.source".)
            if (!configObject) {
                configObject = nsConfigToJson();
            }
            const json = JSON.stringify(configObject, null, 2);
            this.emitFile({
                type: 'asset',
                fileName: 'package.json',
                source: json,
            });
        },
    };
}
//# sourceMappingURL=config-as-json.js.map