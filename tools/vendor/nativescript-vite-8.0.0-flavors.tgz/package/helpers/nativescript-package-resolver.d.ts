export declare function nativescriptPackageResolver(platform: string): {
    name: string;
    enforce: string;
    resolveId(id: any, importer: any): any;
};
