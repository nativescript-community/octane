export declare const aliasCssTree: {
    find: string;
    replacement: string;
}[];
