export declare function cliPlugin(opts: {
    distOutputFolder: string;
    isDevMode: boolean;
    verbose: boolean;
    hmrActive: boolean;
}): {
    name: string;
    apply: string;
    enforce: "post";
    configResolved(config: any): void;
    generateBundle(options: any, bundle: any): void;
    writeBundle(options: any, bundle: any): void;
    closeBundle(): void;
};
