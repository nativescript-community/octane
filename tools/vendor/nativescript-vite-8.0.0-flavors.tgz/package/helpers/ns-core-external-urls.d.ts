import type { Plugin } from 'vite';
import type { Platform } from './platform-types.js';
export interface NsCoreExternalUrlsPluginOptions {
    platform: Platform;
    projectRoot: string;
    /** Resolved @nativescript/core root (workspace source or node_modules install). */
    nsCoreRoot: string;
    hmrPort: number;
    useHttps: boolean;
}
/**
 * HMR builds only: rewrite every bare `@nativescript/core*` specifier to the
 * full /ns/core HTTP URL so bundle.mjs contains NO bundled copy of the core
 * runtime. The plugin runs with enforce:'pre' so it fires BEFORE Vite's alias
 * resolution converts bare specifiers to absolute filesystem paths, and
 * apply:'build' so the dev-server transform pipeline (which has its own
 * import-map) is unaffected.
 *
 * Why this is necessary: core's transitively-bundled helpers (e.g.
 * `@nativescript/zone-js` patches) write `import '@nativescript/core/globals'`
 * in their source. Without this interception, rolldown leaves those as bare
 * specifiers in the emitted bundle.mjs output, iOS's ESM loader can't resolve
 * bare specifiers at module-instantiation time (the runtime import map is
 * installed later by the HMR client), and it falls back to a filesystem
 * lookup that crashes with
 * "Module not found: Cannot find module @nativescript/core/globals".
 *
 * The broader architecture: Vite is the single source of truth for every
 * `@nativescript/core` URL on the device, so this build-time pre-resolver
 * routes every reference into the runtime bridge.
 */
export declare function nsCoreExternalUrlsPlugin(opts: NsCoreExternalUrlsPluginOptions): Plugin;
