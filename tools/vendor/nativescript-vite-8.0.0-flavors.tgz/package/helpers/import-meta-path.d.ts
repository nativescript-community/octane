import { fileURLToPath } from 'node:url';
type FileUrlToPathOptions = Parameters<typeof fileURLToPath>[1];
export declare function resolveRelativeToImportMeta(metaUrl: string, relativePath: string, options?: FileUrlToPathOptions): string;
export {};
