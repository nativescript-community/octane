/**
 * Absolute directories HMR is allowed to react to:
 *   - the app source dir (`appPath`, default `src`)
 *   - shared-library roots from tsconfig `paths` (monorepo libs)
 *
 * Pass the project's tsconfig data (`{ paths, baseUrl }` from `getTsConfigData`)
 * to include configured workspace libraries. Always includes the app source dir.
 */
export declare function getHmrSourceRoots(tsConfig?: {
    paths?: Record<string, string[]>;
    baseUrl?: string;
}): string[];
/**
 * True when `file` lives inside one of the HMR source roots (app source dir or a
 * configured shared-library root). Accepts absolute paths with either separator
 * style and strips any query/hash suffix (`…/app.component.ts?ngResource`).
 */
export declare function isWithinHmrScope(file: string, roots: string[]): boolean;
/**
 * Minimal glob list for `server.watch.ignored`. This is a *performance* guard,
 * NOT the correctness gate (that's the {@link isWithinHmrScope} allowlist applied
 * in `handleHotUpdate`). It keeps chokidar from walking the large native/generated
 * trees that live under the app root. Vite already ignores `node_modules` and
 * `.git` by default; these are the NativeScript-specific additions.
 */
export declare function getHmrWatchIgnoreGlobs(distOutputFolder?: string): string[];
