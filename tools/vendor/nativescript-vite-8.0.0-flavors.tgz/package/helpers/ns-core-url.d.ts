/**
 * Single canonical URL generator for `@nativescript/core` under HMR.
 *
 * Every public-facing reference to `@nativescript/core[/sub]` resolves to
 * exactly one URL string — byte-for-byte identical across every emitter
 * (bundle entry, external-urls plugin, rewriter, import map, runtime
 * require). The only valid shapes are:
 *
 *   - `/ns/core`               — package main
 *   - `/ns/core/<sub>`         — subpath form
 *
 * with `<sub>` always run through `normalizeCoreSub` (extensionless, no
 * `/index` tail, no platform suffix). There is no version segment, no
 * `?p=` query form, no `.js` tail.
 *
 * This module is the ONE site that constructs those URLs. Every caller in
 * the repo should use `buildCoreUrl()` (or `buildCoreUrlPath()` when origin
 * is not known yet). A single violation of canonical form produces a
 * distinct iOS HTTP ESM cache entry for the same file — re-evaluating the
 * module body, re-running `CssAnimationProperty.register(...)` side
 * effects, and crashing with `Cannot redefine property`.
 */
/**
 * Normalize a user-provided subpath into the canonical form used by the
 * /ns/core bridge. Strips:
 *   - Query and hash (`?v=…`, `#…`)
 *   - Leading / trailing slashes
 *   - Trailing `.js`/`.mjs`/`.cjs` extension (platform-suffixed forms are
 *     preserved: `.ios.js` → `.ios`)
 *   - Trailing `/index` segment (package-main sibling: `globals/index` →
 *     `globals`; `ui/core/view/index` → `ui/core/view`)
 *   - Canonical index forms (`index`, `index.js`, empty) → empty string
 *
 * Returns empty string for the main module (`@nativescript/core` itself).
 */
export declare function normalizeCoreSub(sub?: string | null): string;
/**
 * Canonical PATH (no origin) for a core module.
 * Used by middleware/redirects where we don't have the dev-server origin.
 *
 *   ''                → '/ns/core'
 *   'application'     → '/ns/core/application'
 *   'ui/core/view'    → '/ns/core/ui/core/view'
 *   'globals/index'   → '/ns/core/globals'
 */
export declare function buildCoreUrlPath(sub?: string | null): string;
/**
 * Canonical FULL URL for a core module.
 *
 *   origin='http://localhost:5173', sub='application'
 *     → 'http://localhost:5173/ns/core/application'
 *
 * Throws if origin is empty — callers that may not have origin should use
 * `buildCoreUrlPath()` instead.
 */
export declare function buildCoreUrl(origin: string, sub?: string | null): string;
/**
 * Detect whether a URL or path references the /ns/core bridge.
 * Accepts both relative `/ns/core/...` and absolute `http(s)://.../ns/core/...`.
 */
export declare function isCoreBridgeUrl(input: string): boolean;
/**
 * Extract the canonical sub path from a /ns/core URL.
 *   'http://localhost:5173/ns/core'             → ''
 *   'http://localhost:5173/ns/core/application' → 'application'
 *   '/ns/core/ui/core/view'                     → 'ui/core/view'
 *   'http://example.com/other'                  → null
 */
export declare function extractCoreSub(input: string): string | null;
/**
 * Convert a bare `@nativescript/core[/sub]` specifier or an absolute path
 * pointing into `@nativescript/core`'s node_modules install into the
 * canonical sub path. Returns null for anything else.
 *
 *   '@nativescript/core'                                 → ''
 *   '@nativescript/core/application'                     → 'application'
 *   '/node_modules/@nativescript/core/ui/core/view.js'   → 'ui/core/view'
 *   '/foo/bar/baz'                                       → null
 */
export declare function specToCoreSub(spec: string): string | null;
/**
 * Convert an absolute path INSIDE a known @nativescript/core root directory
 * into the canonical sub path. Complements {@link specToCoreSub}, which only
 * recognizes bare specifiers and `node_modules` installs: in a monorepo where
 * core is consumed from source (`<workspace>/packages/core` via a `file:`
 * dependency), the resolve-alias step rewrites bare `@nativescript/core[/sub]`
 * specifiers to absolute paths under that source root BEFORE the
 * `ns-core-external-urls` build plugin sees them. Without this mapping those
 * paths escape externalization and the entire core library is inlined into
 * bundle.mjs — a dead second realm whose `Frame.topmost()` is undefined while
 * the dev-server-served realm owns the live UI.
 *
 *   corePathToSub('/ws/packages/core', '/ws/packages/core')                 → ''
 *   corePathToSub('/ws/packages/core/ui/frame', '/ws/packages/core')        → 'ui/frame'
 *   corePathToSub('/ws/packages/core/ui/frame/index.ios.ts', same root)     → 'ui/frame'
 *   corePathToSub('/elsewhere/file.ts', '/ws/packages/core')                → null
 */
export declare function corePathToSub(spec: string, coreRoot: string | null | undefined): string | null;
/**
 * Produce the set of "runtime module id" strings we expose in
 * `globalThis.__NS_CORE_MODULES__` for a given sub. Callers of the vendor
 * CJS shim may request any of these forms for the same module; we register
 * all of them to the one namespace so lookups are never ambiguous.
 */
export declare function moduleRegistrationKeys(sub?: string | null): string[];
export declare const CORE_SCOPE = "@nativescript/core";
