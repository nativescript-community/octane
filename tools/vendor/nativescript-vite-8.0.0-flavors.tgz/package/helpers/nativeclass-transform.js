import ts from 'typescript';
// This is the active NativeClass transform: a localized textual + AST-assisted
// downlevel that avoids edge corruption of computed property names (e.g.
// ['frame-in']). It is the single production implementation in this package.
import { getCliFlags } from './cli-flags.js';
/**
 * Opt-in: skip the NativeClass ES5 downlevel entirely and let the iOS runtime handle plain
 * ES `class X extends NativeBase {}` declarations natively (the runtime registers the
 * Objective-C class lazily via new.target and also provides a global no-op `NativeClass`
 * decorator, so decorated sources keep working without any build-time rewriting).
 *
 * Enabled via `--env.nativeESClasses` or the NS_NATIVE_ES_CLASSES environment variable
 * (set NS_NATIVE_ES_CLASSES=0/false to force-disable). Android continues to require the
 * ES5 downlevel (the Static Binding Generator relies on it), so this never applies to
 * Android targets.
 */
export function isNativeESClassesEnabled(platform) {
    if (platform === 'android')
        return false;
    const envValue = process.env.NS_NATIVE_ES_CLASSES;
    if (envValue !== undefined) {
        return envValue !== '0' && envValue.toLowerCase() !== 'false';
    }
    try {
        const flags = getCliFlags();
        return !!flags.nativeESClasses;
    }
    catch (e) {
        return false;
    }
}
/**
 * Apply the NativeClass transformer to a source string. Returns null if no change performed.
 */
export function transformNativeClassSource(code, fileName) {
    // Avoid transforming platform-specific sources for the non-target platform.
    // Example: don't run Android-specific transforms on iOS builds and vice versa.
    let platform;
    try {
        const flags = getCliFlags();
        platform = flags.android ? 'android' : 'ios';
        if (fileName.includes('.android.') && platform !== 'android')
            return null;
        if ((fileName.includes('.ios.') || fileName.includes('.visionos.')) && platform === 'android')
            return null;
    }
    catch (e) {
        // If cli flags cannot be read for any reason, fall back to original behavior.
    }
    // Native ES class mode (Apple targets only): leave sources untouched - the runtime
    // understands ES classes extending native types and the NativeClass decorator itself.
    if (isNativeESClassesEnabled(platform))
        return null;
    // If this is JS and we see a __decorate* call that references NativeClass, strip it safely.
    const isJS = /\.(js|mjs|cjs)$/.test(fileName);
    if (isJS && /__decorate[a-zA-Z$]*\s*\(/.test(code) && /\bNativeClass\b/.test(code)) {
        try {
            const sfJS = ts.createSourceFile(fileName, code, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
            let mutated = false;
            const transformer = (ctx) => {
                const factory = ctx.factory ?? ts.factory;
                const visit = (node) => {
                    if (ts.isCallExpression(node)) {
                        const callee = node.expression;
                        const calleeName = ts.isIdentifier(callee) ? callee.text : ts.isPropertyAccessExpression(callee) && ts.isIdentifier(callee.expression) ? `${callee.expression.text}.${callee.name.text}` : undefined;
                        if (calleeName && /^__decorate/.test(calleeName) && node.arguments.length >= 1) {
                            const firstArg = node.arguments[0];
                            if (ts.isArrayLiteralExpression(firstArg)) {
                                const kept = firstArg.elements.filter((el) => !(ts.isIdentifier(el) && el.text === 'NativeClass'));
                                if (kept.length !== firstArg.elements.length) {
                                    mutated = true;
                                    if (kept.length === 0 && node.arguments.length >= 2) {
                                        return ts.visitNode(node.arguments[1], visit);
                                    }
                                    const newArr = factory.updateArrayLiteralExpression(firstArg, kept);
                                    return factory.updateCallExpression(node, node.expression, node.typeArguments, [newArr, ...node.arguments.slice(1)]);
                                }
                            }
                        }
                    }
                    return ts.visitEachChild(node, visit, ctx);
                };
                return (node) => ts.visitNode(node, visit);
            };
            const res = ts.transform(sfJS, [transformer]);
            const transformed = res.transformed[0];
            if (!mutated) {
                res.dispose();
                return null;
            }
            const printer = ts.createPrinter({ newLine: ts.NewLineKind.LineFeed });
            const output = printer.printFile(transformed);
            res.dispose();
            return { code: output, map: null };
        }
        catch {
            // fall through to TS path if anything goes wrong
        }
    }
    // Pre-strip textual @NativeClass decorator (and variants with args) immediately preceding a class,
    // replacing just that occurrence with a stable marker. This ensures we never leave a runtime
    // identifier behind if TypeScript skips or rearranges decorators in this compile phase.
    // Matches stacked decorators and multi-line @NativeClass(...) args.
    // Match @NativeClass (optionally with args, multi-line) not preceded by another decorator line capturing stacked sequences.
    // We'll place the marker right before the class declaration start to simplify slicing.
    const DECORATOR_BLOCK_RE = /(^|\n)((?:\s*@[\w$][^\n]*\n)*)\s*@NativeClass(?:\([\s\S]*?\))?\s*(?=\n(?:\s*@[\w$][^\n]*\n)*\s*(?:export\s+)?class\s)/g;
    const working = code.replace(DECORATOR_BLOCK_RE, (full, prefix, stacked) => {
        // Keep other decorators, inject marker after them.
        return `${prefix || '\n'}${stacked || ''}/*__NativeClass__*/`;
    });
    // If neither original nor marker is present, skip transform early.
    if (!working.includes('@NativeClass') && !working.includes('/*__NativeClass__*/'))
        return null;
    try {
        const sf = ts.createSourceFile(fileName, working, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
        const edits = [];
        // Collect all class declarations (top-level or nested) for potential transform
        const collect = (node) => {
            if (ts.isClassDeclaration(node)) {
                const fullStart = node.getFullStart ? node.getFullStart() : node.pos;
                const preamble = working.slice(fullStart, Math.min(node.getStart(sf) + 64, node.end));
                if (/\/\*__NativeClass__\*\//.test(preamble)) {
                    const original = working.slice(fullStart, node.end);
                    const stripped = original.replace(/\/\*__NativeClass__\*\/\s*/g, '').replace(/^\s*@NativeClass(?:\([\s\S]*?\))?\s*$/gm, '');
                    const hadExport = /^\s*export\s+class\b/.test(stripped);
                    const down = ts
                        .transpileModule(stripped, {
                        compilerOptions: {
                            module: ts.ModuleKind.ESNext,
                            target: ts.ScriptTarget.ES5,
                            experimentalDecorators: true,
                            emitDecoratorMetadata: false,
                            noEmitHelpers: true,
                            useDefineForClassFields: false,
                        },
                    })
                        .outputText.replace(/enumerable:\s*false/g, 'enumerable: true');
                    let cleaned = down.replace(/export \{\};?\s*$/m, '');
                    if (hadExport) {
                        const name = node.name?.text;
                        if (name && !new RegExp(`export\\s*\\{\\s*${name}\\s*\\}`, 'm').test(cleaned)) {
                            cleaned += `\nexport { ${name} };\n`;
                        }
                    }
                    edits.push({ start: fullStart, end: node.end, text: cleaned });
                }
            }
            ts.forEachChild(node, collect);
        };
        collect(sf);
        if (!edits.length)
            return null;
        // Apply edits sequentially
        let output = working;
        // Sort edits by start descending so indices remain valid
        for (const e of edits.sort((a, b) => b.start - a.start)) {
            output = output.slice(0, e.start) + e.text + output.slice(e.end);
        }
        // Remove any remaining markers
        output = output.replace(/\/\*__NativeClass__\*\/\s*/g, '').replace(/@NativeClass(?:\([\s\S]*?\))?\s*/g, '');
        // Deduplicate accidental duplicate re-export lines (e.g. `export { Foo };` appearing twice)
        // This can happen if the transpiled snippet already emitted an export and we also appended one.
        const seenExportLines = new Set();
        output = output
            .split(/\r?\n/)
            .filter((line) => {
            const trimmed = line.trim();
            if (/^export\s*{\s*[A-Za-z_$][A-Za-z0-9_$]*\s*};?$/.test(trimmed)) {
                if (seenExportLines.has(trimmed)) {
                    return false; // drop duplicate
                }
                seenExportLines.add(trimmed);
            }
            return true;
        })
            .join('\n');
        return { code: output, map: null };
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=nativeclass-transform.js.map