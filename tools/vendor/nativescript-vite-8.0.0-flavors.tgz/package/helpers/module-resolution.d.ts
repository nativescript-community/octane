export declare function findPackageInNodeModules(packageName: string, startDir: string): string;
