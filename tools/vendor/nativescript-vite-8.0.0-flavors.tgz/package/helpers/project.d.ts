export declare function getProjectRootPath(): string;
/**
 * Walk up from `start` looking for the nearest monorepo workspace root.
 *
 * Returns the absolute path of the workspace root, or `null` if none of
 * the supported markers are found before reaching the filesystem root. The
 * search returns the FIRST matching ancestor — so a deeply nested app dir
 * inside an Nx monorepo that happens to also live inside a parent pnpm
 * workspace returns the Nx root (closer to the app) rather than the outer
 * pnpm one. This matches Vite's own `searchForWorkspaceRoot` behaviour.
 *
 * Recognized markers (see {@link MONOREPO_WORKSPACE_MARKERS}):
 *  - `pnpm-workspace.yaml` / `pnpm-workspace.yml`
 *  - `lerna.json`
 *  - `nx.json`        (Nx)
 *  - `rush.json`      (Rush)
 *  - `turbo.json`     (Turborepo)
 *  - `deno.json` / `deno.jsonc` containing a `workspace` field
 *  - `package.json` containing a `workspaces` field (npm/yarn workspaces)
 */
export declare function findMonorepoWorkspaceRoot(start?: string): string | null;
/**
 * Memoized variant of {@link findMonorepoWorkspaceRoot}.
 *
 * The dev server resolves hoisted `node_modules/<pkg>/...` candidates on
 * every `/ns/m/` request, and each lookup walks the directory tree once
 * doing `existsSync` calls. Since the workspace layout doesn't change at
 * runtime, the result is safe to cache per `start` directory for the
 * lifetime of the dev server process.
 */
export declare function getMonorepoWorkspaceRoot(start?: string): string | null;
/**
 * Clear the {@link getMonorepoWorkspaceRoot} memoization cache. Intended
 * for tests that mutate the filesystem inside a temp dir between calls.
 */
export declare function clearMonorepoWorkspaceRootCache(): void;
export declare const __dirname: string;
interface IPackageJson {
    name?: string;
    main?: string;
    dependencies?: {
        [name: string]: string;
    };
    devDependencies?: {
        [name: string]: string;
    };
}
/**
 * Utility function to get the contents of the project package.json
 */
export declare function getPackageJson(): IPackageJson;
/**
 * Utility to get project files relative to the project root.
 * @param filePath path to get
 */
export declare function getProjectFilePath(filePath: string): string;
export declare function getProjectTSConfigPath(): string | undefined;
export {};
