import type { Plugin } from 'vite';
/**
 * Post-phase cleanup for NativeClass decorators.
 * Strips `NativeClass` from any `__decorate([...], X)` call (regardless of what
 * other decorators / metadata appear in the array) and downlevels ES6 classes
 * to ES5 so the NativeScript runtime can detect native class inheritance via
 * `__extends`.
 *
 * The pre-phase plugin runs before Vite's TS pipeline and produces ES5 directly,
 * but downstream plugins (notably the Angular plugin) re-compile from the
 * original TypeScript source and overwrite the pre-phase output. This post-phase
 * pass catches those survivors. It's the safety net, not the primary path.
 *
 * Exported separately for testability.
 */
export declare function postCleanupNativeClass(code: string, bareId: string, verbose?: boolean): {
    code: string;
    map: null;
} | null;
/**
 * Wraps NativeClass TS transformer into a Vite plugin.
 */
export declare function createNativeClassTransformerPlugin(): Plugin[];
