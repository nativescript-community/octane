export declare function transformDynamicImports(code: string): string;
export declare function dynamicImportPlugin(): {
    name: string;
    generateBundle(_options: any, bundle: any): void;
};
