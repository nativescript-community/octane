import { type ResolvedConfig, type ViteDevServer } from 'vite';
export declare function mainEntryPlugin(opts: {
    platform: 'ios' | 'android' | 'visionos';
    isDevMode: boolean;
    verbose: boolean;
    hmrActive: boolean;
    useHttps: boolean;
    flavor?: string;
}): {
    name: string;
    configResolved(config: ResolvedConfig): void;
    generateBundle(_outputOptions: unknown, bundle: Record<string, any>): void;
    configureServer(server: ViteDevServer): void;
    resolveId(id: string): string;
    load(id: string): Promise<{
        code: string;
        moduleType: string;
    }>;
};
