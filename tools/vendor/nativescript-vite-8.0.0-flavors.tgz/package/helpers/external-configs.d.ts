import type { Plugin } from 'vite';
/**
 * Vite plugin that merges every dependency's optional `nativescript.vite.mjs`
 * config into the build.
 *
 * Discovery runs in the plugin's `config` hook — which Vite awaits — rather than
 * synchronously while assembling the base config. That is what lets ESM configs
 * (including ones using top-level await, which can't be `require()`d) load via
 * `import()` and still apply, without forcing the config factory or any app's
 * `vite.config.ts` to become async.
 */
export declare function externalConfigsPlugin(): Plugin;
