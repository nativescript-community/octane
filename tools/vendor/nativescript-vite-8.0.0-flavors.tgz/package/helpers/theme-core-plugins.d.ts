import type { Plugin } from 'vite';
/**
 * Return theme core generic CSS alias list converting imports like
 * nativescript-theme-core/css/core.light.css -> platform specific variant when available.
 */
export declare function getThemeCoreGenericAliases(themeCoreRoot: string | undefined, platform: string): any[];
/**
 * Ensures hoisted theme-core is linked into app local node_modules and creates generic -> platform symlinks.
 */
export declare function createEnsureHoistedThemeLinkPlugin(themeCoreRoot: string | undefined, projectRoot: string, platform: string): Plugin | undefined;
/**
 * Fallback loader for theme-core CSS when app-local node_modules copy is missing.
 */
export declare function createThemeCoreCssFallbackPlugin(themeCoreRoot: string | undefined, projectRoot: string, platform: string): Plugin | undefined;
