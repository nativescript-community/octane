import { fileURLToPath } from 'node:url';
export function resolveRelativeToImportMeta(metaUrl, relativePath, options) {
    return fileURLToPath(new URL(relativePath, metaUrl), options);
}
//# sourceMappingURL=import-meta-path.js.map