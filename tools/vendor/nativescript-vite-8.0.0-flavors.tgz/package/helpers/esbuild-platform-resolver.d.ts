/**
 * Rolldown-compatible resolver plugin for NativeScript platform-specific file
 * resolution during dependency optimization.
 */
export declare function optimizeDepsPlatformResolver(opts?: {
    platform: string;
    verbose?: boolean;
}): any;
