import type { ViteDevServer } from 'vite';
import type { AppCssRefreshResult } from './app-css-refresh.js';
/** Tracks the project's `app.css` entry and the files it imports, for HMR invalidation. */
export interface AppCssState {
    path: string;
    deps: Set<string>;
    /**
     * Re-run the app stylesheet pipeline against the current content files.
     * NEVER rejects; conservative on failure (see `createAppCssRefresher`,
     * the only production implementation — test stubs must honor the same
     * contract). `changedSinceStartup` drives the connect-time stylesheet
     * sync (see hmr/server/css-connect-sync.ts).
     */
    refresh: () => Promise<AppCssRefreshResult>;
}
export declare function setAppCssState(server: ViteDevServer, state: AppCssState): void;
export declare function getAppCssState(server: ViteDevServer): AppCssState | undefined;
