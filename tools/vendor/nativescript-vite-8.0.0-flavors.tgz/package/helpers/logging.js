import { createLogger } from 'vite';
import { getGlobalScope } from '../hmr/shared/runtime/global-scope.js';
const GLOBAL_VERBOSE_FLAG = '__NS_ENV_VERBOSE__';
const ENV_VERBOSE_KEYS = ['NS_VITE_VERBOSE', 'NS_ENV_VERBOSE', 'NS_VERBOSE', 'VERBOSE', 'VITE_DEBUG_LOGS', 'DEBUG'];
let cachedVerbose;
function coerceBoolean(value) {
    if (value === undefined || value === null)
        return undefined;
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'number')
        return value !== 0;
    if (typeof value === 'string') {
        const normalized = value.trim().toLowerCase();
        if (!normalized)
            return undefined;
        if (['1', 'true', 'yes', 'y', 'on', 'debug'].includes(normalized)) {
            return true;
        }
        if (['0', 'false', 'no', 'n', 'off'].includes(normalized)) {
            return false;
        }
        return true;
    }
    return undefined;
}
export function resolveVerboseFlag(options = {}) {
    if (options.cache !== false && typeof cachedVerbose === 'boolean') {
        return cachedVerbose;
    }
    const { env = typeof process !== 'undefined' ? process.env : undefined, cliFlags } = options;
    let resolved;
    if (cliFlags && typeof cliFlags === 'object') {
        const cliVerbose = coerceBoolean(cliFlags.verbose ?? cliFlags.VERBOSE);
        if (typeof cliVerbose === 'boolean') {
            resolved = cliVerbose;
        }
    }
    if (resolved === undefined && options.useGlobalFlag !== false) {
        try {
            const globalVerbose = getGlobalScope()?.[GLOBAL_VERBOSE_FLAG];
            const coerced = coerceBoolean(globalVerbose);
            if (typeof coerced === 'boolean') {
                resolved = coerced;
            }
        }
        catch { }
    }
    if (resolved === undefined && env) {
        for (const key of ENV_VERBOSE_KEYS) {
            if (Object.prototype.hasOwnProperty.call(env, key)) {
                const envVerbose = coerceBoolean(env[key]);
                if (typeof envVerbose === 'boolean') {
                    resolved = envVerbose;
                    break;
                }
            }
        }
    }
    if (resolved === undefined) {
        resolved = options.defaultValue ?? false;
    }
    if (options.cache !== false) {
        cachedVerbose = resolved;
    }
    return resolved;
}
export function clearVerboseCache() {
    cachedVerbose = undefined;
}
// Vite/Rollup warning filter helper
// Centralizes suppression of noisy build warnings that are either benign or
// expected given NativeScript's virtual vendor bundling strategy.
// Currently filters:
//  - Sourcemap missing source files (common in published packages)
//  - Sourcemap source paths that walk outside the published package (the map
//    was generated in a monorepo and still references workspace paths the
//    consumer's node_modules doesn't have)
//  - Sidecar `.js.map` files listed in a `//# sourceMappingURL=` comment that
//    were not published alongside the `.js` file
//  - Eval usage attributed to the virtual "@nativescript/vendor" module
//  - License/annotation position warnings for the vendor bundle
//  - Analog Angular optimizer/router plugins that never emit sourcemaps
// Extend this list cautiously; prefer documenting each suppression reason.
//
// All matching uses `.includes()` (never `.startsWith()`) because Vite wraps
// some warnings in picocolors ANSI escape sequences before handing them to
// the logger, which would defeat `startsWith`-style probes on TTY output.
export function createFilteredViteLogger(options = {}) {
    const baseLogger = createLogger(undefined, { allowClearScreen: true });
    return {
        ...baseLogger,
        info(message, opts) {
            if (options.hmrActive && shouldSuppressViteInfo(String(message || '')))
                return;
            return baseLogger.info(message, opts);
        },
        warn(message, options) {
            const msg = String(message || '');
            if (shouldSuppressViteWarning(msg))
                return;
            return baseLogger.warn(message, options);
        },
        warnOnce(message) {
            const msg = String(message || '');
            if (shouldSuppressViteWarning(msg))
                return;
            return baseLogger.warnOnce(message);
        },
    };
}
/**
 * Vite's stock HMR client never connects under device HMR — the device talks
 * to `/ns-hmr` — so Vite's own verdicts about that client are noise, and one
 * of them misleads: `page reload <file>` is what Vite decides for any module
 * it cannot hot-accept on the web, printed while the device is applying the
 * same save in place through a framework strategy.
 */
export function shouldSuppressViteInfo(msg) {
    return /\bpage reload\b/.test(msg) || /\bhmr update\b/.test(msg);
}
// Exported for unit tests. Keep this function pure so the test suite can
// exercise every suppression pattern without instantiating a real logger.
export function shouldSuppressViteWarning(msg) {
    // Missing sourcemap original sources (kept as-is — published packages
    // frequently drop a few `sources[n]` entries during transpile).
    if (msg.includes('Sourcemap for ') && msg.includes('missing source files')) {
        return true;
    }
    // Cross-package sourcemap path. Emitted for every `@nativescript/core`
    // file at dev-server startup when the consumer has the published
    // package installed: the shipped `.js.map` still references the
    // original monorepo `packages/core/**` path, which does not exist in
    // the consumer's node_modules. There is nothing we (or the app
    // author) can do about this short of republishing core with relative
    // sources — silently dropping it is correct.
    if (msg.includes('Sourcemap for ') && msg.includes('points to a source file outside its package')) {
        return true;
    }
    // Missing sidecar .js.map file. A couple of community packages
    // (e.g. `@nativescript-community/observable`) ship the `.js` with a
    // `//# sourceMappingURL=foo.js.map` footer but never include the
    // actual map. Vite's sourcemap loader then retries the ENOENT on
    // every request, flooding the terminal. We cannot resolve the
    // missing file, so suppressing the warn-level diagnostic is the
    // least invasive fix.
    if (msg.includes('Failed to load source map for')) {
        return true;
    }
    // Vendor eval usage (third-party libs aggregated); benign
    if (msg.includes('Use of eval') && (msg.includes('@nativescript/vendor') || msg.includes('"@nativescript/vendor"'))) {
        return true;
    }
    // Annotation/license position warning for vendor bundle
    if ((msg.includes('contains an annotation that Rollup cannot interpret') || msg.includes('position of the comment')) && (msg.includes('@nativescript/vendor') || msg.includes('"@nativescript/vendor"'))) {
        return true;
    }
    // Analog Angular optimizer/router plugins do not emit sourcemaps; Vite floods logs with warnings.
    if (msg.includes('Sourcemap is likely to be incorrect') && (msg.includes('analogjs-router-optimization') || msg.includes('@analogjs/vite-plugin-angular-optimizer'))) {
        return true;
    }
    // "contains Angular decorators but is not in the TypeScript program."
    //
    // Emitted by `@analogjs/vite-plugin-angular` for any `.ts` file that
    // has an Angular decorator (`@Injectable`, `@Component`, etc.) but
    // isn't reachable from Angular's tsconfig program — typically because
    // the file is dynamically imported, lives outside `tsconfig.app.json`'s
    // `include` glob, or is loaded via a non-Angular code path
    // (e.g. `import('./service.ts')` inside a Vite-only utility).
    //
    // In practice these files compile fine via our `tsFallbackTransformPlugin`
    // (which type-strips them through Vite's oxc transformer at request
    // time, see `helpers/workers.ts`'s ANGULAR_DECORATOR_RE skip-guard for
    // the matching policy). Decorator metadata isn't generated for them
    // because they're not in the Angular program — but that's exactly the
    // expected outcome for files that don't need DI or template binding.
    //
    // The warning appears once per offending file at every cold boot of
    // the dev server (50+ lines for a real app), drowning out signal
    // without ever pointing at an actionable problem. Suppressing it
    // matches the working contract `tsFallbackTransformPlugin`
    // established. If a user actually does intend a file to be in the
    // Angular program, they'll notice via Angular's own runtime errors
    // (missing providers, unresolved templates) — which we never
    // suppress.
    if (msg.includes('@analogjs/vite-plugin-angular') && msg.includes('contains Angular decorators but is not in the TypeScript program')) {
        return true;
    }
    return false;
}
//# sourceMappingURL=logging.js.map