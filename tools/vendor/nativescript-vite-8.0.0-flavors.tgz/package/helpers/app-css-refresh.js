/**
 * The refresh state machine for the app stylesheet: serialized generation,
 * previous-output comparison, and the startup baseline.
 *
 * Contract: the returned function NEVER rejects. Generation failure reports
 * `{ changed: true, changedSinceStartup: true }` — conservatism lives here, in
 * exactly one place, because a missed CSS refresh (stale styles for the rest
 * of the session) is worse than a redundant idempotent one. Callers must not
 * re-wrap it in their own fallbacks.
 *
 * Calls are serialized through an internal promise queue: a content edit can
 * arrive while the startup scan is still running, and queueing gives that edit
 * a real baseline instead of racing two Tailwind compilations. The baseline is
 * captured from the first SUCCESSFUL generation, so a transient startup
 * failure cannot poison drift detection for the whole session.
 */
export function createAppCssRefresher(options) {
    let lastGeneratedCss;
    let startupGeneratedCss;
    let queue = Promise.resolve();
    const runRefresh = async () => {
        try {
            const generatedCss = await options.generate();
            const changed = lastGeneratedCss === undefined || generatedCss !== lastGeneratedCss;
            lastGeneratedCss = generatedCss;
            if (startupGeneratedCss === undefined) {
                startupGeneratedCss = generatedCss;
            }
            return { changed, changedSinceStartup: generatedCss !== startupGeneratedCss };
        }
        catch (error) {
            if (options.verbose)
                console.warn('[ns-entry] app.css refresh failed; reporting changed (conservative)', error);
            return { changed: true, changedSinceStartup: true };
        }
    };
    return () => {
        const next = queue.then(runRefresh, runRefresh);
        queue = next;
        return next;
    };
}
//# sourceMappingURL=app-css-refresh.js.map