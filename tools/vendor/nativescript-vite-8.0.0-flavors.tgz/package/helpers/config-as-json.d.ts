import type { Plugin } from 'vite';
export default function nsConfigAsJsonPlugin(): Plugin;
