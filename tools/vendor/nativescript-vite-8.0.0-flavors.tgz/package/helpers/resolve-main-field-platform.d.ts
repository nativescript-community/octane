/**
 * Given a resolved package directory and its `package.json` `main` field, return
 * the platform-specific entry file to use (as a `normalizeModuleId`-canonical
 * absolute id), or `null` when no platform rewrite applies and normal resolution
 * should handle it.
 *
 * Shared by the two `enforce:'pre'` package resolvers (`nativescript-package-resolver`
 * and `package-platform-aliases`) so the main-field platform-variant rules live
 * in one place.
 *
 * Two cases (behavior preserved from the original inline implementations):
 *   1. `main` is extensionless → prefer `<main>.<platform>.js`, else `<main>.js`.
 *   2. `main` has an extension but the file is missing → try `<base>.<platform><ext>`.
 *
 * Note: when an extension-bearing `main` file DOES exist, this returns `null`
 * (the generic file wins) even if a `<base>.<platform><ext>` sibling exists.
 * That is the current, intentional-for-now behavior; revisiting it is tracked
 * separately (it would change resolution for packages shipping both).
 */
export declare function resolveMainFieldPlatformVariant(packagePath: string, mainField: string | undefined | null, platform: string): string | null;
