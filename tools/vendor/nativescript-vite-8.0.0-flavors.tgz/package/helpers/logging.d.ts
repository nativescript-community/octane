import { type Logger } from 'vite';
type Primitive = string | number | boolean | undefined | null;
type ResolveOptions = {
    env?: Record<string, Primitive>;
    cliFlags?: Record<string, Primitive> | null;
    defaultValue?: boolean;
    cache?: boolean;
    useGlobalFlag?: boolean;
};
export declare function resolveVerboseFlag(options?: ResolveOptions): boolean;
export declare function clearVerboseCache(): void;
export declare function createFilteredViteLogger(options?: {
    hmrActive?: boolean;
}): Logger;
/**
 * Vite's stock HMR client never connects under device HMR — the device talks
 * to `/ns-hmr` — so Vite's own verdicts about that client are noise, and one
 * of them misleads: `page reload <file>` is what Vite decides for any module
 * it cannot hot-accept on the web, printed while the device is applying the
 * same save in place through a framework strategy.
 */
export declare function shouldSuppressViteInfo(msg: string): boolean;
export declare function shouldSuppressViteWarning(msg: string): boolean;
export {};
