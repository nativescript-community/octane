import type { Plugin } from 'vite';
export interface WorkerPluginsOptions {
    platform: string;
    verbose?: boolean;
}
export declare function nativescriptWorkerLoaderStubPlugin(): Plugin;
/**
 * Rewrite every code-level `import.meta` usage in a worker module so the
 * emitted classic script can compile.
 *
 * Workers are emitted as classic scripts (the NS worker bootstrap `require()`s
 * them), where ANY code-level `import.meta` token is a compile-time
 * SyntaxError — the runtime reports "Cannot compile script" the moment the
 * worker starts, so the failure looks arbitrary per-worker. Beyond the
 * `.url`/`.dirname` static substitutions, HMR helpers pulled into worker
 * graphs (e.g. @nativescript/angular's hmr view-cache) read `import.meta.hot`
 * / `import.meta["hot"]` / `import.meta["webpackHot"]` defensively behind
 * try/catch — every remaining member access is rewritten to `(undefined)`;
 * workers never have HMR.
 *
 * Bare `import.meta` tokens (no member access) are left alone on purpose:
 * every observed occurrence lives inside string literals (e.g. acorn's parser
 * error messages when a JS parser is bundled into a worker), where they are
 * harmless and rewriting would corrupt library data.
 *
 * Returns `null` when the module contains no `import.meta` at all. None of
 * the replacements add or remove lines, so existing line-level mappings stay
 * valid — the explicit `map: null` also keeps Rolldown from flagging
 * SOURCEMAP_BROKEN on every worker chunk.
 */
export declare function neutralizeWorkerImportMeta(code: string): {
    code: string;
    map: null;
} | null;
export declare function getWorkerPlugins(platformOrOpts: string | WorkerPluginsOptions): any[];
export interface WorkerHmrUrlPluginOptions {
    verbose?: boolean;
}
export declare function viteWorkerAssetPathToNsMUrl(assetPath: string, projectRoot: string, workspaceRoot: string | null): string | null;
export declare function workerHmrUrlPlugin(opts?: WorkerHmrUrlPluginOptions): Plugin;
export declare function workerUrlPlugin(): {
    name: string;
    generateBundle(options: any, bundle: any): void;
};
