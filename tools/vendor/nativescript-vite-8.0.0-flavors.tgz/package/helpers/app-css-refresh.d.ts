/** Result of regenerating the fully transformed app stylesheet. */
export interface AppCssRefreshResult {
    /** True when the output changed relative to the previous successful generation. */
    changed: boolean;
    /**
     * True when the output differs from the baseline captured by the first
     * successful generation at dev-server startup. Drives the connect-time
     * stylesheet sync — see hmr/server/css-connect-sync.ts for the rationale.
     */
    changedSinceStartup: boolean;
}
/**
 * The refresh state machine for the app stylesheet: serialized generation,
 * previous-output comparison, and the startup baseline.
 *
 * Contract: the returned function NEVER rejects. Generation failure reports
 * `{ changed: true, changedSinceStartup: true }` — conservatism lives here, in
 * exactly one place, because a missed CSS refresh (stale styles for the rest
 * of the session) is worse than a redundant idempotent one. Callers must not
 * re-wrap it in their own fallbacks.
 *
 * Calls are serialized through an internal promise queue: a content edit can
 * arrive while the startup scan is still running, and queueing gives that edit
 * a real baseline instead of racing two Tailwind compilations. The baseline is
 * captured from the first SUCCESSFUL generation, so a transient startup
 * failure cannot poison drift detection for the whole session.
 */
export declare function createAppCssRefresher(options: {
    generate: () => Promise<string>;
    verbose?: boolean;
}): () => Promise<AppCssRefreshResult>;
