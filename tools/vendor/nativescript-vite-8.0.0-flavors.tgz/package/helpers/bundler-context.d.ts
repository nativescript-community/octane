import type { Plugin } from 'vite';
import type { Platform } from './platform-types.js';
export type BundlerPlatform = Platform | undefined;
/** Recursively collect every file under `dir` (posix paths), tolerating unreadable entries. */
export declare function walkAppFiles(dir: string, out?: string[]): string[];
/** Skip partials (`_`-prefixed), `.d.ts`, worker modules, and platform-mismatched files. */
export declare function shouldExcludePlatformFile(p: string, platform: BundlerPlatform): boolean;
/** Absolute app path → root-anchored import specifier the dev server can serve. */
export declare function toContextImportSpecifier(abs: string): string;
/** Loads `.xml` files as default-exported strings (shared by the JS and TS configs). */
export declare function createXmlLoaderPlugin(name: string): Plugin;
