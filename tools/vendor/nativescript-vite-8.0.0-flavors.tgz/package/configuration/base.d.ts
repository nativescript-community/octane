import { type UserConfig } from 'vite';
export declare const baseConfig: ({ mode, flavor }: {
    mode: string;
    flavor?: string;
}) => UserConfig;
