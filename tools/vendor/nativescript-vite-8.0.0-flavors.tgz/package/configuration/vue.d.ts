import { type UserConfig } from 'vite';
import { type TypeCheckControlOptions } from '../helpers/typescript-check.js';
export declare const vueConfig: ({ mode }: {
    mode: any;
}, options?: TypeCheckControlOptions) => UserConfig;
