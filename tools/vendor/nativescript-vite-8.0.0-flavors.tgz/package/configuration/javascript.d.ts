import { type UserConfig } from 'vite';
export declare const javascriptConfig: ({ mode }: {
    mode: any;
}) => UserConfig;
