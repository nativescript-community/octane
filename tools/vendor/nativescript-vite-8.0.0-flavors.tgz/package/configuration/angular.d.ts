import { type UserConfig } from 'vite';
/**
 * File replacement entry forwarded to `@analogjs/vite-plugin-angular`.
 * `replace` and `with` may be absolute paths or paths relative to
 * `workspaceRoot` (when supplied). The Analog plugin matches against the
 * resolved id with `endsWith(replace)`, so absolute paths Just Work in Nx
 * / pnpm / Rush layouts where the source tree may live above the project
 * root.
 */
export interface AngularFileReplacement {
    replace: string;
    with: string;
    ssr?: string;
}
export declare const angularConfig: ({ mode, fileReplacements, workspaceRoot, }: {
    mode: string;
    /**
     * Angular CLI–style file replacements (e.g. `environment.ts` →
     * `environment.stg.ts`) forwarded to `@analogjs/vite-plugin-angular`'s
     * `replaceFiles` plugin AND to the Angular TypeScript CompilerHost.
     *
     * Required for monorepo apps that need configuration-specific
     * environment files: the Angular host reads source files via its own
     * file-system layer, so a Vite `resolveId`/`load` plugin alone cannot
     * swap a `.ts` file for `vite serve` / HMR — the host will still
     * compile the original source from disk. Passing the list here ensures
     * the host sees the replacement before TypeScript ever parses the
     * file, matching how Angular CLI's `fileReplacements` works.
     */
    fileReplacements?: AngularFileReplacement[];
    /**
     * Workspace root used by `@analogjs/vite-plugin-angular` to resolve
     * relative `fileReplacements` paths. Absolute paths bypass this.
     * Defaults to `process.cwd()`.
     */
    workspaceRoot?: string;
}) => UserConfig;
